<?php

use App\Http\Controllers\Admin\MediaCenterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

# login view page route
Route::get('secure', function () {
    return view('login');
})->name('login');

# do login route
Route::group(['prefix' => 'auth'], function () {

    Route::post('login','App\Http\Controllers\Admin\AccountController@login');

});

# auth routes
Route::group(['middleware' => ['auth','multilang','AuthPermission']], function(){

	# home route
	Route::get('home', 'App\Http\Controllers\Admin\HomeController@index');

	# users routes
	Route::resource('users', 'App\Http\Controllers\Admin\UserController');

    # courses routes
    Route::resource('courses', 'App\Http\Controllers\Admin\CourseController');

    # course application routes
    Route::resource('courseApplication', 'App\Http\Controllers\Admin\CourseApplicationController');

    # Venue routes
    Route::resource('venue', 'App\Http\Controllers\Admin\VenueController');

    # Subject Area routes
    Route::resource('subject', 'App\Http\Controllers\Admin\SubjectAreaController');

    # Activity Type routes
    Route::resource('activity', 'App\Http\Controllers\Admin\ActivityTypeController');

    # Accreditation Type routes
    Route::resource('accreditation', 'App\Http\Controllers\Admin\AccreditationController');

    # coursereviews routes
    Route::resource('coursereviews', 'App\Http\Controllers\Admin\CourseReviewController');

    # video-reviews routes
    Route::resource('video-reviews', 'App\Http\Controllers\Admin\VideoReviewsController');

    # Home Page
    Route::prefix('home-page')->group(function () {

        # Slider
        Route::resource('slider' , 'App\Http\Controllers\Admin\BannerController');

        # Media Center
        Route::resource('clone-menu', 'App\Http\Controllers\Admin\CloneMenuController');
        Route::resource('footer' , 'App\Http\Controllers\Admin\FooterController');
        Route::resource('menu' , 'App\Http\Controllers\Admin\MenuController');
        Route::resource('media_center' , 'App\Http\Controllers\Admin\MediaCenterController');
        Route::resource('testimonial' , 'App\Http\Controllers\Admin\TestimonialController');
        Route::resource('counter' , 'App\Http\Controllers\Admin\CounterController');
        Route::resource('home-content' , 'App\Http\Controllers\Admin\HomePageContentController');
        Route::resource('blocks' , 'App\Http\Controllers\Admin\BlocksController');
    });

    # BlogSlider routes
    Route::resource('blog_sliders', 'App\Http\Controllers\Admin\BlogSliderController');

    # Training routes
    Route::resource('training', 'App\Http\Controllers\Admin\TrainingController');

    # consultancy routes
    Route::resource('consultancy', 'App\Http\Controllers\Admin\ConsultancyController');

    # Faq routes
    Route::resource('faq', 'App\Http\Controllers\Admin\FaqController');

    # Trusted and Accreditation
    Route::resource('trusted_accreditation' , 'App\Http\Controllers\Admin\TrustedAccreditationController');

    # Contact-us
    Route::resource('contact-us' , 'App\Http\Controllers\Admin\ContactUsController');

    # About-us-head
    Route::resource('about-us-head' , 'App\Http\Controllers\Admin\AboutUsHeadController');

    # About-us
    Route::resource('about-us' , 'App\Http\Controllers\Admin\AboutUsController');

    # Join-us
    Route::resource('join-us' , 'App\Http\Controllers\Admin\JoinUsController');

    # Leadership
    Route::resource('leadership' , 'App\Http\Controllers\Admin\LeadershipController');

    # brands
    Route::resource('brands' , 'App\Http\Controllers\Admin\BrandsController');

    # Our Impact
    Route::resource('our-impact' , 'App\Http\Controllers\Admin\OurImpactController');

    # strategy
    Route::resource('strategy' , 'App\Http\Controllers\Admin\StrategyController');

    # extra
    Route::resource('extra' , 'App\Http\Controllers\Admin\ExtraController');

    # achievements
    Route::resource('achievements' , 'App\Http\Controllers\Admin\AchievementController');

    # Terms Of Use
    Route::resource('terms-of-use' , 'App\Http\Controllers\Admin\TermsOfUseController');

    # privacy-policy
    Route::resource('privacy-policy' , 'App\Http\Controllers\Admin\PrivacyPolicyController');

    # copyright
    Route::resource('copyright' , 'App\Http\Controllers\Admin\CopyrightController');

    # copyright Page
    Route::resource('copyright-page' , 'App\Http\Controllers\Admin\CopyrightPageController');

    # gallery routes
    Route::resource('gallery', 'App\Http\Controllers\Admin\GalleryController');
    
    Route::resource('titles', 'App\Http\Controllers\Admin\TitlesController');

    # pages routes
    Route::resource('pages', 'App\Http\Controllers\Admin\PageController');

    # news routes
    Route::resource('news', 'App\Http\Controllers\Admin\NewsController');

    # news Slider routes
    Route::resource('newsSlider', 'App\Http\Controllers\Admin\NewsSliderController');

    # countries routes
    Route::resource('countries', 'App\Http\Controllers\Admin\CountryController');

    # mobile country codes routes
    Route::resource('mobilecountrycodes', 'App\Http\Controllers\Admin\MobileCountryCodeController');

    # newsletter country codes routes
    Route::resource('newsletter', 'App\Http\Controllers\Admin\NewsletterController');

    # Send Message to Subscribers country codes routes
    Route::post('newsletter/sendnewsletteremail', [\App\Http\Controllers\Admin\NewsletterController::class , 'sendNewsletterEmail']);

    # Reports

    Route::prefix('reports')->group(function () {

        Route::get('contact' , [\App\Http\Controllers\Admin\ReportController::class , 'contactReport']);
        Route::get('join' , [\App\Http\Controllers\Admin\ReportController::class , 'joinReport']);
        Route::get('suggest' , [\App\Http\Controllers\Admin\ReportController::class , 'suggestReport']);
        Route::get('teach' , [\App\Http\Controllers\Admin\ReportController::class , 'teachReport']);
        Route::get('reseller' , [\App\Http\Controllers\Admin\ReportController::class , 'resellerReport']);
        # Filter Reports
        Route::get('filter-contact' , [\App\Http\Controllers\Admin\ReportController::class , 'filterContactReport']);
        Route::get('filter-join' , [\App\Http\Controllers\Admin\ReportController::class , 'filterJoinReport']);
        Route::get('filter-suggest' , [\App\Http\Controllers\Admin\ReportController::class , 'filterSuggestReport']);
        Route::get('filter-teach' , [\App\Http\Controllers\Admin\ReportController::class , 'filterTeachReport']);
        Route::get('filter-reseller' , [\App\Http\Controllers\Admin\ReportController::class , 'filterResellerReport']);
        Route::get('filter-course-application' , [\App\Http\Controllers\Admin\ReportController::class , 'filterCourseApplication']);
    });

    # permissions
    Route::group(['prefix' => 'permissions'], function (){

        Route::get('/',[
            'as' => 'admin.permissions.get', 'uses' => 'App\Http\Controllers\Admin\PermissionController@index'
        ]);

        Route::post('/update',[
            'as' => 'admin.permissions.update', 'uses' => 'App\Http\Controllers\Admin\PermissionController@update'
        ]);

    });

    Route::post('hide/{id}' , [\App\Http\Controllers\Admin\CourseController::class , 'hide'])->middleware('multilang');


});

# logout route
Route::get('auth/logout', 'App\Http\Controllers\Admin\AccountController@logout')->middleware('auth');

# error pages
Route::get('unauthorized', 'App\Http\Controllers\Admin\HomeController@unauthorized')
->middleware(['auth','multilang']);

Route::get('somethingwrong',function(){
	return view('admin.errors.somethingwrong');
})->middleware(['auth','multilang']);


# ajax request
Route::post('userDetails','App\Http\Controllers\Admin\AjaxController@userDetails');
Route::post('getMobileCountryCode','App\Http\Controllers\Admin\AjaxController@getMobileCountryCode');
# ajax request

