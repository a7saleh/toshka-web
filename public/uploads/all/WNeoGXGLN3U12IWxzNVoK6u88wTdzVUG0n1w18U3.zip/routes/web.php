<?php

use App\Models\Accreditation;
use App\Models\ActivityType;
use App\Models\Banner;
use App\Models\Counter;
use App\Models\PageContent;
use App\Models\SliderVideo;
use App\Models\SubjectArea;
use App\Models\Testimonial;
use App\Models\Venue;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Route;
use App\Models\TrustedAccreditation;
use Illuminate\Support\Facades\Session;
use App\Models\Course;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/old', function () {


    $counterArr1 = Counter::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->get();
    $counterArr2 = Counter::where('priority' , null)->orderBy('id' , 'desc')->get();
    $counters = Array();
    foreach ($counterArr1 as $arr){
        array_push($counters , $arr);
    }
    foreach ($counterArr2 as $arr){
        array_push($counters , $arr);
    }


    $courses = Course::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
    $subject_area = SubjectArea::all();
    $venue = Venue::all();
    $activity_type = ActivityType::all();
    $accreditation = TrustedAccreditation::all();
    $banners = Banner::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->limit(5)->get();
    $slider_videos = SliderVideo::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
    $testimonials = Testimonial::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
    $counter1 = Counter::findOrFail(1);
    $counter2 = Counter::findOrFail(2);
    $counter3 = Counter::findOrFail(3);
    $content = PageContent::findOrFail(1);
    $block1 = PageContent::findOrFail(66);
    $block2 = PageContent::findOrFail(67);
    $block3 = PageContent::findOrFail(68);
//    session()->flash('session' , 1);
    return view('website.home.index')
        ->with('courses', $courses)
        ->with('subject_area', $subject_area)
        ->with('venue', $venue)
        ->with('activity_type', $activity_type)
        ->with('accreditation', $accreditation)
        ->with('banners', $banners)
        ->with('videos', $slider_videos)
        ->with('testimonials', $testimonials)
        ->with('counter1', $counter1)
        ->with('counter2', $counter2)
        ->with('counter3', $counter3)
        ->with('content', $content)
        ->with('block1', $block1)
        ->with('block2', $block2)
        ->with('block3', $block3)->with('counters' , $counters);
})->name('home')->middleware('multilang');

Route::get('/', function (){
    return redirect()->route('home');
});
Route::get('/home', 'App\Http\Controllers\Web\HomeController@index')->middleware('multilang')->name('home');

Route::group(['prefix' => 'aljhood', 'middleware' => ['multilang']], function () {

    # handle dynamic routes
    Route::get('{any?}', 'App\Http\Controllers\Web\WebController@index')->where('any', '[\/\w\.-]*');

});

# ajax requests
Route::group(['prefix' => 'ajax'], function () {

    # get gallery contents
    Route::post('getGalleryContent', 'App\Http\Controllers\Web\AjaxController@getGalleryContent');

});

# global search results
Route::get('search/{id?}', 'App\Http\Controllers\Web\WebController@search')->middleware('multilang');
# Compare Courses
Route::get('compare', [\App\Http\Controllers\Web\WebController::class, 'compare'])->middleware('multilang');
# Search Courses
Route::get('filterCourse', [\App\Http\Controllers\Web\WebController::class, 'filterCourse'])->middleware('multilang');
# Search Gallery
Route::get('filterGallery', [\App\Http\Controllers\Web\WebController::class, 'filterGallery'])->middleware('multilang');
# Newsletter Courses
Route::post('newsletter', [\App\Http\Controllers\Web\WebController::class, 'newsletter'])->middleware('multilang');
# Thank You
Route::get('thank-you', function () {
    return view('errors.thank-you');
})->middleware('multilang');;
Route::get('setSession' , [\App\Http\Controllers\Web\WebController::class , 'setSession'])->middleware('multilang');
Route::post('contactForm' , [\App\Http\Controllers\Web\WebController::class , 'contactForm'])->middleware('multilang');
Route::post('joinForm' , [\App\Http\Controllers\Web\WebController::class , 'joinForm'])->middleware('multilang');
Route::post('suggestForm' , [\App\Http\Controllers\Web\WebController::class , 'suggestForm'])->middleware('multilang');
Route::post('teachForm' , [\App\Http\Controllers\Web\WebController::class , 'teachForm'])->middleware('multilang');
Route::post('resellerForm' , [\App\Http\Controllers\Web\WebController::class , 'resellerForm'])->middleware('multilang');
Route::post('applyCourse' , [\App\Http\Controllers\Web\WebController::class , 'courseApplication'])->middleware('multilang');

Route::get('apply-course/{id}' , [\App\Http\Controllers\Web\WebController::class , 'applyToCourse'])->middleware('multilang');
Route::get('course/{id}',[\App\Http\Controllers\Web\WebController::class, 'course'])->middleware('multilang');
Route::get('blog/{id}',[\App\Http\Controllers\Web\WebController::class, 'blog'])->middleware('multilang');
Route::get('news/{id}',[\App\Http\Controllers\Web\WebController::class, 'news'])->middleware('multilang');
Route::get('gallery/{id}',[\App\Http\Controllers\Web\WebController::class, 'gallery'])->middleware('multilang');

Route::get('send-mail' , [\App\Http\Controllers\Web\WebController::class , 'testMail']);
Route::get('emails' , function (){
   return view('emails.responders');
});



