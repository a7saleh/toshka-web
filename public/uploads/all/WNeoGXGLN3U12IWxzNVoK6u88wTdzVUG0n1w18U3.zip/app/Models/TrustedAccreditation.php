<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string $name
 * @property string $name_ar
 * @property string $description
 * @property string $description_ar
 * @property string $image
 * @property string $created_at
 * @property string $updated_at
 * @property string $priority
 */

class TrustedAccreditation extends Model
{
    protected $fillable = ['name','name_ar','description', 'description_ar','image' , 'priority'];
    use HasFactory;
}
