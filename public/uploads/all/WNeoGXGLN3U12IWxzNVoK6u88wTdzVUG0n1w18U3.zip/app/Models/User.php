<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;

/**
 * @property int $id
 * @property int $country_id
 * @property int $role_id
 * @property string $first_name
 * @property string $middle_name
 * @property string $last_name
 * @property string $email
 * @property string $password
 * @property string $mobile_number
 * @property string $mobile_country_code
 * @property string $email_code_verified
 * @property int $is_email_verified
 * @property string $created_at
 * @property string $updated_at
 * @property Country $country
 * @property UserRole $userRole
 * @property News[] $news
 * @property News[] $news
 * @property Page[] $pages
 * @property Page[] $pages
 * @property Testimonial[] $testimonials
 */
class User extends Authenticatable
{
    /**
     * @var array
     */
    protected $fillable = ['country_id', 'role_id', 'first_name', 'middle_name', 'last_name', 'email', 'password', 'mobile_number', 'mobile_country_code', 'email_code_verified', 'is_email_verified', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country()
    {
        return $this->belongsTo('App\Models\Country');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userRole()
    {
        return $this->belongsTo('App\Models\UserRole', 'role_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function createdNews()
    {
        return $this->hasMany('App\Models\News', 'created_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function updatedNews()
    {
        return $this->hasMany('App\Models\News', 'updated_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function createdPages()
    {
        return $this->hasMany('App\Models\Page', 'created_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function updatedPages()
    {
        return $this->hasMany('App\Models\Page', 'updated_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function testimonials()
    {
        return $this->hasMany('App\Models\Testimonial');
    }
}
