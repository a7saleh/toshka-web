<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


/**
 * @property string $title_en
 * @property string $title_ar
 * @property string $description_en
 * @property string $description_ar
 * @property string $image
 * @property string $link
 * @property string $priority
 * @property string $created_at
 * @property string $updated_at
 */

class Banner extends Model
{

    protected $fillable = ['button_file_ar','button_file_en','pdf','button_label_ar','button_label_en','title_en', 'title_ar' ,'description_en', 'description_ar','image','link','priority','video'];
    use HasFactory;
}
