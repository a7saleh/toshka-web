<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $role_id
 * @property int $permission_id
 * @property string $created_at
 * @property string $updated_at
 * @property Permission $permission
 * @property UserRole $userRole
 */
class RolePermission extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['role_id', 'permission_id', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function permission()
    {
        return $this->belongsTo('App\Models\Permission','permission_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userRole()
    {
        return $this->belongsTo('App\Models\UserRole', 'role_id');
    }
}
