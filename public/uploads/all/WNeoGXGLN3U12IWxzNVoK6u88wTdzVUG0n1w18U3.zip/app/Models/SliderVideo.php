<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string $video
 * @property string $created_at
 * @property string $updated_at
 * @property string $priority
 */


class SliderVideo extends Model
{
    protected $fillable = ['video' , 'priority'];
    use HasFactory;
}
