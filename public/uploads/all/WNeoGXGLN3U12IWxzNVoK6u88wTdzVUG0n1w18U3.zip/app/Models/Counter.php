<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


/**
 * @property string $title_en
 * @property string $title_ar
 * @property string $counter
 * @property string $priority
 * @property string $created_at
 * @property string $updated_at
 */

class Counter extends Model
{
    protected $fillable = ['title_en' ,'title_ar' , 'counter', 'priority'];
    use HasFactory;
}
