<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


/**
 * @property int $id
 * @property int $activity_type
 * @property int $activity_type_ar
 * @property string $created_at
 * @property string $updated_at

 */

class ActivityType extends Model

{

    protected $fillable = ['activity_type','activity_type_ar', 'created_at', 'updated_at'];

    use HasFactory;
}
