<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $accreditation
 * @property int $accreditation_ar
 * @property string $created_at
 * @property string $updated_at

 */

class Accreditation extends Model
{
    protected $fillable = ['accreditation','accreditation_ar', 'created_at', 'updated_at'];
    use HasFactory;
}
