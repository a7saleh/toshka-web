<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string $image1
 * @property string $image2
 * @property string $image3
 * @property string $title_en
 * @property string $title_ar
 * @property string $description_en
 * @property string $description_ar
 * @property string $link
 * @property string $priority
 * @property string $created_at
 * @property string $updated_at
 */

class NewsSlider extends Model
{
    protected $fillable = ['news_id','news2_id','news3_id', 'first_title_en', 'first_title_ar' ,'second_title_en', 'second_title_ar' ,'third_title_en', 'third_title_ar', 'image1' , 'image2' , 'image3' , 'priority'];
    use HasFactory;

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function news()
    {
        return $this->belongsTo('App\Models\News', 'news_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function news2()
    {
        return $this->belongsTo('App\Models\News', 'news2_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function news3()
    {
        return $this->belongsTo('App\Models\News', 'news3_id');
    }
}
