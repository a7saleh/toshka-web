<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string $report_type
 * @property string $first_name
 * @property string $last_name
 * @property string $name
 * @property string $email
 * @property string $aria_code
 * @property int $number
 * @property string $country
 * @property string $message
 * @property string $nationality
 * @property string $categories
 * @property string $languages
 * @property string $resume
 * @property string $department
 */

class Report extends Model
{
    protected $fillable = ['report_type','first_name','last_name','name', 'email' , 'area_code','number', 'country' , 'message' , 'nationality', 'categories', 'languages', 'resume', 'department'];
    use HasFactory;
}
