<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $created_by
 * @property int $updated_by
 * @property string $title_en
 * @property string $title_ar
 * @property string $content_en
 * @property string $content_ar
 * @property string $link
 * @property string $date
 * @property string $created_at
 * @property string $updated_at
 * @property string $priority
 * @property User $user
 */
class News extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['video','created_by', 'updated_by', 'title_en', 'title_ar', 'meta_description_en', 'meta_description_ar', 'content_en', 'content_ar', 'file', 'link', 'date', 'breaking_news', 'is_blog', 'explore_more', 'inner_image', 'most_popular', 'latest', 'created_at', 'updated_at', 'priority'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function createdBy()
    {
        return $this->belongsTo('App\Models\User', 'created_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function updatedBy()
    {
        return $this->belongsTo('App\Models\User', 'updated_by');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function blogCourses()
    {
        return $this->hasMany('App\Models\BlogCourse','blog_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function newsSlider()
    {
        return $this->hasMany('App\Models\NewsSlider','news_id');
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function newsSlider2()
    {
        return $this->hasMany('App\Models\NewsSlider','news2_id');
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function newsSlider3()
    {
        return $this->hasMany('App\Models\NewsSlider','news3_id');
    }
}
