<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $course_id
 * @property string $video
 * @property string $created_at
 * @property string $updated_at
 * @property string $priority
 * @property Course $course
 */

class VideoReview extends Model
{

    /**
     * @var array
     */
    protected $fillable = ['course_id', 'video', 'created_at', 'updated_at' , 'priority'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function course()
    {
        return $this->belongsTo('App\Models\Course');
    }
}
