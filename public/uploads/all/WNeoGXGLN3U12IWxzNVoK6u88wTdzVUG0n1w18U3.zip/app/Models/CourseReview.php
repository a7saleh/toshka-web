<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $course_id
 * @property string $person_name
 * @property string $review
 * @property string $stars
 * @property string $created_at
 * @property string $updated_at
 * @property Course $course
 */
class CourseReview extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['course_id', 'person_name', 'review', 'stars', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function course()
    {
        return $this->belongsTo('App\Models\Course');
    }
}
