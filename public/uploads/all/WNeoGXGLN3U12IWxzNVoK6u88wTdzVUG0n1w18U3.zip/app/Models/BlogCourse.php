<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $course_id
 * @property int $blog_id
 * @property string $created_at
 * @property string $updated_at
 * @property Course $course
 * @property News $news
 */

class BlogCourse extends Model
{
    /**
     * @var array
     */

    protected $fillable = ['course_id', 'blog_id', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function course(){
        return $this->belongsTo('App/Models/Course' , 'course_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function blog(){
        return $this->belongsTo('App/Models/News' , 'blog_id');
    }
    use HasFactory;
}
