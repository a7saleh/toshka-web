<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseApplication extends Model
{
    use HasFactory;

    /**
     * @var array
     */

    protected $fillable = ['name_en','birthdate','gender','course_id' , 'name' , 'email' , 'number' , 'country' , 'company' , 'job_title' , 'cv' ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function course(){
        return $this->belongsTo('App\Models\Course' , 'course_id');
    }
}
