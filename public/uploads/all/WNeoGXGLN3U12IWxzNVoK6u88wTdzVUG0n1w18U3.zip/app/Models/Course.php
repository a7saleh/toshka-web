<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $title_en
 * @property string $title_ar
 * @property string $description_en
 * @property string $description_ar
 * @property string $what_you_will_learn
 * @property string $what_you_will_learn_ar
 * @property string $subject_area
 * @property string $subject_area_ar
 * @property string $duration
 * @property string $duration_ar
 * @property string $status
 * @property string $status_ar
 * @property string $skills
 * @property string $skills_ar
 * @property string $course_details
 * @property string $course_details_ar
 * @property string $image
 * @property string $prerequisites
 * @property string $prerequisites_ar
 * @property string $time_commitment
 * @property string $time_commitment_ar
 * @property string $course_language
 * @property string $course_language_ar
 * @property string $activity_type
 * @property string $activity_type_ar
 * @property string $level
 * @property string $level_ar
 * @property string $activity
 * @property string $activity_ar
 * @property string $accreditation
 * @property string $accreditation_ar
 * @property int $is_certified
 * @property int $days
 * @property int $number_modules
 * @property string $contact_number
 * @property string $start_date
 * @property string $course_place
 * @property int $category
 * @property int $types
 * @property string $created_at
 * @property string $updated_at
 * @property string $venue
 * @property string $venue_ar
 * @property string $register_by
 * @property string $video
 * @property string $your_class
 * @property string $your_class_ar
 * @property string $your_class_title
 * @property string $your_class_title_en
 * @property string $your_class_image
 * @property string $priority
 * @property CourseReview[] $courseReviews
 * @property Gallery[] $galleries
 */
class Course extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['details_en','details_ar','b1_ar','b1_en','b2_ar','b2_en','b3_ar','b3_en','title_en','inner_image','title_ar', 'description_en', 'description_ar', 'what_you_will_learn', 'what_you_will_learn_ar', 'subject_area', 'subject_area_ar', 'duration', 'duration_ar', 'status', 'status_ar', 'skills', 'skills_ar', 'course_details', 'course_details_ar', 'image', 'prerequisites', 'prerequisites_ar', 'time_commitment', 'time_commitment_ar', 'course_language', 'course_language_ar', 'activity_type', 'activity_type_ar', 'level', 'level_ar', 'activity', 'activity_ar', 'accreditation', 'accreditation_ar', 'is_certified', 'days', 'number_modules', 'contact_number', 'start_date', 'course_place', 'category', 'types', 'created_at', 'updated_at', 'venue', 'venue_ar', 'register_by', 'video', 'your_class', 'your_class_ar', 'your_class_image', 'your_class_title', 'your_class_title_ar', 'priority', 'brochure', 'is_hidden'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function courseReviews()
    {
        return $this->hasMany('App\Models\CourseReview');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function galleries()
    {
        return $this->hasMany('App\Models\Gallery');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function blogCourses()
    {
        return $this->hasMany('App\Models\BlogCourse', 'course_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function courseApplications()
    {
        return $this->hasMany('App\Models\CourseApplication', 'course_id');
    }

    public function scopeFilter($query, $subject_area_request, $venue_request, $date_request, $activity_type_request, $accreditation_request)
    {
        $filter = $query->where('is_hidden', 0)
            ->when($subject_area_request, function ($query) use ($subject_area_request) {
                $query->where('subject_area', $subject_area_request);
            })
            ->when($venue_request, function ($query) use ($venue_request) {
                $query->where('venue', $venue_request);
            })
            ->when($date_request, function ($query) use ($date_request) {
                $query->where('start_date', '>=', Carbon::now())->where('start_date', $date_request);
            })
            ->when($activity_type_request, function ($query) use ($activity_type_request) {
                $query->where('activity_type', $activity_type_request);
            })
            ->when($accreditation_request, function ($query) use ($accreditation_request) {
                $query->where('accreditation', $accreditation_request);
            })->get();
        dd($filter);
        return $filter;
    }
}
