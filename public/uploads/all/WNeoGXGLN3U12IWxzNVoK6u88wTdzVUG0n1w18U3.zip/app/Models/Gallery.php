<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $course_id
 * @property string $title_en
 * @property string $title_ar
 * @property string $description_en
 * @property string $description_ar
 * @property string $created_at
 * @property string $updated_at
 * @property int $other
 * @property string $date
 * @property string $priority
 * @property Course $course
 */
class Gallery extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['video', 'title_en', 'title_ar', 'files', 'cover_photo', 'location_id', 'description_en', 'description_ar', 'other', 'date', 'created_at', 'updated_at', 'priority'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function course()
    {
        return $this->belongsTo('App\Models\Course');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function location()
    {
        return $this->belongsTo('App\Models\Country', 'location_id');
    }

}
