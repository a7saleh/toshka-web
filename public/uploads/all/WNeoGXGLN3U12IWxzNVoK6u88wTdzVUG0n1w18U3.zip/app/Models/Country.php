<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $country_name
 * @property string $country_name_ar
 * @property string $country_iso_two_code
 * @property string $country_iso_three_code
 * @property string $created_at
 * @property string $updated_at
 * @property MobileCountryCode[] $mobileCountryCodes
 * @property User[] $users
 */
class Country extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['country_name', 'country_name_ar', 'country_iso_two_code', 'country_iso_three_code', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function mobileCountryCodes()
    {
        return $this->hasMany('App\Models\MobileCountryCode');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function users()
    {
        return $this->hasMany('App\Models\User');
    }
}
