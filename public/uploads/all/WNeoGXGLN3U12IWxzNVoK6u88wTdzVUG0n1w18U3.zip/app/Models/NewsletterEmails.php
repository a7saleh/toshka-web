<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


/**
 * @property int $id
 * @property string $email
 * @property string $created_by
 * @property string $updated_by
 */

class NewsletterEmails extends Model
{

    protected $fillable = ['email', 'created_at', 'updated_at'];
    use HasFactory;


}
