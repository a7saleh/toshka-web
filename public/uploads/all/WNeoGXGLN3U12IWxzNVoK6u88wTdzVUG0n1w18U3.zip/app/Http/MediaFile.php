<?php

namespace App\Http;

use Illuminate\Support\Facades\Storage;

Class MediaFile{

    private static $obj = null;

    private function __construct()
    {
    }

    public static function singleObject()
    {
        if(self::$obj == null){
            self::$obj = new MediaFile();
        }
        return self::$obj;
    }

    private static $allowed_types =
    ['png', 'jpg', 'jpeg', 'gif', 'mp4', 'mov', 'pdf', 'docx', 'doc', 'xls', 'xlsx' , 'csv', 'rar', 'zip', 'tar'];


    public function  uploadFile($file,$folder){

        try{
            if(in_array($file->extension(),self::$allowed_types)){

                $filename = time().'.'. $file->getClientOriginalExtension();

                $path=$file->move(public_path().'/storage/uploads/'.$folder.'/', $filename);

                return $filename;
            }
            elseif (!in_array($file->extension(),self::$allowed_types)){
                return "This file type is not supported";
            }
            else{
                return "";
            }
        }
        catch (Exception $e){
            report($e);
            return $e->getMessage();
        }

    }

    public function uploadMultipleFiles($files,$folder){

        try{


            $MFiles = array();
            $count=0;
            foreach ($files as $key => $file){
            $count++;
                if(in_array($file->extension(),self::$allowed_types)){

                    $filename =$count.time() . $key . '.' . $file->getClientOriginalExtension();

                    $path=$file->move(public_path().'/storage/uploads/'.$folder.'/', $filename);
                    $MFiles[] = $filename;
                }
                elseif (!in_array($file->extension(),self::$allowed_types)){
                    return "This file type is not supported";
                }
                else{
                    return "";
                }
            }

            return $MFiles;
        }
        catch (Exception $e){
            report($e);
            return $e->getMessage();
        }

    }
}
