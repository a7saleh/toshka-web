<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CourseApplication;
use App\Models\Report;
use Carbon\Traits\Creator;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function contactReport(){
        $reports = Report::select('id','name','email','message' , 'created_at')->where('report_type' , 'contact')->orderBy('id' , 'desc')->get();
//        return $reports;
        return view(' admin.reports.contact')->with('reports' , $reports);
    }

    public function joinReport(){
        $reports = Report::select('id','first_name','last_name','area_code','number','email','department' , 'resume' ,'created_at')->where('report_type' , 'join')->orderBy('id' , 'desc')->get();
        return view('admin.reports.join')->with('reports' , $reports);
    }

    public function suggestReport(){
        $reports = Report::select('id','first_name','last_name','number','email','country' , 'message' , 'created_at')->where('report_type' , 'suggest')->orderBy('id' , 'desc')->get();
        return view('admin.reports.suggest')->with('reports' , $reports);
    }

    public function teachReport(){
        $reports = Report::select('id','first_name','last_name', 'number','email', 'country' ,'nationality', 'categories','languages','resume' , 'message' , 'created_at')->where('report_type' , 'teach')->orderBy('id' , 'desc')->get();
        return view('admin.reports.teach')->with('reports' , $reports);
    }

    public function resellerReport(){
        $reports = Report::select('id','first_name','last_name','number','email','country' , 'message' , 'created_at')->where('report_type' , 'reseller')->orderBy('id' , 'desc')->get();
        return view('admin.reports.reseller')->with('reports' , $reports);
    }


    public function filterContactReport(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $reports = Report::select('id','name','email','message' , 'created_at')->where('report_type' , 'contact')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view(' admin.reports.contact')->with('reports' , $reports)->with('first_date' , $date1)->with('second_date' , $date2);
    }

    public function filterJoinReport(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $reports = Report::select('id','first_name','last_name','area_code','number','email','department' , 'resume' ,'created_at')->where('report_type' , 'join')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view(' admin.reports.join')->with('reports' , $reports)->with('first_date' , $date1)->with('second_date' , $date2);
    }


    public function filterSuggestReport(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $reports = Report::select('id','first_name','last_name','number','email','country' , 'message' , 'created_at')->where('report_type' , 'suggest')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view(' admin.reports.suggest')->with('reports' , $reports)->with('first_date' , $date1)->with('second_date' , $date2);
    }


    public function filterTeachReport(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $reports = Report::select('id','first_name','last_name', 'number','email', 'country' ,'nationality', 'categories','languages','resume' , 'message' , 'created_at')->where('report_type' , 'teach')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view(' admin.reports.teach')->with('reports' , $reports)->with('first_date' , $date1)->with('second_date' , $date2);
    }


    public function filterResellerReport(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $reports = Report::select('id','first_name','last_name','number','email','country' , 'message' , 'created_at')->where('report_type' , 'reseller')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view(' admin.reports.reseller')->with('reports' , $reports)->with('first_date' , $date1)->with('second_date' , $date2);
    }

    public function filterCourseApplication(Request $request){
        $date1 = $request->first_date;
        $date2 = $request->second_date;
        $first_date = new Carbon($date1);
        $second_date = new Carbon($date2);
        $applications = CourseApplication::with('course')->whereBetween('created_at', [$first_date->format('Y-m-d')." 00:00:00", $second_date->format('Y-m-d')." 23:59:59"])->get();
        return view('admin.course-application.index')->with('applications',$applications)->with('first_date' , $date1)->with('second_date' , $date2);

    }
}
