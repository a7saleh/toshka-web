<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Counter;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Validator;
use \Exception;
use DB;

class MenuController extends Controller
{
    public function index(){

        try {
            $data=[];
            $menus = DB::table('menu')->where('parent_id','=',0)->orderBy('element_order','asc')->get();
            foreach($menus as $menu){
            $submenu = DB::table('menu')->where('parent_id','=',$menu->id)->orderBy('element_order','asc')->get();
            if($submenu)
            $menu->submenu=$submenu;
            
            array_push($data,$menu);
            }
            $menus=$data;
            return view('admin.home-page.menu')->with('menus',$menus);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {
            $menus = DB::table('menu')->where('id','=',$id)->first();
            $parents = DB::table('menu')->where('id','!=',$id)->where('parent_id','=',0)->get();
            return view('admin.home-page.edit-menu')->with(['counter'=> $menus,'parents'=>$parents]);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

           $parents = DB::table('menu')->where('id','=',$id)->update([
               'name_ar'=>$request->name_ar,
               'name_en'=>$request->name_en,
               'parent_id'=>$request->parent_id,
               'element_order'=>$request->element_order,
               'url'=>$request->url,
               'status'=>$request->status,
               ]);

            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('menu.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }
        public function create()
    {
        try {
            $parents = DB::table('menu')->where('parent_id','=',0)->get();
            return view('admin.home-page.create_menu')->with('parents',$parents);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

           $parents = DB::table('menu')->insert([
               'name_ar'=>$request->name_ar,
               'name_en'=>$request->name_en,
               'parent_id'=>$request->parent_id,
               'element_order'=>$request->element_order,
               'url'=>$request->url,
               'status'=>$request->status,
               ]);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('menu.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

}
