<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\PageContent;
use Illuminate\Http\Request;
use Validator;
use \Exception;

class PrivacyPolicyController extends Controller
{
    public function index(){

        try {

            $contents = PageContent::where('ref_page' , 'privacy-policy')->orderBy('id' , 'desc')->get();


            return view('admin.privacy-policy.index')->with('contents',$contents);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function create()
    {
        try {

            return view('admin.privacy-policy.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {


            $providedData = $request->all();

            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/page-contents/', $filename);
            $providedData['image'] = $filename;
            }            

            PageContent::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('privacy-policy.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $content = PageContent::findOrFail($id);
            return view('admin.privacy-policy.edit')->with('content', $content);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $providedData = $request->all();

            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/page-contents/', $filename);
            $providedData['image'] = $filename;
            }  
            
            $content = PageContent::findOrFail($id);

            $content->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('privacy-policy.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $content = PageContent::find($id);
            $content->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('privacy-policy.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
