<?php

namespace App\Http\Controllers\Admin;

use App\Models\BlogCourse;
use App\Models\Course;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\News;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use App\Http\MediaFile;
use Validator;

/**
 * News
 */
class NewsController extends Controller
{

    public function index(){

        try {

            $array1 = News::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->get();
            $array2 = News::where('priority' , null)->orderBy('id' , 'desc')->get();

//            $news = News::orderBy('id' , 'desc')->get();
            $news = Array();
            foreach ($array1 as $arr){
                array_push($news , $arr);
            }
            foreach ($array2 as $arr){
                array_push($news , $arr);
            }
            return view('admin.news.index')->with('news',$news);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            $related_courses = Course::all();

            return view('admin.news.create')->with('related_courses' , $related_courses);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required|string',
                'title_ar'   => 'required|string',
                'content_en' => 'required',
                'content_ar' => 'required',
                'file'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if($request->file('inner_image') != null){
            $file=$request->file('inner_image');
            $filename_inner_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/news/', $filename_inner_image);
            $providedData['inner_image'] = $filename_inner_image;
            }
            
            if($request->file('file') != null){
            $file=$request->file('file');
            $filename_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/news/', $filename_image);
            $providedData['file'] = $filename_image;
            }
            

            $providedData['is_blog'] = ($request->input('is_blog') != null) ? $request->input('is_blog') : 0;
            $providedData['explore_more'] = ($request->input('explore_more') != null && $request->input('is_blog') != null) ? $request->input('explore_more') : 0;
            $providedData['most_popular'] = ($request->input('most_popular') != null && $request->input('is_blog') != null) ? $request->input('most_popular') : 0;
            $providedData['latest'] = ($request->input('latest') != null && $request->input('is_blog') != null) ? $request->input('latest') : 0;
            $providedData['breaking_news'] = ($request->input('breaking_news') != null && $request->input('is_blog') == null) ? $request->input('breaking_news') : 0;

            $providedData['created_by'] = Auth::id();
            if ( $providedData['is_blog'] == 1){
                $blog = News::create($providedData);
                if (!empty($providedData['related_courses'])){
                    foreach ($providedData['related_courses'] as $course){
                        $blog_course = New BlogCourse;
                        $blog_course->course_id = $course;
                        $blog_course->blog_id = $blog->id;
                        $blog_course->save();
                    }
                }

            }else{
                News::create($providedData);
            }


            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('news.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {

        try {

           $this->id = $id;
            $related_courses = Course::all();
            $selected_courses = Course::with('blogCourses')->whereHas('blogCourses' , function ($query){
                $query->where('blog_id' , $this->id);
            })->get();




            $new = News::findOrFail($id);
            return view('admin.news.edit')->with('new', $new)->with('related_courses' , $related_courses)->with('selected_courses' , $selected_courses);

        } catch (Exception $e) {
            report($e);
//            return redirect('somethingwrong');
            return $e;
        }
    }

    public function update(Request $request,$id)
    {

        try {

            $validateForm = Validator::make($request->all(),[
                'title_en' => 'required|string',
                'title_ar' => 'required|string',
                'content_en' => 'required',
                'content_ar' => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
//            return $providedData['is_blog'];



            if($request->file('file') != null){
            $file=$request->file('file');
            $filename_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/news/', $filename_image);
            $providedData['file'] = $filename_image;
            }            

            $providedData['is_blog'] = ($request->input('is_blog') != null) ? $request->input('is_blog') : 0;
            $providedData['explore_more'] = ($request->input('explore_more') != null && $request->input('is_blog') != null) ? $request->input('explore_more') : 0;
            $providedData['most_popular'] = ($request->input('most_popular') != null && $request->input('is_blog') != null) ? $request->input('most_popular') : 0;
            $providedData['latest'] = ($request->input('latest') != null && $request->input('is_blog') != null) ? $request->input('latest') : 0;
            $providedData['breaking_news'] = ($request->input('breaking_news') != null && $request->input('is_blog') == null) ? $request->input('breaking_news') : 0;

            $providedData['updated_by'] = Auth::id();

            if($request->file('inner_image') != null){
            $file=$request->file('inner_image');
            $filename_inner_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/news/', $filename_inner_image);
            $providedData['inner_image'] = $filename_inner_image;
            }
            
            $new = News::findOrFail($id);
            $course_blog =  BlogCourse::where('blog_id' , $id)->first();
//            return $course_blog;
            if ( $providedData['is_blog'] == 1){
                if ($course_blog == null){
                    if (!empty($providedData['related_courses'])){
                        foreach ($providedData['related_courses'] as $course){
                            $blog_course = New BlogCourse;
                            $blog_course->course_id = $course;
                            $blog_course->blog_id = $new->id;
                            $blog_course->save();
                        }
                    }
                    $new->fill($providedData)->save();
                }else {
                    if (!empty($providedData['related_courses'])){
                        BlogCourse::where('blog_id' , $id)->delete();
                        if (!empty($providedData['related_courses'])){
                            foreach ($providedData['related_courses'] as $course){
                                $blog_course = New BlogCourse;
                                $blog_course->course_id = $course;
                                $blog_course->blog_id = $new->id;
                                $blog_course->save();
                            }
                        }

                        $new->fill($providedData)->save();
                    }else{
                        $course_blog->delete();
                        $new->fill($providedData)->save();
                    }
                }

            }else{
                if (!empty($providedData['related_courses'])){
                    BlogCourse::where('blog_id' , $id)->delete();
                }
                $new->fill($providedData)->save();
            }



            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('news.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
            //return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $new = News::find($id);
            $new->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('news.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
