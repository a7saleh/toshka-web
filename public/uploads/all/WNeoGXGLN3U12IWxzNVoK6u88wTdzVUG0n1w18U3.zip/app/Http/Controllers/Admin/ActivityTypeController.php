<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityType;
use Illuminate\Http\Request;
use Validator;

class ActivityTypeController extends Controller
{
    public function index(){

        try {

            $activity_type = ActivityType::orderBy('id' , 'desc')->get();

            return view('admin.courses.activity')->with('activity_type',$activity_type);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.courses.create-activity');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'activity_type'   => 'required|string',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            ActivityType::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('activity.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $activity_type = ActivityType::findOrFail($id);
            return view('admin.courses.edit-activity')->with('activity_type', $activity_type);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'activity_type'   => 'required|string',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $activity_type = ActivityType::findOrFail($id);

            $activity_type->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('activity.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $activity_type = ActivityType::find($id);
            $activity_type->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('activity.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
