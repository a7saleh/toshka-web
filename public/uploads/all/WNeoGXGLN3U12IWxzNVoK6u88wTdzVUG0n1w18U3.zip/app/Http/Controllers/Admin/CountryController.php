<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \Exception;
use \Validator;
use \Session;
use App\Models\Country;

/**
 * Country Controller
 */
class CountryController extends Controller
{

	public function index()
	{
		try {

			$countries = Country::orderBy('id' , 'desc')->get();
			return view('admin.countries.index',['countries' => $countries]);

		} catch (Exception $e) {
			report($e);
			return redirect('somethingwrong');
		}
	}

    public function create()
    {
        try {

            return view('admin.countries.create');
        }
        catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

             $validateForm = Validator::make($request->all(), [
                'country_name' => 'required',
                'country_name_ar' => ['required'],
                'country_iso_two_code'   => ['required'],
                'country_iso_three_code'   => ['required'],
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $country = Country::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('countries.index');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function edit($id)
    {
        try {

            $country = Country::findOrFail($id);
            return view('admin.countries.edit',['country' => $country]);
        }
        catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request, $id)
    {
    	try {

            $validateForm = Validator::make($request->all(), [
                'country_name' => 'required',
                'country_name_ar' => ['required'],
                'country_iso_two_code'   => ['required'],
                'country_iso_three_code'   => ['required'],
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $country = Country::findOrFail($id);
            $country->fill($providedData)->save();

            session()->flash('success', trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('countries.index');

    	} catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $country = Country::find($id);
            $country->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('countries.index');

        } catch (Exception $e) {
            return $e->getMessage();
            report($e);
            return redirect('somethingwrong');

        }
    }

}
