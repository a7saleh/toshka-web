<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use \Exception;


class MediaCenterController extends Controller
{
    public function index(){

        try {

            $videos = SliderVideo::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
            $testimonials = Testimonial::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();

            return view('admin.home-page.media-center')->with('videos',$videos)->with('testimonials' , $testimonials);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.home-page.create-slider-video');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'video'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            SliderVideo::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('media_center.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $video = SliderVideo::findOrFail($id);
            return view('admin.home-page.edit-slider-video')->with('video', $video);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'video'   => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $video = SliderVideo::findOrFail($id);

            $video->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('media_center.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $video = SliderVideo::find($id);
            $video->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('media_center.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
