<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\PageContent;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Validator;
use DB;
/**
 * create dynamic page
 */
class TitlesController extends Controller
{

    public function index(){

        try {

            $contents = DB::table('page_contents')->where('priority','=','700')->get();
            return view('admin.titles.index')->with('contents',$contents);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.titles.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $providedData = $request->all();
            $providedData['created_by'] = Auth::id();
            PageContent::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('titles.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $content= DB::table('page_contents')->where('id','=',$id)->first();
            return view('admin.titles.edit')->with('content', $content);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {



            $providedData = $request->all();
            $providedData['updated_by'] = Auth::id();
            $page = PageContent::findOrFail($id);

            $page->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('titles.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $page = PageContent::find($id);
            $page->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('titles.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
