<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CourseApplication;
use Illuminate\Http\Request;
use App\Models\Course;
class CourseApplicationController extends Controller
{
    public function index(){

        try {

            $applications = CourseApplication::with('course')->orderBy('id','desc')->get();
//            return $applications[0]->course->title_en;

            return view('admin.course-application.index')->with('applications',$applications);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }
}
