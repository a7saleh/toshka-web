<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Validator;

/**
 * create dynamic page
 */
class PageController extends Controller
{

    public function index(){

        try {

            $pages = Page::orderBy('id' , 'desc')->get();
            return view('admin.pages.index')->with('pages',$pages);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.pages.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'page_name_en' => 'required|string',
                'page_name_ar' => 'required|string',
                'content_en' => 'required',
                'content_ar' => 'required',
                'slug' => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $providedData['created_by'] = Auth::id();
            Page::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('pages.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $page = Page::findOrFail($id);
            return view('admin.pages.edit')->with('page', $page);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'page_name_en' => 'required|string',
                'page_name_ar' => 'required|string',
                'content_en' => 'required',
                'content_ar' => 'required',
                'slug' => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $providedData['updated_by'] = Auth::id();
            $page = Page::findOrFail($id);

            $page->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('pages.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $page = Page::find($id);
            $page->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('pages.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
