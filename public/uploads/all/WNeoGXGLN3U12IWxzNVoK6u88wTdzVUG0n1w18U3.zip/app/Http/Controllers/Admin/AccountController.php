<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \Exception;
use \Validator;
use \Session;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

/**
 * Auth Controller [auth]
 */
class AccountController extends Controller
{

	public function login(Request $request){

		try {   

			$validateForm = Validator::make($request->all(),[
				'email' => 'required|email|string',
				'password' => 'required|string'
			]);

			if($validateForm->fails()){

				session()->flash('errors', $validateForm->errors());
				return redirect('admin/secure');
			}


			$email = $request->input('email');
			$password = $request->input('password');

			if(Auth::attempt(['email' => $email , 'password' => $password])){

				return redirect(url('admin/home'));

			}else{

				session()->flash('error', 'Incorrect username or password');
				return redirect('admin/secure');
			}

		} catch (Exception $e) {

			report($e);
			return $e->getMessage();
		}
	}

	public function logout(){

		Session::flush(); // remove session
		return redirect('admin/secure');
	}
}
