<?php

namespace App\Http\Controllers\Admin;

use App\Models\Accreditation;
use App\Models\ActivityType;
use App\Models\SubjectArea;
use App\Models\TrustedAccreditation;
use App\Models\Venue;
use App\Models\PageContent;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Course;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use App\Http\MediaFile;
use Validator;

/**
 * Courses
 */
class CourseController extends Controller
{

    public function index(){

        try {

            $array1 = Course::where('priority' , '!=' , null)->where('is_hidden' , 0)->orderBy('priority' , 'asc')->get();
            $array2 = Course::where('priority' , null)->where('is_hidden' , 0)->orderBy('id' , 'desc')->get();
            $array3 = Course::where('priority' , '!=' , null)->where('is_hidden' , 1)->orderBy('priority' , 'asc')->get();
            $array4 = Course::where('priority' , null)->where('is_hidden' , 1)->orderBy('id' , 'desc')->get();


            $courses = Array();
            foreach ($array1 as $arr){
                array_push($courses , $arr);
            }
            foreach ($array2 as $arr){
                array_push($courses , $arr);
            }
            foreach ($array3 as $arr){
                array_push($courses , $arr);
            }
            foreach ($array4 as $arr){
                array_push($courses , $arr);
            }
//            $courses = Course::orderBy('id' , 'desc')->get();
//            return $courses;
            return view('admin.courses.index')->with('courses',$courses);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            $subject_area = SubjectArea::all();
            $venue = Venue::all();
            $activity_type = ActivityType::all();
            $accreditation = TrustedAccreditation::all();
            return view('admin.courses.create')
                ->with('subject_area' , $subject_area)
                ->with('venue' , $venue)
                ->with('activity_type' , $activity_type)
                ->with('accreditation' , $accreditation);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {


            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required|string',
                'title_ar'   => 'required|string',
                'duration' => 'required',
                'image'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            if($request->file('inner_image') != null){
            $file=$request->file('inner_image');
            $filename_inner_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/courses/', $filename_inner_image);
            $providedData['inner_image'] = $filename_inner_image;
            }
            
            $subject_area = [];


            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/courses/', $filename_image);
            $providedData['image'] = $filename_image;
            }
            $filename_image1="";
            if($request->file('your_class_image') != null){
            $file=$request->file('your_class_image');
            $filename_image1 = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/your_class/', $filename_image1);
            $providedData['your_class_image'] = $filename_image1;
            }


            if($request->file('brochure')){

                $image = $request->file('brochure');
                $image_name = time(). '.' . $image->getClientOriginalExtension();
                $destinationPath = $image->move(public_path().'/storage/uploads/course-brochure', $image_name);
                $providedData['brochure'] = $image_name;

            }

            $providedData['description_en'] = ( $request->input('description_en') == '<p>&nbsp;</p>' ) ? null : $request->input('description_en');
            $providedData['description_ar'] = ( $request->input('description_ar') == '<p>&nbsp;</p>' ) ? null : $request->input('description_ar');
            $providedData['what_you_will_learn'] = ( $request->input('what_you_will_learn') == '<p>&nbsp;</p>' ) ? null : $request->input('what_you_will_learn');
            $providedData['course_details'] = ( $request->input('course_details') == '<p>&nbsp;</p>' ) ? null : $request->input('course_details');
            $providedData['prerequisites'] = ( $request->input('prerequisites') == '<p>&nbsp;</p>' ) ? null : $request->input('prerequisites');

            $array_to_string = implode(',',$providedData['subject_area']);
            $providedData['subject_area'] = $array_to_string;

            $array_to_string2 = implode(',',$providedData['venue']);
            $providedData['venue'] = $array_to_string2;

            $array_to_string3 = implode(',',$providedData['subject_area_ar']);
            $providedData['subject_area_ar'] = $array_to_string3;

            $array_to_string4 = implode(',',$providedData['venue_ar']);
            $providedData['venue_ar'] = $array_to_string4;

            $providedData['is_certified'] = ($request->input('is_certified') != null) ? $request->input('is_certified') : 0;
            $providedData['your_class_image'] = $filename_image1;

            Course::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('courses.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $course = Course::findOrFail($id);
            $subject_area = SubjectArea::all();
            $selected_subject_area = explode(',' , $course->subject_area);
            $selected_subject_area_ar = explode(',' , $course->subject_area_ar);
            $venue = Venue::all();
            $selected_venue = explode(',' , $course->venue);
            $selected_venue_ar = explode(',' , $course->venue_ar);
//            return $selected_venue;
            $activity_type = ActivityType::all();
            $accreditation = TrustedAccreditation::all();
            return view('admin.courses.edit')->with('course', $course)
                ->with('subject_area' , $subject_area)
                ->with('venue' , $venue)
                ->with('activity_type' , $activity_type)
                ->with('accreditation' , $accreditation)
                ->with('selected_venues' , $selected_venue)
                ->with('selected_venues_ar' , $selected_venue_ar)
                ->with('selected_subjects', $selected_subject_area)
                ->with('selected_subjects_ar', $selected_subject_area_ar);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        
            if($request->icons != null){
            $providedData = $request->all();
            $providedData['image'] = $request->image;
            
            $content = PageContent::findOrFail($id);

            $content->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('courses.index');
            }

        
        
        try {


            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required',
                'title_ar'   => 'required',
                'duration' => 'required',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }


            $providedData = $request->all();
//            return $providedData['subject_area'];

            if($request->file('inner_image') != null){
            $file=$request->file('inner_image');
            $filename_inner_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/courses/', $filename_inner_image);
            $providedData['inner_image'] = $filename_inner_image;
            }

            if($request->file('image') != null){
            $file=$request->file('image');
            $filename_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/courses/', $filename_image);
            $providedData['image'] = $filename_image;
            }
            
            if($request->file('your_class_image') != null){
            $file=$request->file('your_class_image');
            $filename_image = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/your_class/', $filename_image);
            $providedData['your_class_image'] = $filename_image;
            }


            if($request->file('brochure')) {

                $image = $request->file('brochure');
                $image_name = time(). '.' . $image->getClientOriginalExtension();
                $destinationPath = $image->move(public_path().'/storage/uploads/course-brochure', $image_name);
                $providedData['brochure'] = $image_name;

            }

            $providedData['description_en'] = ( $request->input('description_en') == '<p>&nbsp;</p>' ) ? null : $request->input('description_en');
            $providedData['description_ar'] = ( $request->input('description_ar') == '<p>&nbsp;</p>' ) ? null : $request->input('description_ar');
            $providedData['what_you_will_learn'] = ( $request->input('what_you_will_learn') == '<p>&nbsp;</p>' ) ? null : $request->input('what_you_will_learn');
            $providedData['course_details'] = ( $request->input('course_details') == '<p>&nbsp;</p>' ) ? null : $request->input('course_details');
            $providedData['prerequisites'] = ( $request->input('prerequisites') == '<p>&nbsp;</p>' ) ? null : $request->input('prerequisites');

            $array_to_string = implode(',',$providedData['subject_area']);
            $providedData['subject_area'] = $array_to_string;

            $array_to_string2 = implode(',',$providedData['venue']);
            $providedData['venue'] = $array_to_string2;

            $array_to_string3 = implode(',',$providedData['subject_area_ar']);
            $providedData['subject_area_ar'] = $array_to_string3;

            $array_to_string4 = implode(',',$providedData['venue_ar']);
            $providedData['venue_ar'] = $array_to_string4;


//            $array_to_string = implode(',',$providedData['subject_area']);
//            $providedData['subject_area'] = $array_to_string;
//
//            $array_to_string2 = implode(',',$providedData['venue']);
//            $providedData['venue'] = $array_to_string2;


            $providedData['is_certified'] = ($request->input('is_certified') != null) ? $request->input('is_certified') : 0;

            $course = Course::findOrFail($id);

            $course->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('courses.index');

        } catch (Exception $e) {
            report($e);
            return $e;
        }
    }

    public function destroy($id)
    {
        try {

            $course = Course::find($id);
            $course->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('courses.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

    public function hide(Request $request , $id){
        try {

//            return $request->all();
            $validateForm = Validator::make($request->all(),[
                'is_hidden'   => 'required',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $is_hidden = $request->all();
            $course = Course::findOrFail($id);

            $course->fill($is_hidden)->save();

            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('courses.index');
        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
