<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \Exception;
use \Validator;
use \Session;
use App\Models\Country;
use App\Models\MobileCountryCode;

/**
 * MobileCountryCode
 */
class MobileCountryCodeController extends Controller
{
	
	public function index()
	{
		try {

			$mobilecountrycodes = MobileCountryCode::all();
			return view('admin.mobilecountrycodes.index',
			['mobilecountrycodes' => $mobilecountrycodes]);
			
		} catch (Exception $e) {
			report($e);
			return redirect('somethingwrong');
		}
	}

    public function create()
    {
        try {

        	$countries = Country::all();
            return view('admin.mobilecountrycodes.create',['countries' => $countries]);
        }
        catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

             $validateForm = Validator::make($request->all(), [
                'mob_country_code' => 'required',
                'country_id' => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $MobileCountryCode = MobileCountryCode::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('mobilecountrycodes.index');
            
        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function edit($id)
    {
        try {

        	$countries = Country::all();
            $MobileCountryCode = MobileCountryCode::findOrFail($id);
            return view('admin.mobilecountrycodes.edit',
            ['MobileCountryCode' => $MobileCountryCode, 'countries' => $countries]);
        }
        catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request, $id)
    {
    	try {

            $validateForm = Validator::make($request->all(), [
                'mob_country_code' => 'required',
                'country_id' => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            $MobileCountryCode = MobileCountryCode::findOrFail($id);
            $MobileCountryCode->fill($providedData)->save();

            session()->flash('success', trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('mobilecountrycodes.index');
    		
    	} catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');    	
        }
    }

    public function destroy($id)
    {
        try {

            $MobileCountryCode = MobileCountryCode::find($id);
            $MobileCountryCode->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('mobilecountrycodes.index');
            
        } catch (Exception $e) {
            return $e->getMessage();
            report($e);
            return redirect('somethingwrong');

        }
    }
}