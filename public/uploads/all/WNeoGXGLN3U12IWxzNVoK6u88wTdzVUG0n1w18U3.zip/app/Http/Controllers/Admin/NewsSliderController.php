<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\News;
use App\Models\NewsSlider;
use Illuminate\Http\Request;
use Validator;
use \Exception;
use \DB;

class NewsSliderController extends Controller
{
    public function index(){

        try {

            $news_slider = NewsSlider::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();


            return view('admin.news-slider.index')->with('news_slider',$news_slider);

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {
            $news = News::where('is_blog' , 0)->get();

            return view('admin.news-slider.create')->with('news' , $news);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'image1'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG',
                'image2'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG',
                'image3'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }


            $providedData = $request->all();

            
            if($request->file('image1') != null){
            $file=$request->file('image1');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image1'] = $filename;
            }
            if($request->file('image2') != null){
            $file=$request->file('image2');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image2'] = $filename;
            }
            if($request->file('image3') != null){
            $file=$request->file('image3');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image3'] = $filename;
            }
            
            NewsSlider::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('newsSlider.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $news_slider = NewsSlider::findOrFail($id);
            $n1 = $news_slider->news_id;
            $n2 = $news_slider->news2_id;
            $n3 = $news_slider->news3_id;
            $news = News::where('is_blog' , 0)->get();
            $news1 = News::where('id' , $n1)->get();
            $news2 = News::where('id' , $n2)->get();
            $news3 = News::where('id' , $n3)->get();
//            return $news1[0]->title_en;
            return view('admin.news-slider.edit')->with('news_slider', $news_slider)->with('news' , $news)
                ->with('news1' , $news1)
                ->with('news2' , $news2)
                ->with('news3' , $news3);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {





            $providedData = $request->all();

            if($request->file('image1') != null){
            $file=$request->file('image1');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image1'] = $filename;
            }
            if($request->file('image2') != null){
            $file=$request->file('image2');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image2'] = $filename;
            }
            if($request->file('image3') != null){
            $file=$request->file('image3');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/newsSlider/', $filename);
            $providedData['image3'] = $filename;
            }


            $news_slider = NewsSlider::findOrFail($id);

            $news_slider->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('newsSlider.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $news_slider = NewsSlider::find($id);
            $news_slider->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('newsSlider.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
