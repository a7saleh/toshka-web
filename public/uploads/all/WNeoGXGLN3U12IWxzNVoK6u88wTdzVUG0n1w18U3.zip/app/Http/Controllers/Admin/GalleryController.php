<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Gallery;
use App\Models\Course;
use App\Models\Country;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use App\Http\MediaFile;
use Validator;

/**
 * gallery
 */
class GalleryController extends Controller
{

    public function index(){

        try {

            $array1 = Gallery::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->get();
            $array2 = Gallery::where('priority' , null)->orderBy('id' , 'desc')->get();
            $gallery = Array();
            foreach ($array1 as $arr){
                array_push($gallery , $arr);
            }
            foreach ($array2 as $arr){
                array_push($gallery , $arr);
            }
//            $gallery = Gallery::orderBy('id' , 'desc')->get();
            return view('admin.gallery.index')->with('gallery',$gallery);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            $locations = Country::all();
            $courses = Course::all();
            return view('admin.gallery.create')
            ->with('locations',$locations)
            ->with('courses',$courses);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

     public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required|string',
                'title_ar'   => 'required|string'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }


            $providedData = $request->all();


            if ($providedData['course_id'] == 'other'){
                $providedData['course_id'] = null;
            }

            $filenames = [];
            $cover_photo = '';

            if($request->file('files') != null){
                $filenames = MediaFile::singleObject()->uploadMultipleFiles($request->file('files'),'gallery');
	            $providedData['files'] = implode(',',$filenames);
            }

            if($request->file('cover_photo') != null){
            $file=$request->file('cover_photo');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/gallery/', $filename);
            $providedData['cover_photo'] = $filename;
            }

             $address = implode(",", array_filter($filenames));


            Gallery::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('gallery.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $locations = Country::all();
            $gallery = Gallery::findOrFail($id);
            $gallery_files = explode(',', $gallery->files);
            $courses = Course::all();
            return view('admin.gallery.edit')->with('gallery', $gallery)
            ->with('locations',$locations)
            ->with('gallery_files',$gallery_files)
            ->with('courses',$courses);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {



            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required|string',
                'title_ar'   => 'required|string'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->except(['files','cover_photo']);


            if($request->file('files') != null){
                $filenames = MediaFile::singleObject()->uploadMultipleFiles($request->file('files'),'gallery');
	            $providedData['files'] = implode(',',$filenames);
            }

            if($request->file('cover_photo') != null){
            $file=$request->file('cover_photo');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/gallery/', $filename);
            $providedData['cover_photo'] = $filename;
            }


            $gallery = Gallery::findOrFail($id);

            $gallery->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('gallery.index');


    }

    public function destroy($id)
    {
        try {

            $gallery = Gallery::find($id);
            $gallery->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('gallery.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
