<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Counter;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Validator;
use \Exception;
use DB;

class CloneMenuController extends Controller
{
        public function index()
    {
        try {
            
            $parents = DB::table('menu')->where('parent_id','=',0)->get();
            $menus = DB::table('menu')->where('url','!=','/')->get();
            return view('admin.home-page.clone_menu')->with('parents',$parents)->with('menus',$menus);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }
}
