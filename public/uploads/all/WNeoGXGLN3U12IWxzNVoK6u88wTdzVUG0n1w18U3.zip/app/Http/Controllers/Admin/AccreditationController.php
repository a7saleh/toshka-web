<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Accreditation;
use Illuminate\Http\Request;
use Validator;

class AccreditationController extends Controller
{
    public function index(){

        try {

            $accreditation = Accreditation::orderBy('id' , 'desc')->get();

            return view('admin.courses.accreditation')->with('accreditation',$accreditation);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.courses.create-accreditation');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'accreditation'   => 'required|string',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            Accreditation::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('accreditation.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $accreditation = Accreditation::findOrFail($id);
            return view('admin.courses.edit-accreditation')->with('accreditation', $accreditation);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'accreditation'   => 'required|string',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $accreditation = Accreditation::findOrFail($id);

            $accreditation->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('accreditation.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $accreditation = Accreditation::find($id);
            $accreditation->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('accreditation.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
