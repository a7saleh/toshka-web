<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Banner;
use Illuminate\Http\Request;
use Validator;
use \Exception;

class BannerController extends Controller
{
    public function index(){

        try {


            $array1 = Banner::where('priority', '!=' , null)->orderBy('priority' , 'asc')->get();
            $array2 = Banner::where('priority', null)->orderBy('id' , 'desc')->get();
            $banners = Array();
            foreach ($array1 as $arr){
                array_push($banners , $arr);
            }
            foreach ($array2 as $arr){
                array_push($banners , $arr);
            }

//            $banners = array_merge($array1,$array2);
//            return $banners;

            return view('admin.home-page.index')->with('banners',$banners);

        } catch (Exception $e) {
            report($e);
            return $e;
        }
    }

    public function create()
    {
        try {

            return view('admin.home-page.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

           

            $providedData = $request->all();


            if($request->file('file') != null){
            $file=$request->file('file');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/banners/files', $filename);
            $providedData['file'] = $filename;
            }     
            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/sliders/', $filename);
            $providedData['image'] = $filename;
            }            


            Banner::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('slider.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $banner = Banner::findOrFail($id);
            return view('admin.home-page.edit')->with('banner', $banner);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            
            if($request->file('file') != null){
            $file=$request->file('file');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/banners/files/', $filename);
            $providedData['pdf'] = $filename;
            }  
            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/sliders/', $filename);
            $providedData['image'] = $filename;
            }

            
            if($request->file('banner') != null){
            $file=$request->file('banner');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/frontend/images/banners/', $filename);
            $providedData['image'] = $filename;
            }

            $banners = Banner::findOrFail($id);

            $banners->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('slider.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $banners = Banner::find($id);
            $banners->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('slider.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
