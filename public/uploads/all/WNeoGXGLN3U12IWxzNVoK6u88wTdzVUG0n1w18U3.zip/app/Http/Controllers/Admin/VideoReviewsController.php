<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Course;
use App\Models\PageContent;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use App\Models\VideoReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use \Exception;

class VideoReviewsController extends Controller
{
    public function index(){

        try {

            $videos = VideoReview::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();

            return view('admin.video-reviews.index')->with('videos',$videos);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            $courses = Course::all();
            return view('admin.video-reviews.create')->with('courses',$courses);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'video'      => 'required',
                'course_id'   => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            VideoReview::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('video-reviews.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $video = VideoReview::findOrFail($id);
            $courses = Course::all();
            return view('admin.video-reviews.edit')->with('video', $video)->with('courses',$courses);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'course_id'   => 'required',
                'video'   => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $video = VideoReview::findOrFail($id);

            $video->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('video-reviews.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $video = VideoReview::find($id);
            $video->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('video-reviews.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
