<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\CourseReview;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use App\Http\MediaFile;
use Validator;

/**
 * Course Review
 */
class CourseReviewController extends Controller
{

    public function index(){

        try {

            $coursereviews = CourseReview::orderBy('id' , 'desc')->get();
//            return  $coursereviews;
            return view('admin.coursereviews.index')->with('coursereviews',$coursereviews);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            $courses = Course::all();
            return view('admin.coursereviews.create')->with('courses',$courses);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'course_id'   => 'required',
                'review'      => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            CourseReview::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('coursereviews.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $CourseReview = CourseReview::findOrFail($id);
            $courses = Course::all();
            return view('admin.coursereviews.edit')->with('CourseReview', $CourseReview)
            ->with('courses',$courses);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'course_id'   => 'required',
                'review'      => 'required'
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            $CourseReview = CourseReview::findOrFail($id);

            $CourseReview->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('coursereviews.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $CourseReview = CourseReview::find($id);
            $CourseReview->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('coursereviews.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

}
