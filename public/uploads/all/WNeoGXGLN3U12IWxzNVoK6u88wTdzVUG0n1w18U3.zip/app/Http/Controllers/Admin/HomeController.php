<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \Exception;
use \Validator;
use \Session;
use App\User;

/**
 * home controller
 */
class HomeController extends Controller
{
	
	public function index()
	{
		try {

			return view('admin.home.index');
			
		} catch (Exception $e) {
			report($e);
			return redirect('somethingwrong');
		}
	}

	public function unauthorized()
    {
		return view('admin.errors.unauthorized');
	}
}
