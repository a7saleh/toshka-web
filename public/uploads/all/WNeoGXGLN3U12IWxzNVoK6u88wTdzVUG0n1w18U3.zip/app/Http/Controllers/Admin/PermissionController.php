<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Permission;
use App\Models\UserRole;
use App\Models\RolePermission;
use Exception;

class PermissionController extends Controller
{
	public function index()
	{
		try {
            
            $userRoles = UserRole::select('id','name')->with('rolePermissions')->get();
            foreach ($userRoles as $userRole){
                $userRole->permissions = $userRole->rolePermissions->pluck('id')->toArray();
                unset($userRole->rolePermissions);
            }
			$permissions = Permission::select('id' , 'name')->orderBy('name')->get();
			return view('admin.permissions.index')->with('permissions', $permissions)->with('user_roles' , $userRoles);
			
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	public function update(Request $request)
	{
		try {

			$id = $request->input('userid');
			$permissions = $request->input('permissions');

			$userRole = UserRole::findOrFail($id);

			if($request->has('permissions')){
                $userRole->rolePermissions()->sync($permissions);
            }
            
            return response()->json(['status' => true]);

		} catch (Exception $e) {
			return $e->getMessage();
		}
	}
}