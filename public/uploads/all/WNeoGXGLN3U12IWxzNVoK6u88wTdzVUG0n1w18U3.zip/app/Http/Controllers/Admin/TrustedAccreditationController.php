<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\TrustedAccreditation;
use App\Models\PageContent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use \Exception;

class TrustedAccreditationController extends Controller
{
    public function index(){

        try {

            $trusted_accreditations = TrustedAccreditation::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();

            return view('admin.trusted-accreditation.index')->with('trusted_accreditations',$trusted_accreditations);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.trusted-accreditation.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'image'      => 'required|mimes:jpg,jpeg,png,mp4,JPG,JPEG',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/trusted_accreditations/', $filename);
            $providedData['image'] = $filename;
            } 
            
            TrustedAccreditation::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('trusted_accreditation.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $trusted_accreditation = TrustedAccreditation::findOrFail($id);
            return view('admin.trusted-accreditation.edit')->with('trusted_accreditation', $trusted_accreditation);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {


            $providedData = $request->all();

            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/trusted_accreditations/', $filename);
            $providedData['image'] = $filename;
            } 
            
            if($request->file('banner') != null || $request->title_ar != null || $request->title_en != null){
            $file=$request->file('banner');
            if($file){
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/frontend/images/banners/', $filename);
            $providedData['image'] = $filename;
            }
            $content = PageContent::findOrFail($id);

            $content->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('trusted_accreditation.index');            
                
            }


            $trusted_accreditations = TrustedAccreditation::findOrFail($id);

            $trusted_accreditations->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('trusted_accreditation.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $trusted_accreditations = TrustedAccreditation::find($id);
            $trusted_accreditations->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('trusted_accreditation.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
