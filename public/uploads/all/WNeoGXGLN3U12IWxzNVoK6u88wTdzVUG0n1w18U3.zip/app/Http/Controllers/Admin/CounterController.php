<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Counter;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Validator;
use \Exception;

class CounterController extends Controller
{
    public function index(){

        try {
            $array1 = Counter::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->limit(3)->get();
            $array2 = Counter::where('priority' , null)->orderBy('id' , 'desc')->limit(3)->get();
            $counters = Array();
            foreach ($array1 as $key => $arr){
                array_push($counters , $arr);
            }
            foreach ($array2 as $key => $arr){
                array_push($counters , $arr);
            }

//            $counters = Counter::limit(3)->orderBy('id' , 'desc')->get();


            return view('admin.home-page.counter')->with('counters',$counters);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {

            $counter = Counter::findOrFail($id);
            return view('admin.home-page.edit-counter')->with('counter', $counter);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'   => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $counter = Counter::findOrFail($id);

            $counter->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('counter.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

}
