<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Validator;
use \Exception;
use DB;

class TestimonialController extends Controller
{
    
        public function index(){

        try {

            $videos = SliderVideo::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
            $testimonials = Testimonial::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();

            return view('admin.home-page.testimonial')->with('videos',$videos)->with('testimonials' , $testimonials);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.home-page.create-testimonial');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'      => 'required',
                'description_en'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            Testimonial::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('testimonial.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $testimonial = Testimonial::findOrFail($id);
            return view('admin.home-page.edit-testimonial')->with('testimonial', $testimonial);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'      => 'required',
                'description_en'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();



            $testimonial = Testimonial::findOrFail($id);

            $testimonial->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('testimonial.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $testimonial = Testimonial::find($id);
            $testimonial->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('testimonial.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
