<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\BlogSlider;
use Illuminate\Http\Request;
use Validator;
use \Exception;

class BlogSliderController extends Controller
{
    public function index(){

        try {

            $array1 = BlogSlider::where('priority', '!=' , null)->orderBy('priority' , 'asc')->get();
            $array2 = BlogSlider::where('priority', null)->orderBy('id' , 'desc')->get();
            $banners = Array();
            foreach ($array1 as $key => $arr){
                array_push($banners , $arr);
            }
            foreach ($array2 as $key => $arr){
                array_push($banners , $arr);
            }


            return view('admin.blog_sliders.index')->with('banners',$banners);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function create()
    {
        try {

            return view('admin.blog_sliders.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/sliders/', $filename);
            $providedData['image'] = $filename;
            }

            BlogSlider::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('blog_sliders.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $banner = BlogSlider::findOrFail($id);
            return view('admin.blog_sliders.edit')->with('banner', $banner);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'title_en'      => 'required',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/sliders/', $filename);
            $providedData['image'] = $filename;
            }

            $banners = BlogSlider::findOrFail($id);

            $banners->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('blog_sliders.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $banners = BlogSlider::find($id);
            $banners->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('slider.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
