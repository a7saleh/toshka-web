<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\NewsletterEmails;
use App\Models\PageContent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Validator;
use \Exception;


class NewsletterController extends Controller
{
    public function index(){

        try {

            $emails = NewsletterEmails::orderBy('id' , 'desc')->get();


            return view('admin.newsletter.index')->with('emails',$emails);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function create()
    {
        try {

            return view('admin.newsletter.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'email'   => 'required|email|unique:newsletter_emails',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            NewsletterEmails::create($providedData);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('newsletter.index');

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }


    public function edit($id)
    {
        try {

            $email = NewsletterEmails::findOrFail($id);
            return view('admin.newsletter.edit')->with('email', $email);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
                'email'   => 'required|email|unique:newsletter_emails',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            $email = NewsletterEmails::findOrFail($id);

            $email->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('newsletter.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function destroy($id)
    {
        try {

            $email = NewsletterEmails::find($id);
            $email->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('newsletter.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }

    public function sendNewsletterEmail(Request $request){
        try {
            $emails = NewsletterEmails::all();
            $emails_array = [];
            foreach ($emails as $email){
                $emails_array[] = $email->email;
            }
            $emailSubject = $request->subject;
            $emailBody = $request->message;

            Mail::raw($emailBody, function ($message) use ($emailSubject , $emails_array) {
                $message->from('info@rumman.tech', ' RummanTech Co ');
                $message->sender('info@rumman.tech', ' RummanTech Co ');
                $message->to($emails_array);
                $message->subject($emailSubject);
            });
            session()->flash('success' , 'Your Message Was Sent Successfully');
            return redirect()->route('newsletter.index');
        }catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }
}
