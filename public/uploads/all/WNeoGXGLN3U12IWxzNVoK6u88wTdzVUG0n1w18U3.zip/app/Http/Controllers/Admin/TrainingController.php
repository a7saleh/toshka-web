<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\PageContent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use \Exception;

class TrainingController extends Controller
{
    public function index(){

        try {

            $contents = PageContent::where('ref_page' , 'training')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();


            return view('admin.training.index')->with('contents',$contents);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function store(Request $request)
    {
        try {

            $providedData = $request->all();

            $content = new PageContent();

            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/frontend/images/consultant/', $filename);
            $providedData['image'] = $filename;
            }

            $content->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('training.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }



        public function create()
    {
        try {

            return view('admin.training.create');

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }
    
    public function edit($id)
    {
        try {

            $content = PageContent::findOrFail($id);
            return view('admin.training.edit')->with('content', $content);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {
            
            
            $providedData = $request->all();


            
            if($request->file('image') != null){
            $file=$request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/storage/uploads/page-contents/', $filename);
            $providedData['image'] = $filename;
            }           
            
            if($request->file('banner') != null){
            $file=$request->file('banner');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $path = $file->move(public_path().'/frontend/images/banners/', $filename);
            $providedData['image'] = $filename;
            }

            $content = PageContent::findOrFail($id);

            $content->fill($providedData)->save();
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('training.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }
    
    public function destroy($id)
    {
        try {

            $content = PageContent::find($id);
            $content->delete();
            session()->flash('success' , trans('messages.data_has_been_deleted_successfully'));
            return redirect()->route('training.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');

        }
    }    
    
    
}
