<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\MobileCountryCode;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Models\Banner;
use App\Http\MediaFile;
use App\Models\Testimonial;

/**
 * AjaxController [ handle ajax request ]
 */
class AjaxController extends Controller
{

	public function userDetails(Request $request)
	{
		$id = $request->input('id');
		$user = User::with('userRole')->with('country')->findOrFail($id);
		return response()->json(['status' => 200, 'user' => $user]);
	}
	//userDetails

	public function getMobileCountryCode(Request $request)
	{
		$country_id = $request->input('country_id');
		$code = MobileCountryCode::where('country_id',$country_id)->get();
		return response()->json(['status' => 200, 'code' => $code]);
	}
	//getMobileCountryCode

}
