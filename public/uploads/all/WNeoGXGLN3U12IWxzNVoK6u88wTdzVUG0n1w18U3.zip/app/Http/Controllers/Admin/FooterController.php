<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Counter;
use App\Models\SliderVideo;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Validator;
use \Exception;
use DB;

class FooterController extends Controller
{
    public function index(){

        try {
            
            $menus = DB::table('footer')->orderBy('element_order','asc')->where('type','!=','logo')->get();
            

            return view('admin.home-page.footer')->with('menus',$menus);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }


    public function edit($id)
    {
        try {
            $menus = DB::table('footer')->where('id','=',$id)->first();
            $parents = DB::table('footer')->where('id','!=',$id)->where('parent_id','=',0)->get();
            return view('admin.home-page.edit-footer')->with(['counter'=> $menus,'parents'=>$parents]);

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

    public function update(Request $request,$id)
    {
        try {

            $validateForm = Validator::make($request->all(),[
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if($request->file('image') != null){
                
           //$filename = MediaFile::singleObject()->uploadFile($request->file('image'),'test');
                $file=$request->file('image');
                $filename = time().'.'.$file->getClientOriginalExtension();
                $path = $file->move(public_path().'/logo/', $filename);
                
           $parents = DB::table('footer')->where('id','=',23)->update([
               'url'=>$filename,
               ]);  
               
            }else{
           $parents = DB::table('footer')->where('id','=',$id)->update([
               'name_ar'=>$request->name_ar,
               'name_en'=>$request->name_en,
               'element_order'=>$request->element_order,
               'url'=>$request->url,
               'status'=>$request->status,
               'type'=>$request->type,
               ]);
            }
            
            session()->flash('success' , trans('messages.data_has_been_updated_successfully'));
            return redirect()->route('footer.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }
        public function create()
    {
        try {
            $parents = DB::table('footer')->where('parent_id','=',0)->get();
            return view('admin.home-page.create_footer')->with('parents',$parents);

        } catch (Exception $e) {

            report($e);
            return redirect('somethingwrong');
        }
    }

    public function store(Request $request)
    {
        try {

           $parents = DB::table('footer')->insert([
               'name_ar'=>$request->name_ar,
               'name_en'=>$request->name_en,
               'element_order'=>$request->element_order,
               'url'=>$request->url??0,
               'status'=>$request->status,
               'type'=>$request->type,
               ]);

            session()->flash('success' , trans('messages.data_has_been_added_successfully'));
            return redirect()->route('footer.index');

        } catch (Exception $e) {
            report($e);
            return redirect('somethingwrong');
        }
    }

}
