<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\MediaFile;
use App\Models\Accreditation;
use App\Models\ActivityType;
use App\Models\BlogSlider;
use App\Models\CourseApplication;
use App\Models\CourseReview;
use App\Models\NewsSlider;
use App\Models\PageContent;
use App\Models\Report;
use App\Models\SliderVideo;
use App\Models\SubjectArea;
use App\Models\TrustedAccreditation;
use App\Models\Venue;
use App\Models\VideoReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use \Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\URL;
use Nette\Utils\DateTime;
use \Validator;
use \Session;
use App\Models\User;
use App\Models\News;
use App\Models\Gallery;
use App\Models\Course;
use App\Models\Country;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Models\NewsletterEmails;
use File;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;



/**
 * web controller for webiste
 */
class WebController extends Controller
{

	# handle all index pages

    public function index(Request $request){

		try {

			# get page name
			$end_of_url = explode('/', $request->fullUrl());
			$end_of_url = end($end_of_url);

			if ($end_of_url == 'leadership') {

			    $content = PageContent::where('ref_page' , 'leadership')->get();

				return view('website.pages.leadership')->with('content' , $content);

			}elseif ($end_of_url == 'brands') {

                $content = PageContent::where('ref_page' , 'brands')->get();
                return view('website.pages.brands')->with('content' , $content);

			}elseif ($end_of_url == 'ourimpact') {

                $content = PageContent::where('ref_page','our-impact')->get();
				return view('website.pages.ourimpact')->with('content' , $content);

			}elseif ($end_of_url == 'strategies') {

                $vision = PageContent::findOrFail(27);
                $mission = PageContent::findOrFail(28);
                $growth = PageContent::findOrFail(29);
				return view('website.pages.strategies')
                    ->with('vision' , $vision)
                    ->with('mission' , $mission)
                    ->with('growth' , $growth);

			}elseif ($end_of_url == 'trusted-accreditation') {

                $accreditation = TrustedAccreditation::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->where('image','!=',null)->get();
				return view('website.pages.achievements')
                    ->with('accreditation' , $accreditation);

			}elseif ($end_of_url == 'achievements2') {

                $contents = PageContent::where('ref_page','achievements')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
                return view('website.pages.achievements2')
                    ->with('contents' , $contents);

            }elseif ($end_of_url == 'extra') {

                $contents = PageContent::where('ref_page','extra')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
                return view('website.pages.extra')
                    ->with('contents' , $contents);

            }elseif ($end_of_url == 'trainings') {

                $contents = PageContent::where('ref_page','training')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
                $subject_area = SubjectArea::all();
                $venue = Venue::all();
                $activity_type = ActivityType::all();
                $accreditation = TrustedAccreditation::where('image','!=',null)->get();
				return view('website.pages.trainings')
                    ->with('subject_area' , $subject_area)
                    ->with('venue' , $venue)
                    ->with('activity_type' , $activity_type)
                    ->with('accreditation' , $accreditation)
                    ->with('contents' , $contents);

			}elseif ($end_of_url == 'contact-us') {

                $content = PageContent::findOrFail(11);
                $call = PageContent::findOrFail(12);
                $phone = PageContent::findOrFail(13);
                $email = PageContent::findOrFail(43);
                $po_box = PageContent::findOrFail(14);
                $location = PageContent::findOrFail(15);
                return view('website.pages.contactus')
                    ->with('content' , $content)
                    ->with('call' , $call)
                    ->with('phone' , $phone)
                    ->with('email' , $email)
                    ->with('box' , $po_box)
                    ->with('location' , $location);

			}elseif ($end_of_url == 'about-us') {

			    $head_content = PageContent::where('ref_page' , 'about-us-head')->get();
                $contents = PageContent::where('ref_page','about-us')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
				return view('website.pages.aboutus')
                    ->with('contents', $contents)->with('head_content' , $head_content);

			}elseif ($end_of_url == 'join-us') {

			    $content = PageContent::where('ref_page','join-us')->get();
				return view('website.pages.joinus')
                    ->with('content', $content);

			}elseif ($end_of_url == 'consultancy') {


				return view('website.pages.consultancy');

			}elseif ($end_of_url == 'coursesAll' || str_contains($end_of_url, 'coursesAll?page') ) {


                $checkLang = 0;

                $courses =  Course::where('is_hidden' , 0)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
                $subject_area = SubjectArea::all();
                $venue = Venue::all();
                $activity_type = ActivityType::all();
                $accreditation = TrustedAccreditation::get();
                $coursesDropDown = Course::where('is_hidden' , 0)->get();
                $links = 0;
                $date = date('Y-m-d H:i:s');
                $currentDate = Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('m-d-Y');
//                $currentDate = Carbon::now();
//                $currentDate = $currentDate->toDateString();
                return view('website.pages.courses')
                    ->with('courses',$courses)
                    ->with('links', $links)
                    ->with('currentDate' , $currentDate)
                    ->with('coursesDropDown' , $coursesDropDown)
                    ->with('subject_area' , $subject_area)
                    ->with('venue' , $venue)
                    ->with('activity_type' , $activity_type)
                    ->with('accreditation' , $accreditation)->with('checkLang' , $checkLang);

            }elseif ($end_of_url == 'courses') {





                $courses = Course::where('is_hidden' , 0)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->Paginate(6);
                $subject_area = SubjectArea::all();
                $venue = Venue::all();
                $activity_type = ActivityType::all();
                $accreditation = TrustedAccreditation::all();
                $coursesDropDown = Course::where('is_hidden' , 0)->get();
                $links = 1;
                $date = date('Y-m-d H:i:s');
                $currentDate = Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('m-d-Y');
                $checkLang = 0;
//                $currentDate = Carbon::now();
//                $currentDate = $currentDate->toDateString();
                return view('website.pages.courses')
                    ->with('courses',$courses)
                    ->with('links', $links)
                    ->with('currentDate' , $currentDate)
                    ->with('coursesDropDown' , $coursesDropDown)
                    ->with('subject_area' , $subject_area)
                    ->with('venue' , $venue)
                    ->with('activity_type' , $activity_type)
                    ->with('accreditation' , $accreditation)->with('checkLang' , $checkLang);

            } elseif (str_contains($end_of_url, 'courses?page') ) {


                $courses = Course::where('is_hidden' , 0)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->Paginate(6);
                $subject_area = SubjectArea::all();
                $venue = Venue::all();
                $activity_type = ActivityType::all();
                $accreditation = TrustedAccreditation::all();
                $coursesDropDown = Course::where('is_hidden' , 0)->get();
                $links = 1;
                $date = date('Y-m-d H:i:s');
                $currentDate = Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('m-d-Y');
                $checkLang = 1;
//                $currentDate = Carbon::now();
//                $currentDate = $currentDate->toDateString();
                return view('website.pages.courses')
                    ->with('courses',$courses)
                    ->with('links', $links)
                    ->with('currentDate' , $currentDate)
                    ->with('coursesDropDown' , $coursesDropDown)
                    ->with('subject_area' , $subject_area)
                    ->with('venue' , $venue)
                    ->with('activity_type' , $activity_type)
                    ->with('accreditation' , $accreditation)->with('checkLang' , $checkLang);

            }elseif (str_contains($end_of_url, 'inner-course?')) {



                $course_id = $_GET['course_id'];
                $course = Course::findOrFail($course_id);
                $subject_areas = explode(',' , $course->subject_area);
                $subject_areas_ar = explode(',' , $course->subject_area_ar);
                $skills = $course->skills;
                $skills_array = explode(',' , $skills);
                $skills_ar  = $course->skills_ar;
                $skills_array_ar = explode(',' , $skills_ar);
                $accreditation = $course->accreditation;
                $accreditation_array = explode(',' , $accreditation);
                $reviews = CourseReview::where('course_id' , $course_id)->get();
                $slider_videos = VideoReview::where('course_id' , $course_id)->get();

                $currentURL = url()->current();
                $shareComponent = \Share::page(
                    $currentURL,
                    $course->title_en
                )
                    ->facebook()
                    ->whatsapp()
                    ->twitter()
                    ->linkedin();


                $arr = Array();
                foreach ($subject_areas as $key => $subject_area){
                    $related = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area)->where('id' , '!=' , $course_id)->get();
                    foreach ($related as $value){
                        array_push($arr, $value);

                    }
                }

                $arr_ar = Array();
                foreach ($subject_areas_ar as $key => $subject_area_ar){
                    $related_ar = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area_ar)->where('id' , '!=' , $course_id)->get();
                    foreach ($related_ar as $value){
                        array_push($arr_ar, $value);

                    }
                }

                #diff


                return view('website.pages.inner-courses')
                    ->with('course' , $course)
                    ->with('reviews' , $reviews)
                    ->with('skills' , $skills_array)->with('skills_ar' , $skills_array_ar)
                    ->with('subject_area' , $subject_areas)->with('subject_area_ar' , $subject_areas_ar)->with('shareComponent' , $shareComponent)
                    ->with('accreditations' , $accreditation_array)
                    ->with('related_courses' , $arr)->with('related_courses_ar' , $arr_ar)
                    ->with('videos' , $slider_videos);

            }elseif ($end_of_url == 'compare-courses') {

                return view('website.pages.compare-courses');

            }elseif (str_contains($end_of_url, 'apply-course?')) {

                $course_id = $_GET['course_id'];
                $course = Course::where('id' , $course_id)->get();
//                return $related;

                return view('website.pages.apply-course')
                    ->with('course' , $course);

            }elseif ($end_of_url == 'blog' || str_contains($end_of_url, 'blog?page')) {

			    $sliderArr1 = BlogSlider::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->get();
			    $sliderArr2 = BlogSlider::where('priority' ,  null)->orderBy('id' , 'desc')->get();
                $blog_slider = Array();
                foreach ($sliderArr1 as $arr){
                    array_push($blog_slider , $arr);
                }
                foreach ($sliderArr2 as $arr){
                    array_push($blog_slider , $arr);
                }

                $blogs = News::where('is_blog',1)->orWhere('most_popular' , 1)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->Paginate(3);
				$latest_articles = News::where('is_blog' , 1)->where('latest' , 1)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->limit(9)->get();
				$explore_more = News::where('is_blog' , 1)->where('explore_more' , 1)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->limit(3)->get();

                $links = 1;

                return view('website.pages.blog')
                    ->with('blogs',$blogs)
                    ->with('latest_articles' , $latest_articles)
                    ->with('explore_more' , $explore_more)
                    ->with('links' , $links)
                    ->with('sliders' , $blog_slider);

			}elseif (str_contains($end_of_url , 'inner-blog?')) {

                $blog_id = $_GET['blog_id'];
                $this->blog_id = $blog_id;
                $blog = News::findOrFail($blog_id);
                $blogs = News::where('is_blog',1)->get();
                $blog_slider = BlogSlider::all();
                $related_courses = Course::where('is_hidden' , 0)->with('blogCourses')->whereHas('blogCourses' , function ($query){
                    $query->where('blog_id' , $this->blog_id);
                })->get();


                $currentURL = url()->current();
                $shareComponent = \Share::page(
                    $currentURL,
                    $blog->title_en,
                )
                    ->facebook()
                    ->twitter()
                    ->linkedin()
                    ->whatsapp();
//                return $currentURL;
                return view('website.pages.inner-blog')
                    ->with('blogs' , $blogs)
                    ->with('blog' , $blog)
                    ->with('shareComponent' , $shareComponent)
                    ->with('related_courses' , $related_courses)
                    ->with('sliders' , $blog_slider);

            }elseif ($end_of_url == 'news'){
				$news = News::where('is_blog',0)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
				$breaking_news = News::where('is_blog',0)->where('breaking_news' , 1)->orderBy('id' , 'desc')->get();
                $slider = NewsSlider::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
                $links = 0;
                return view('website.pages.news')->with('news',$news)->with('sliders' , $slider)->with('links' , $links)->with('breaking_news' , $breaking_news);

			} elseif ($end_of_url == 'more-news' || str_contains($end_of_url, 'more-news')) {

                $news = News::where('is_blog',0)->orderBy('id' , 'desc')->get();
                $breaking_news = News::where('is_blog',0)->where('breaking_news' , 1)->orderBy('id' , 'desc')->get();
                $slider = NewsSlider::all();
                $links = 1;
                return view('website.pages.news')->with('news',$news)->with('sliders' , $slider)->with('links' , $links)->with('breaking_news' , $breaking_news);

            }
			elseif (str_contains($end_of_url, 'inner-news?')) {

				$news_id = $_GET['news_id'];
				$recent_news = News::where('is_blog',0)->where('breaking_news' , 1)->orderBy('id' , 'desc')->get();
				$news = News::where('id',$news_id)->where('is_blog',0)->Paginate(6);
				if( count($news) != 1) return redirect(404);

                $currentURL = url()->current();
                $shareComponent = \Share::page(
                    $currentURL,
                    $news[0]->title_en,
                )
                    ->facebook()
                    ->whatsapp()
                    ->twitter()
                    ->linkedin();

				return view('website.pages.inner-news')
				->with('news',$news)
				->with('recent_news',$recent_news)
                ->with('shareComponent' , $shareComponent);

			}elseif ($end_of_url == 'faqs') {

			    $contents = PageContent::where('ref_page' , 'faq')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
				return view('website.pages.faqs')->with('contents' , $contents);

			}elseif ($end_of_url == 'gallery' || str_contains($end_of_url, 'gallery?page')) {

				$courses = Course::where('is_hidden' , 0)->with('galleries')->whereHas('galleries' , function ($query){
				    $query->where('course_id' , '!=' , null);
                })->get();
				$locations = Country::all();
//				$gallery = Gallery::all();
                $gallery = Gallery::with('location')->with('course')->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->Paginate(6);
                $links = 1;
                $checkLang = 0;

				return view('website.pages.gallery')
				->with('locations',$locations)
				->with('courses',$courses)
                    ->with('gallery' , $gallery)
                    ->with('links',  $links)->with('checkLang' , $checkLang);

			}elseif (str_contains($end_of_url, 'inner-gallery?')) {

				$gallery_id = $_GET['gallery_id'];


				$gallery = Gallery::with('course')
				->with('location')
				->find($gallery_id);

                $currentURL = url()->current();
                $shareComponent = \Share::page(
                    $currentURL,
                    $gallery->title_en
                )
                    ->facebook()
                    ->twitter()
                    ->linkedin()
                    ->whatsapp();

				$gallery_images = explode(',', $gallery->files);
				if(!$gallery) return redirect(404);

				return view('website.pages.inner-gallery')
				->with('gallery_images', $gallery_images)
				->with('gallery',$gallery)->with('shareComponent' , $shareComponent);

			}elseif ($end_of_url == 'instructor-form') {

				return view('website.pages.instructor-form');

			}elseif ($end_of_url == 'reseller-form') {

				return view('website.pages.reseller-form');

			}elseif ($end_of_url == 'suggest-new-course-form') {

				return view('website.pages.suggest-new-course-form');

			}elseif ($end_of_url == 'copyright') {


                $main_description = PageContent::where('id' , 51)->get();
                $contents = PageContent::where('ref_page' , 'copyright-page')->where('id' , '!=' , 51)->get();


				return view('website.pages.copyright')
                    ->with('contents' ,$contents)
                    ->with('main_description' , $main_description);

			}elseif ($end_of_url == 'privacy-policy') {

                $main_description = PageContent::where('id' , 32)->get();
                $contents = PageContent::where('ref_page' , 'privacy-policy')->where('id' , '!=' , 32)->get();
				return view('website.pages.privacypolicy')
                    ->with('contents' ,$contents)
                    ->with('main_description' , $main_description);

			}elseif ($end_of_url == 'terms-of-use') {

			    $main_description = PageContent::where('id' , 31)->get();
			    $contents = PageContent::where('ref_page' , 'terms-of-use')->where('id' , '!=' , 31)->get();

				return view('website.pages.termsofuse')
                    ->with('contents' ,$contents)
                    ->with('main_description' , $main_description);

			}elseif ($end_of_url == 'sitemap') {

				return view('website.pages.sitemap');

			}else{

				return redirect('404');
			}

		} catch (Exception $e) {

			report($e);
			return $e->getMessage();
		}
	}
	//index

	# handle global search
	public function search(Request $request)
	{

		$search_word = $request->get('search_word');

		if ( !empty($search_word) ) {

			$courses = Course::where('is_hidden' , 0)->
			where('title_en', 'like', '%'.$search_word.'%')
			->orWhere('title_ar', 'like', '%'.$search_word.'%')
			->get();

			$news = News::where('title_en', 'like', '%'.$search_word.'%')
			->orWhere('title_ar', 'like', '%'.$search_word.'%')
			->get();

			foreach ($news as $key => $new) {
				if ( $new->is_blog == 1 ) {
					unset($news[$key]);
				}
			}

			$news = array_values($news->toArray());

			return view('website.pages.search')
			->with('news',$news)
			->with('courses',$courses);
		}else{
			return view('website.pages.search');
		}
	}
	//search

    public function compare(Request $request){

        $course1_id = $request->get('course-select-1');
        $course2_id = $request->get('course-select-2');
        $course3_id = $request->get('course-select-3');
        $courses    =  Course::where('is_hidden' , 0)->get();
//        return $course1_id;
        if ($course1_id != 0 || $course2_id != 0 || $course3_id !=0){
            $course1 = Course::where('id' , $course1_id)->get();
            $course2 = Course::where('id' , $course2_id)->get();
            $course3 = Course::where('id' , $course3_id)->get();
//            return $course1[0]->id;
            return view('website.pages.compare-courses')->with('course1' , $course1)->with('course2' , $course2)->with('course3' , $course3)->with('courses' , $courses);

        }else{
            return view('website.pages.compare-courses')->with('courses' , $courses);
        }


    }

    public function filterCourse(Request $request){


        $checkLang = 1;
        $subject_area = SubjectArea::all();
        $venue = Venue::all();
        $activity_type = ActivityType::all();
        $accreditation = TrustedAccreditation::all();

        $subject_area_request = $request->get('subject_area_amsify');
        $date_request  = $request->get('available_date');
        $venue_request = $request->get('venue_amsify');
        $activity_type_request = $request->get('activity_type_amsify');
        $accreditation_request = $request->get('accreditation_amsify');
//        return $activity_type_request;

        if (empty($venue_request) && empty($subject_area_request) && empty($date_request) && empty($activity_type_request) && empty($accreditation_request)){
            $venue_request = 'faked';
            $subject_area_request = 'faked';
            $date_request = 'faked';
            $activity_type_request = 'faked';
            $accreditation_request = 'faked';
        }




        $available_courses = array();
        $courses_arr = array();
        $available = $request->available;

        if(!empty($available)){

            foreach($available as $key => $value ){

                if ($value == 'now') {
                    $courses = Course::where('is_hidden' , 0)->where('start_date' , '>=' , Carbon::now())->wherebetween('start_date' , [Carbon::now()->startOfWeek(Carbon::SATURDAY), Carbon::now()->endOfWeek(Carbon::FRIDAY)])->get();
                    array_push($available_courses , $courses);
                }

                if ($value == 'next_week') {
                    $date = Carbon::now();
                    $date7 = Carbon::parse($date)->addDays(7);
                    $date14 = Carbon::parse($date)->addDays(8);

                    $courses = Course::where('is_hidden' , 0)->where('start_date' , '>' , $date7->format('Y-m-d'))
                    ->where('start_date' , '<=' , $date14->format('Y-m-d'))
                    ->get();
                    array_push($available_courses , $courses);
                }

                if ($value == 'next_month') {
                    $date = Carbon::now();
                    $date30 = Carbon::parse($date)->addDays(8);
                    $date60 = Carbon::parse($date)->addDays(30);

                    $courses = Course::where('is_hidden' , 0)->where('start_date' , '>' , $date30->format('Y-m-d'))
                    ->where('start_date' , '<' , $date60->format('Y-m-d'))
                    ->get();
                    array_push($available_courses , $courses);
                }

                if ($value == 'three_months') {
                    $date = Carbon::now();
                    $date3 = Carbon::parse($date)->addMonths(1);
                    $date6 = Carbon::parse($date)->addMonths(3);

                    $courses = Course::where('is_hidden' , 0)->where('start_date' , '>=' , $date3->format('Y-m-d'))
                    ->where('start_date' , '<=' , $date6->format('Y-m-d'))
                    ->get();
                    array_push($available_courses , $courses);
                }

                if ($value == 'sixth_months') {
                    $date = Carbon::now();
                    $date6 = Carbon::parse($date)->addMonths(3);
                    $date1 = Carbon::parse($date)->addMonths(12);

                    $courses = Course::where('is_hidden' , 0)->where('start_date' , '>=' , $date6->format('Y-m-d'))
                    ->where('start_date' , '<=' , $date1->format('Y-m-d'))
                    ->get();
                    array_push($available_courses , $courses);
                }


            }
        }

//        if (!empty($request->available_date)) {
//            $date = Carbon::now();
//            $date1 = Carbon::parse($request->available_date);
//
//            $courses = Course::where('is_hidden' , 0)->where('start_date' , '=' , $date1->format('Y-m-d'))->get();
//            array_push($available_courses , $courses);
//        }

//        return $available_courses;
        foreach ($available_courses as $key => $course){
            foreach ($course as $c){
                array_push($courses_arr , $c);
            }
        }



        if (App::getLocale() == 'en'){
            $courses = Course::query()->where('is_hidden' , 0)
                ->when($subject_area_request, function ($query) use ($subject_area_request){
                    $query->where('subject_area', 'LIKE', "%$subject_area_request%");
                })
                ->when($venue_request , function ($query) use ($venue_request){
                    $query->where('venue', 'LIKE', "%$venue_request%");
                })
                ->when($date_request , function ($query) use ($date_request){
                    $query->where('start_date' , '>=' , Carbon::now())->where('start_date', $date_request);
                })
                ->when($activity_type_request , function ($query) use ($activity_type_request){
                    $query->where('activity_type', $activity_type_request);
                })
                ->when($accreditation_request , function ($query) use ($accreditation_request){
                    $query->where('accreditation', $accreditation_request);
                })
                ->get();


        }else {
            $courses = Course::query()->where('is_hidden' , 0)
                ->when($subject_area_request, function ($query) use ($subject_area_request){
                    $query->where('subject_area_ar', 'LIKE', "%$subject_area_request%");
                })
                ->when($venue_request , function ($query) use ($venue_request){
                    $query->where('venue_ar', 'LIKE', "%$venue_request%");
                })
                ->when($date_request , function ($query) use ($date_request){
                    $query->where('start_date' , '>=' , Carbon::now())->where('start_date', $date_request);
                })
                ->when($activity_type_request , function ($query) use ($activity_type_request){
                    $query->where('activity_type_ar', $activity_type_request);
                })
                ->when($accreditation_request , function ($query) use ($accreditation_request){
                    $query->where('accreditation_ar', $accreditation_request);
                })
                ->get();
        }

//        $courses = Course::filter($subject_area_request, $date_request, $venue_request, $activity_type_request, $accreditation_request)->get();

//        if ($date_request == 'faked'){
//            $courses = Course::where('is_hidden' , 0)->where('subject_area' , $subject_area_request)->where('start_date' , '>=' , Carbon::now())
//                ->orWhere('subject_area_ar' , $subject_area_request)
//                ->orWhere('venue_ar' , $venue_request)
//                ->orWhere('venue',  $venue_request)
//                ->orWhere('start_date' ,  $date_request)
//                ->orWhere('activity_type',  $activity_type_request)
//                ->orWhere('activity_type_ar',  $activity_type_request)
//                ->orWhere('accreditation', $accreditation_request)
//                ->orWhere('accreditation_ar', $accreditation_request)
//                ->orderBy('id' , 'desc')
//                ->get();
//        }else{
//
//            $courses = Course::where('is_hidden' , 0)->where('start_date' , '>=' , Carbon::now())->where('start_date' , $date_request)->get();
//
//        }



//        if ($venue_request != 'faked' && $subject_area_request == 'faked' && $date_request == 'faked' && $activity_type_request == 'faked' && $accreditation_request == 'faked'){
//            $courses = Course::where('is_hidden' , 0)->where('venue' , $venue_request)->get();
//        }


        foreach ( $courses as $key => $course){
            array_push($courses_arr , $course);
        }



        $coursesDropDown = Course::where('is_hidden' , 0)->get();
        $links = 0;
        $date = date('Y-m-d H:i:s');
        $currentDate = Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('m-d-Y');

        return view('website.pages.courses')
            ->with('courses',$courses_arr)
            ->with('links', $links)
            ->with('currentDate' , $currentDate)
            ->with('coursesDropDown' , $coursesDropDown)
            ->with('subject_area' , $subject_area)
            ->with('venue' , $venue)
            ->with('activity_type' , $activity_type)
            ->with('accreditation' , $accreditation)
            ->with('subject_area_request' ,$subject_area_request)
            ->with('venue_request' ,$venue_request)
            ->with('date_request' ,$date_request)
            ->with('activity_type_request' ,$activity_type_request)
            ->with('accreditation_request' ,$accreditation_request)->with('available' , $available)->with('checkLang' , $checkLang);

    }

    public function filterGallery(Request $request){


        $checkLang = 1;
        $course_request = $request->get('course');
        $date_request = $request->get('date');
        if (!empty($date_request)){
            $date_request = Carbon::createFromFormat('m-d-Y', $date_request)->format('Y-m-d');
        }
        $location_request = $request->get('location');

        if (empty($course_request)){
            $course_request = 'faked';
        }
        if (empty($date_request)){
            $date_request = 'faked';
        }
        if (empty($location_request)){
            $location_request = 'faked';
        }
        $courses = Course::where('is_hidden' , 0)->with('galleries')->whereHas('galleries' , function ($query){
            $query->where('course_id' , '!=' , null);
        })->get();
        $locations = Country::all();
        if ($course_request == 'all' || $location_request == 'all'){
            $gallery = Gallery::with('location')->with('course')->get();
        }elseif ($course_request == 'other'){
            $gallery = Gallery::with('location')->with('course')->where('course_id' , null)->get();
        }elseif ($course_request != 'faked' && $date_request == 'faked' && $location_request == 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('course_id' , $course_request)->get();
        }elseif ($course_request != 'faked' && $date_request != 'faked' && $location_request == 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('course_id' , $course_request)->where('date' , $date_request)->get();
        }elseif ($course_request != 'faked' && $date_request != 'faked' && $location_request != 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('course_id' , $course_request)->where('date' , $date_request)->where('location_id' , $location_request)->get();
        }elseif ($course_request == 'faked' && $date_request != 'faked' && $location_request == 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('date' , $date_request)->get();
        }elseif ($course_request == 'faked' && $date_request != 'faked' && $location_request != 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('date' , $date_request)->where('location_id' , $location_request)->get();
        }elseif ($course_request == 'faked' && $date_request == 'faked' && $location_request != 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('location_id' , $location_request)->get();
        }elseif ($course_request != 'faked' && $date_request == 'faked' && $location_request != 'faked'){
            $gallery = Gallery::with('location')->with('course')
                ->where('course_id' , $course_request)->where('location_id' , $location_request)->get();
        }else{
            $gallery = Gallery::with('location')->with('course')
                ->where('course_id' , $course_request)
                ->orWhere('date' , $date_request)
                ->orWhere('location_id' , $location_request)
                ->orderBy('id' , 'desc')
                ->get();
        }

        $links = 0;

        return view('website.pages.gallery')
            ->with('locations',$locations)
            ->with('courses',$courses)
            ->with('gallery' , $gallery)
            ->with('links',  $links)->with('date' , $date_request)
            ->with('course_request' , $course_request)
            ->with('date_request' , $date_request)
            ->with('location_request' , $location_request)->with('checkLang' , $checkLang);



    }

    public function newsletter(Request $request){

	    try{

            $validateForm = Validator::make($request->all(),[
                'email'   => 'required|email|unique:newsletter_emails',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }
            $providedData = $request->all();

            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/Newsletter-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood Newsletter";
                $emailBody = "Thank you for subscribing to our newsletter , you will be able to get the updates of our latest news , and we assure you that your data will be dealt with according to our privacy policy";
                $link_text = "Check our privacy policy";

            }else{
                $path = asset('frontend/images/After/Newsletter-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "النشرة البريدية";
                $emailBody = "شكراً لك , ستتمكن من الاطلاع على اخر التحديثات والأخبار , مع التأكيد بأننا نتعامل مع بياناتك وفق سياسة الخصوصية";
                $link_text = "تحقق من سياسة الخصوصية";
            }

            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));

//            try {
//                Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
//                    $message->from('info@rumman.tech', ' Aljhood ');
//                    $message->sender('info@rumman.tech', ' Aljhood ');
//                    $message->to($email);
//                    $message->subject($emailSubject);
//                    $message->attach($path);
//                });
//
//            } catch (\Exception $e) {
//                return redirect()->back()->with('success', $e->getMessage());
//            }

            NewsletterEmails::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Thanks For Subscribing.');
            return view('errors.thank-you');
        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }
    public function setSession(){
        try{


            session(['session' => 1]);
            return 'success';

        } catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function contactForm(Request $request){
        try {
            $validateForm = Validator::make($request->all(),[
                'name'   => 'required',
                'email'   => 'required|email',
            ]);

            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/Contact-us-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood Contact Us";
                $emailBody = "Thank you for contacting us , you may also find answers to some of your questions on your FAQ page, and we assure you that your data will be dealt with according to our privacy policy.";
                $link_text = "Check our privacy policy";

            }else{
                $path = asset('frontend/images/After/Contact-us-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "تواصل معنا";
                $emailBody = "سيتم التواصل معك قريباً , نود إعلامك أنه بإمكانك أيضاً العثور على إجابات لبعض أسئلتك في صفحة الأسئلة الاكثر تكراراً , مع التأكيد بأننا نتعامل مع بياناتك وفق سياسة الخصوصية.";
                $link_text = "تحقق من سياسة الخصوصية";
            }

            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));

//            try {
//                Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
//                    $message->from('info@rumman.tech', ' Aljhood ');
//                    $message->sender('info@rumman.tech', ' Aljhood ');
//                    $message->to($email);
//                    $message->subject($emailSubject);
//                    $message->attach($path);
//                });
//
//            } catch (\Exception $e) {
//                return redirect()->back()->with('success', $e->getMessage());
//            }

            Report::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Thanks');
            return 'success';
        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function joinForm(Request $request){
        try {
            $validateForm = Validator::make($request->all(),[
                'first_name'   => 'required',
                'email'   => 'required|email',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();
            // return $request->file('resume');

            // if($request->file('resume') != null){
            //     $filename = MediaFile::singleObject()->uploadFile($request->file('resume'),'resumes');
            //     $providedData['resume'] = $filename;
            // }else{
            //     $providedData['resume'] = '';
            // }

            if($request->file('resume')) {

                $image = $request->file('resume');
                $image_name = time(). '.' . $image->getClientOriginalExtension();
                $destinationPath = $image->storeAs('uploads/resumes', $image_name);
                $providedData['resume'] = $image_name;

            }

//            return $providedData;

            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/join-us-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood Join Us";
                $emailBody = "We appreciate you interest , We have successfully received your submitted request , and we assure you that your data will be dealt with according to our privacy policy.";
                $link_text = "Check our privacy policy";
            }else{
                $path = asset('frontend/images/After/join-us-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "انضم لنا";
                $emailBody = "نقدر اهتمامك , لقد تلقينا طلبك بنجاح , مع التاكيد بأننا نتعامل مع بياناتك وفق سياسة الخصوصية";
                $link_text = "تحقق من سياسة الخصوصية";
            }

            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));
//            try {
//                Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
//                    $message->from('info@rumman.tech', ' Aljhood ');
//                    $message->sender('info@rumman.tech', ' Aljhood ');
//                    $message->to($email);
//                    $message->subject($emailSubject);
//                    $message->attach($path);
//                });
//
//            } catch (\Exception $e) {
//                return redirect()->back()->with('success', $e->getMessage());
//            }

            Report::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Thanks');
            return 'success';
        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function suggestForm(Request $request){
        try {
            $validateForm = Validator::make($request->all(),[
                'first_name'   => 'required',
                'email'   => 'required|email',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if($request->file('resume')) {

                $image = $request->file('resume');
                $image_name = time(). '.' . $image->getClientOriginalExtension();
                $destinationPath = $image->storeAs('uploads/resumes', $image_name);
                $providedData['resume'] = $image_name;

            }

            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/Suggest-course-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood Suggest a course";
                $emailBody = "Thank you , Your needs and suggestions are the first steps in the instructional design , and we assure you that your data will be dealt with according to our privacy policy.";
                $link_text = "Check our privacy policy";
            }else{
                $path = asset('frontend/images/After/Suggest-course-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "اقترح دورة";
                $emailBody = "شكراً لك , تلبية احتياجاتكم و مقترحاتكم هي الخطوة الأولى في التصميم التعليمي , مع التأكيد بأننا نتعامل مع بياناتك وفق سياسة الخصوصية.";
                $link_text = "تحقق من سياسة الخصوصية";
            }

            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));
//            try {
//                Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
//                    $message->from('info@rumman.tech', ' Aljhood ');
//                    $message->sender('info@rumman.tech', ' Aljhood ');
//                    $message->to($email);
//                    $message->subject($emailSubject);
//                    $message->attach($path);
//                });
//
//            } catch (\Exception $e) {
//                return redirect()->back()->with('success', $e->getMessage());
//            }


            Report::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Thanks');
            return 'success';
        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }
    public function resellerForm(Request $request){
        try {
            $validateForm = Validator::make($request->all(),[
                'first_name'   => 'required',
                'email'   => 'required|email',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();

            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/Reseller-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood , Reseller form";
                $emailBody = "We appreciate your interest , We believe that partnership is the foundation of excellence, you will be contacted by our team, and we assure you that your data will be dealt with according to our privacy policy.";
                $link_text = "Check our privacy policy";

            }else{
                $path = asset('frontend/images/After/Reseller-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "كن موزعاً";
                $emailBody = "نؤمن بأن الشراكة هي أساس التميز , سيتم التواصل معك من قبل فريقنا مع التأكيد باننا نتعامل مع بياناتك وفق سياسة الخصوصية";
                $link_text = "تحقق من سياسة الخصوصية";

            }


            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));

//            try {
//                Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
//                    $message->from('info@rumman.tech', ' Aljhood ');
//                    $message->sender('info@rumman.tech', ' Aljhood ');
//                    $message->to($email);
//                    $message->subject($emailSubject);
//                    $message->attach($path);
//                });
//
//            } catch (\Exception $e) {
//                return redirect()->back()->with('success', $e->getMessage());
//            }

            Report::create($providedData);
            session(['session' => 1]);
            session()->flash('success' , 'Thanks');
            return 'success';
        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function teachForm(Request $request){
        try {
            $validateForm = Validator::make($request->all(),[
                'first_name'   => 'required',
                'email'   => 'required|email',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }

            $providedData = $request->all();


            if (App::getLocale() == 'en'){
                $path = asset('frontend/images/After/join-us-en.jpg');
                $email = $providedData['email'];
                $emailSubject = "Aljhood Join Us";
                $emailBody = "We appreciate you interest , We have successfully received your submitted request , and we assure you that your data will be dealt with according to our privacy policy.";
                $link_text = "Check our privacy policy";

            }else{
                $path = asset('frontend/images/After/join-us-ar.jpg');
                $email = $providedData['email'];
                $emailSubject = "انضم لنا";
                $emailBody = "نقدر اهتمامك , لقد تلقينا طلبك بنجاح , مع التاكيد بأننا نتعامل مع بياناتك وفق سياسة الخصوصية";
                $link_text = "تحقق من سياسة الخصوصية";

            }


            $details = [
                'title' => $emailSubject,
                'body' => $emailBody,
                'path' => $path,
                'link_text' => $link_text,
            ];

            // \Mail::to($email)->send(new \App\Mail\RespondersMail($details));

            // try {
            //     Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
            //         $message->from('info@aljhood.com', ' Aljhood ');
            //         $message->sender('info@aljhood.com', ' Aljhood ');
            //         $message->to($email);
            //         $message->subject($emailSubject);
            //         $message->attach($path);
            //     });

            // } catch (\Exception $e) {
            //     return redirect()->back()->with('success', $e->getMessage());
            // }


            Report::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Thanks');
            session(['session' => 1]);
            session()->flash('success' , 'Your Application was sent successfully');
            return redirect()->back();
        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function course($id) {
        $course_id = $id;
        $course = Course::findOrFail($course_id);
        $subject_areas = explode(',' , $course->subject_area);
        $subject_areas_ar = explode(',' , $course->subject_area_ar);
        $skills = $course->skills;
        $skills_array = explode(',' , $skills);
        $skills_ar  = $course->skills_ar;
        $skills_array_ar = explode(',' , $skills_ar);
        $accreditation = $course->accreditation;
        $accreditation_array = explode(',' , $accreditation);
        $reviews = CourseReview::where('course_id' , $course_id)->get();
        $slider_videos = VideoReview::where('course_id' , $course_id)->get();

        $currentURL = url()->current();
//        return $currentURL;
        $shareComponent = \Share::page(
            $currentURL,
            $course->title_en,
        )
            ->facebook()
            ->whatsapp()
            ->twitter()
            ->linkedin();



        $arr = Array();
        foreach ($subject_areas as $key => $subject_area){
            $related = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area)->where('id' , '!=' , $course_id)->get();
            foreach ($related as $value){
                array_push($arr, $value);

            }
        }

        $arr_ar = Array();
        foreach ($subject_areas_ar as $key => $subject_area_ar){
            $related_ar = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area_ar)->where('id' , '!=' , $course_id)->get();
            foreach ($related_ar as $value){
                array_push($arr_ar, $value);

            }
        }

        $date   = $course->register_by;

        // courses 2
        $course2_id = $id;
        $course2 = Course::findOrFail($course2_id);
        $subject_areas2 = explode(',' , $course->subject_area);
        $subject_areas_ar2 = explode(',' , $course2->subject_area_ar);
        $skills_ar2  = $course2->skills_ar;
        $skills_array_ar2 = explode(',' , $skills_ar2);
        $accreditation2 = $course2->accreditation;
        $accreditation_array2 = explode(',' , $accreditation2);
        $reviews2 = CourseReview::where('course_id' , $course2_id)->get();
        $slider_videos2 = VideoReview::where('course_id' , $course2_id)->get();

        $currentURL2 = url()->current();
        $shareComponent2 = \Share::page(
            $currentURL2,
            $course2->title_en
        )
            ->facebook()
            ->whatsapp()
            ->twitter()
            ->linkedin();





        $arr2 = Array();
        foreach ($subject_areas2 as $key => $subject_area2){
            $related2 = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area2)->where('id' , '!=' , $course2_id)->get();
            foreach ($related2 as $value2){
                array_push($arr2, $value2);

            }
        }

        $arr_ar2 = Array();
        foreach ($subject_areas_ar2 as $key => $subject_area_ar2){
            $related_ar2 = Course::where('is_hidden' , 0)->where('subject_area' ,$subject_area_ar2)->where('id' , '!=' , $course2_id)->get();
            foreach ($related_ar2 as $value2){
                array_push($arr_ar2, $value2);

            }
        }

        $date2   = $course2->register_by;




        return view('website.pages.inner-courses')
            ->with('course' , $course)
            ->with('reviews' , $reviews)
            ->with('skills' , $skills_array)->with('skills_ar' , $skills_array_ar)
            ->with('subject_area' , $subject_areas)->with('subject_area_ar' , $subject_areas_ar)->with('shareComponent' , $shareComponent)
            ->with('accreditations' , $accreditation_array)
            ->with('related_courses' , $arr)->with('related_courses_ar' , $arr_ar)
            ->with('videos' , $slider_videos)->with('date' , $date)
            ->with('course2' , $course2)
            ->with('reviews2' , $reviews2)
            ->with('skills_ar2' , $skills_array_ar2)
            ->with('subject_area_ar2' , $subject_areas_ar2)->with('shareComponent2' , $shareComponent2)
            ->with('accreditations2' , $accreditation_array2)
            ->with('related_courses_ar2' , $arr_ar2)
            ->with('videos2' , $slider_videos2)->with('date2' , $date2)->with('related_courses2' , $arr2);
    }

    public function blog($id){
        $blog_id = $id;
        $this->blog_id = $blog_id;
        $blog = News::findOrFail($blog_id);
        $blogs = News::where('is_blog',1)->get();
        $sliderArr1 = BlogSlider::where('priority' , '!=' , null)->orderBy('priority' , 'asc')->get();
        $sliderArr2 = BlogSlider::where('priority' ,  null)->orderBy('id' , 'desc')->get();
        $blog_slider = Array();
        foreach ($sliderArr1 as $arr){
            array_push($blog_slider , $arr);
        }
        foreach ($sliderArr2 as $arr){
            array_push($blog_slider , $arr);
        }
//        $blog_slider = BlogSlider::all();
        $related_courses = Course::where('is_hidden' , 0)->with('blogCourses')->whereHas('blogCourses' , function ($query){
            $query->where('blog_id' , $this->blog_id);
        })->get();


        $currentURL = url()->current();
        $shareComponent = \Share::page(
            $currentURL,
            $blog->title_en,
                )
            ->facebook()
            ->twitter()
            ->linkedin()
            ->whatsapp();
//                return $currentURL;
        return view('website.pages.inner-blog')
            ->with('blogs' , $blogs)
            ->with('blog' , $blog)
            ->with('shareComponent' , $shareComponent)
            ->with('related_courses' , $related_courses)
            ->with('sliders' , $blog_slider);
    }

    public function news($id){
        $news_id = $id;
        $recent_news = News::where('is_blog',0)->orderBy('id' , 'desc')->get();
        $keep_reading = News::where('is_blog',0)->where('id','!=' , $news_id)->orderBy('id' , 'desc')->get();
        $news = News::where('id',$news_id)->where('is_blog',0)->Paginate(6);
        if( count($news) != 1) return redirect(404);

        $currentURL = url()->current();
        $shareComponent = \Share::page(
            $currentURL,
            $news[0]->title_en,
                )
            ->facebook()
            ->whatsapp()
            ->twitter()
            ->linkedin();

        return view('website.pages.inner-news')
            ->with('news',$news)
            ->with('recent_news',$recent_news)
            ->with('shareComponent' , $shareComponent)->with('keep_reading' , $keep_reading);
    }
    public function gallery($id){
        $gallery_id = $id;


        $gallery = Gallery::with('course')
            ->with('location')
            ->find($gallery_id);

        $currentURL = url()->current();
        $shareComponent = \Share::page(
            $currentURL,
            $gallery->title_en
                )
            ->facebook()
            ->twitter()
            ->linkedin()
            ->whatsapp();

        $gallery_images = explode(',', $gallery->files);
        if(!$gallery) return redirect(404);

        return view('website.pages.inner-gallery')
            ->with('gallery_images', $gallery_images)
            ->with('gallery',$gallery)->with('shareComponent' , $shareComponent);

    }
    public function applyToCourse($id){
        $course_id = $id;
        $course = Course::where('id' , $course_id)->get();
//                return $related;

        return view('website.pages.apply-course')
            ->with('course' , $course);
    }

    public function courseApplication(Request $request){
     
        try {
            $validateForm = Validator::make($request->all(),[
                'name'   => 'required',
                'email'   => 'required|email',
                'number'   => 'required',
                'country'   => 'required',
                'job_title'   => 'required',
            ]);


            if($validateForm->fails()){

                session()->flash('errors', $validateForm->errors());
                return redirect()->back();
            }
            $providedData = $request->all();

            if (isset($providedData['gender']) && $providedData['gender']=="female"){
            $providedData['gender']="female";
            }else{
            $providedData['gender']="male";
            }
//            return $providedData;


            $providedData['birthdate']=$providedData['day'].'-'.$providedData['month'].'-'.$providedData['year'];
            $providedData['number']=$providedData['countryCode'].$providedData['number'];
            
            
            if($request->file('cv')) {

                $image = $request->file('cv');
                $image_name = time(). '.' . $image->getClientOriginalExtension();
                $destinationPath = $image->storeAs('uploads/courseApplication', $image_name);
                $providedData['cv'] = $image_name;

            }

            $path = public_path('frontend/images/reports/Suggest-course-en.jpeg');
            $email = $providedData['email'];
            $emailSubject = "Aljhood Suggest a course";
            $emailBody = "Thank you , Your needs and suggestions are the first steps in the instructional design , and we assure you that your data will be dealt with according to our privacy policy.";

            // try {
            //     Mail::raw($emailBody, function ($message) use ($emailSubject , $email , $path) {
            //         $message->from('info@rumman.tech', ' Aljhood ');
            //         $message->sender('info@rumman.tech', ' Aljhood ');
            //         $message->to($email);
            //         $message->subject($emailSubject);
            //         $message->attach($path);
            //     });

            // } catch (\Exception $e) {
            //     return redirect()->back()->with('success', $e->getMessage());
            // }


            CourseApplication::create($providedData);

            session(['session' => 1]);
            session()->flash('success' , 'Your Application was sent successfully');
            return redirect()->back();


        }catch (Exception $e) {
            report($e);
            return $e->getMessage();
        }
    }

    public function testMail(Request $request){
        $details = [
            'title' => 'Mail from ItSolutionStuff.com',
            'body' => 'This is for testing email using smtp',
        ];

        // \Mail::to('ahmad.izzat@mcibs.net')->send(new \App\Mail\RespondersMail($details));

        dd("Email is Sent.");
    }
}
