<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \Exception;
use \Validator;
use \Session;
use App\Models\User;
use App\Models\News;
use App\Models\Gallery;
use App\Models\Course;
use App\Models\Country;
use Illuminate\Support\Facades\Hash;

/**
 * ajax controller for webiste
 */

class AjaxController extends Controller {

	public function getGalleryContent(Request $request)
	{

		$gallery   = [];
		$take      = ( !empty($request->input('take_courses')) ) ? $request->input('take_courses') : 9;
		$course_id = ( $request->input('course_id') == 'all' )   ? null : $request->input('course_id');
		$lacation  = ( $request->input('lacation') == 'all' )    ? null : $request->input('lacation');

		# pagination
		$page = 1;
	    if($request->has('page') && $request['page'] > 0 ){
	        $page = (int)$request['page'];
	    }

	    $limit = 9;
	    $offset = ($page - 1) * $limit;

		if ( $request->input('filter') == 0 ) {

			$gallery = Gallery::with('location')->with('course')->take($take)->get();
			return response()->json(['status' => 200, 'gallery' => $gallery, 'page' => $page]);
		}

		$course_date = $request->input('course_date');


		if ( $request->input('filter') == 1 && !empty($course_id) && !empty($lacation)
		&& !empty($request->input('course_date')) ) {

			$gallery = Gallery::with('location')->with('course')->where('course_id', $course_id)
		               ->where('location_id', $lacation)
		               ->whereHas('course', function($query) use($course_date) {
		               	$query->where('start_date', $course_date);
		               })
					   ->offset($offset)
					   ->limit($limit)
		               ->get();

		}elseif ( $request->input('filter') == 1 && !empty($course_id) && !empty($lacation) ){

			$gallery = Gallery::with('location')->with('course')->where('course_id', $course_id)
		               ->where('location_id', $lacation)
					   ->offset($offset)
					   ->limit($limit)
		               ->get();


		}elseif ( $request->input('filter') == 1 && !empty($course_id) && !empty($request->input('course_date')) ) {

			$gallery = Gallery::with('location')->with('course')->where('course_id', $course_id)
		               ->whereHas('course', function($query) use($course_date) {
		               	$query->where('start_date', $course_date);
		               })
					   ->offset($offset)
					   ->limit($limit)
		               ->get();


		}elseif ( $request->input('filter') == 1 &&  !empty($lacation) && !empty($request->input('course_date')) ) {

			$gallery = Gallery::with('location')->with('course')->where('location_id', $lacation)
		               ->whereHas('course', function($query) use($course_date) {
		               	$query->where('start_date', $course_date);
		               })
					   ->offset($offset)
					   ->limit($limit)
		               ->get();


		}elseif ( $request->input('filter') == 1 &&  !empty($course_id) ) {

			$gallery = Gallery::with('location')->with('course')
			           ->where('course_id', $course_id)
					   ->offset($offset)
					   ->limit($limit)
		               ->get();


		}elseif ( $request->input('filter') == 1 &&  !empty($request->input('course_date')) ) {

			$gallery = Gallery::with('location')->with('course')
		               ->whereHas('course', function($query) use($course_date) {
		               	$query->where('start_date', $course_date);
		               })
					   ->offset($offset)
					   ->limit($limit)
		               ->get();


		}elseif ( $request->input('filter') == 1 &&  !empty($lacation) ) {

			$gallery = Gallery::with('location')->with('course')
			           ->where('location_id', $request->input('lacation'))
					   ->offset($offset)
					   ->limit($limit)
		               ->get();

		}else{

			$gallery = Gallery::with('location')->with('course')
					   ->offset($offset)
					   ->limit($limit)
		               ->get();
		}

		return response()->json(['status' => 200, 'gallery' => $gallery, 'page' => $page]);
	}
	//getGalleryContent
}
