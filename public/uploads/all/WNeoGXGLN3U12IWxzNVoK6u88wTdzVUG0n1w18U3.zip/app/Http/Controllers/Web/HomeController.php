<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ActivityType;
use App\Models\Banner;
use App\Models\Counter;
use App\Models\Course;
use App\Models\PageContent;
use App\Models\SliderVideo;
use App\Models\SubjectArea;
use App\Models\Testimonial;
use App\Models\TrustedAccreditation;
use App\Models\Venue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {
        $counterArr1 = Counter::where('priority', '!=', null)->orderBy('priority', 'asc')->get();
        $counterArr2 = Counter::where('priority', null)->orderBy('id', 'desc')->get();
        $counters = Array();
        foreach ($counterArr1 as $arr) {
            array_push($counters, $arr);
        }
        foreach ($counterArr2 as $arr) {
            array_push($counters, $arr);
        }

        $courses = Course::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
        $subject_area = SubjectArea::all();
        $venue = Venue::all();
        $activity_type = ActivityType::all();
        $accreditation = TrustedAccreditation::all();
        $banners = Banner::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->limit(5)->get();
        $slider_videos = SliderVideo::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
        $testimonials = Testimonial::orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->get();
        $counter1 = Counter::findOrFail(1);
        $counter2 = Counter::findOrFail(2);
        $counter3 = Counter::findOrFail(3);
        $content = PageContent::findOrFail(1);
        $block1 = PageContent::findOrFail(66);
        $block2 = PageContent::findOrFail(67);
        $block3 = PageContent::findOrFail(68);

        return view('website.home.test')
            ->with('courses', $courses)
            ->with('subject_area', $subject_area)
            ->with('venue', $venue)
            ->with('activity_type', $activity_type)
            ->with('accreditation', $accreditation)
            ->with('banners', $banners)
            ->with('videos', $slider_videos)
            ->with('testimonials', $testimonials)
            ->with('counter1', $counter1)
            ->with('counter2', $counter2)
            ->with('counter3', $counter3)
            ->with('content', $content)
            ->with('block1', $block1)
            ->with('block2', $block2)
            ->with('block3', $block3)->with('counters', $counters);
    }

}
