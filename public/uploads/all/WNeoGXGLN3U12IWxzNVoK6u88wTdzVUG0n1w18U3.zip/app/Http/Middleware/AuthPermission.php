<?php


namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Models\RolePermission;

class AuthPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        # check if user is super admin
        if (Auth::user()->role_id == 1) {

            return $next($request);
            
        }else{
            
            if($this->checkUserPermission($request)) {

                return $next($request);
            }
            else{

                return redirect('/admin/unauthorized');
            }
        }
    }

    protected function checkUserPermission($request){

        $role_permissions = RolePermission::where('role_id','=',Auth::user()->role_id)->with('permission')->get()->pluck('permission.name');
        $route_split = explode('@', $request->route()->getActionName()); //to get controller name and method
        $controller = explode('\\', $route_split[0])[sizeof(explode('\\', $route_split[0])) - 1];
        $model = explode('Controller',$controller)[0];
        $action = $route_split[1];
        $permission_name = $model.'.'.$action;
        if(in_array($permission_name,$role_permissions->toArray())){
            return true;
        }
        else{
            return false;
        }
    }
}
