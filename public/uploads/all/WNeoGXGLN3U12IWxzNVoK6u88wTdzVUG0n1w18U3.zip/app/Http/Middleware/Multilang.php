<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;

class Multilang
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $local = (in_array(session('locale'),config('app.locales'))?session('locale'):config('app.fallback_locale'));

        if(!empty($request['lang']) && in_array($request['lang'],config('app.locales'))){
            app()->setlocale($request['lang']);
            Session::put('locale',$request['lang']);
            return redirect()->back();
        }
        else{
            app()->setLocale($local);
            Session::put('locale',session('locale'));
        }
        // set localization

        return $next($request);
    }
}
