<!DOCTYPE html>
<html lang="en">
<head>
    <!-- set the encoding of your site -->
    <meta charset="utf-8">
    <!-- set the viewport width and initial-scale on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- set the HandheldFriendly -->
    <meta name="HandheldFriendly" content="True">
    <!-- set the description -->
    @if(app()->getLocale() == 'en')
        <meta name='description'         content='{{ $blog->title_en }}'>
        <meta property='og:description'  content='{{ $blog->meta_description_en }}'>
        <meta name='twitter:description' content='{{ $blog->meta_description_en }}'>
    @else
        <meta name='description'         content='{{ $blog->title_ar }}'>
        <meta property='og:description'  content='{{ $blog->meta_description_ar }}'>
        <meta name='twitter:description' content='{{ $blog->meta_description_ar }}'>
    @endif
    <meta property="og:image"  content="{{ asset('storage/uploads/news') }}/{{ $blog->file }}">
    <meta name="twitter:image" content="{{ asset('storage/uploads/news') }}/{{ $blog->file }}">
    <!-- set the Keyword -->
    <meta name="keywords" content="aljhood">
    <meta name="author" content="aljhood">
    <!-- base url -->
    <meta name="base_url" content="{{url('/')}}">
    <!-- csrf token -->
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <!-- set the page title -->
    @if(app()->getLocale() == "en")
        <title>AL JHOOD - {{ $blog->title_en }}</title>
    @else
        <title class="rtl">الجهود - {{ $blog->title_ar }}</title>
    @endif

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
    <!-- include google roboto font cdn link -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
    <!-- include the site bootstrap stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
    <!-- include the plugins stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
    <!-- include the colors stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/colors.css") }}">
    <!-- include the custom stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/custom.css") }}">
    <!-- include the site responsive stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
    <!-- include pannellum 360 image viewer -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/>
    <!-- include animate css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <style>
        #social-links{
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: center;
        }
        #social-links ul{
            list-style: none;
            display: contents;
            flex-direction: row;
            justify-content: flex-end;
            align-items: center;
        }

        #social-links ul li{
            list-style: none;
            margin: 0 10px;
        }

        #social-links ul li a{
            font-size: 20px;
        }
        .share{
            display: flex;
            flex-direction: row;
            justify-content: flex-end;
            align-items: center;
        }
        .share p{
            margin-bottom: 0 !important;
        }
    </style>

    @if(app()->getLocale() == "ar")
        <style>
            @font-face {
                font-family: 'URWGeometric';
                src: url('{{ url('/') }}/frontend/css/fonts/URWG.ttf') format('truetype');
            }
            a, p, span, li, h1, h2, h3, h4, h5, h6, input, label, textarea, datalist , dd , div , font , blockquote , strong{
                font-family: URWGeometric;
            }
            blockquote{
                font-family: URWGeometric !important;
            }
            li a{
                font-family: URWGeometric !important;
            }
            strong{
                font-family: URWGeometric !important;
            }

            h3  a{
                font-family: URWGeometric !important;

            }
            .popular-posts-slider .slick-arrow {
                right: unset;
            }
            @media only screen and (max-width: 767px) {
                .popular-posts-slider .slick-arrow {
                    left: 14% !important;
                }
            }
            @media (max-width: 767px) {
                .page-header-blog .navbar-default .navbar-nav > li > a{
                    text-align: right;
                }
                .main-navigation{
                    padding: 0;
                }
                .page-header-blog .navbar-default .navbar-nav > .dropdown:after{
                    left: unset !important;
                    right: 90%;
                }
                .ul-nopad{
                    padding: 0;
                }
                .ul-nopad1{
                    padding: 0;
                    margin: 13px 0 0 0;
                }
            }
        </style>
    @else
        <style>
            @media (max-width: 767px) {
                .page-header-blog .navbar-default .navbar-nav > li > a{
                    text-align: left !important;
                }
                .main-navigation{
                    padding: 0;
                }
                .page-header-blog .navbar-default .navbar-nav > .dropdown:after{
                    left: unset !important;
                }
                .navbar-search-form{
                    margin: 0 15px 0 0;
                }
                .ul-nopad{
                    padding: 0;
                }
                .ul-nopad1{
                    padding: 0;
                    margin: 13px 0 0 0;
                }
            }
        </style>
    @endif
</head>
<body id="bolg_content">

@php
    use Carbon\Carbon;

    $time = Carbon::now();
    $end_of_url = explode('.', \Request::route()->getName());
    $end_of_url = end($end_of_url);
@endphp

<?php 
$blog_title="title_".app()->getLocale();
$content_title="content_".app()->getLocale();
$image_src=$blog->inner_image?"inner_image":"file";
?>

<?php 
$useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
$devic=1;

}else{
$devic=0;
}
?>
<!-- main container of all the page elements -->
<div id="wrapper">
    <!-- header of the page -->
    
    @if(app()->getLocale() == "en")
    <?php $dir="ltr";
    $order="asc";
    $text_align="text-align:left;";
    ?>
    @else
     <?php $dir="rtl";
     $order="desc";
     $text_align="text-align:right;";
     ?>
    @endif
@if($devic)    
<?  $order="asc";?>
@endif
    
<!-- main container of all the page elements -->
<div id="wrapper">


        <header id="page-header" class="page-header-stick"
                style="{{ ($end_of_url) != 'home' ? 'background: #222;' : '' }} direction:">
            <!-- top bar -->
            <div class="top-bar bg-dark text-gray">
                <div class="container">
                    <div class="row top-bar-holder">

                    </div>
                </div>
            </div>
            <!-- header holder -->
            <div class="header-holder">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-6 col-sm-3">
                            <!-- logo -->
                            <div class="logo">
                                <a href="{{ url('/') }}">
                                    <img class="hidden-xs" src="{{ asset("frontend/images/logos/logo.png") }}"
                                         alt="aljhood">
                                    <img class="hidden-sm hidden-md hidden-lg"
                                         src="{{ asset("frontend/images/logos/logo-dark.png") }}"
                                         alt="aljhood">
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-6 col-sm-9 static-block">
                            <!-- nav -->
                            <nav id="nav" class="navbar navbar-default">
                                <!-- navbar collapse -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <!-- main navigation -->
                                    <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato">


                                       <?php 
                                       $menu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=','0')->orderBy('element_order',$order)->get();
                                       $Name_Field="name_".app()->getLocale();
                                       ?>
                                       @foreach($menu_items as $menu_item)
                                       <?php $submenu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->orderBy('element_order',$order)->get();
                                       $submenu_item_found=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->first();
                                       ?>

                                            @if($submenu_item_found!=null)
                                            <li class="dropdown">
                                            <a href="{{ url($menu_item->url)}}" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">{{$menu_item->$Name_Field}}</a>
                                            <ul class="dropdown-menu" style="text-align:left; direction:{{$dir}};">
                                            @foreach($submenu_items as $submenu_item)
                                            <li><a href="{{ url($submenu_item->url)}}">{{$submenu_item->$Name_Field}}</a></li>
                                           @endforeach
                                           </ul>
                                           </li> 
                                           @else
                                           <li><a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a></li>
                                           @endif
                                           @endforeach 
                                    </ul>
                                </div>
                                <!-- navbar form -->
                                <form hidden action="{{ url('search') }}" method="GET"
                                      class="navbar-form navbar-search-form navbar-right">
                                    <a class="fas fa-search search-opener" role="button" data-toggle="collapse"
                                       href="#searchCollapse" aria-expanded="false" aria-controls="searchCollapse">
                                        <span class="sr-only">search opener</span>
                                    </a>
                                    <!-- search collapse -->
                                    <div class="collapse search-collapse" id="searchCollapse">
                                        <div class="form-group" DIR="LTR">
                                            <input type="text" name="search_word" pattern=".*\S+.*"
                                                   title="This field is required" class="form-control"
                                                   placeholder="Search for courses, news &hellip;" required="required">
                                            <button type="submit" class="fas fa-search btn"><span
                                                    class="sr-only">search</span></button>
                                        </div>
                                    </div>
                                </form>
                                <span class="lang_switcher" hidden>
                                    @if(isset($lang))
                                        @if(str_contains(url()->current() , 'filterCourse'))
                                            <a id="changeLang" href="javascript:void(0)"
                                               class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                    <span class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                                @else
                                                    EN
                                                @endif
                                            </a>
                                        @else
                                            <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '&lang=ar':request()->getRequestUri() . '&lang=en'}}"
                                               class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                    <span class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                                @else
                                                    EN
                                                @endif
                                            </a>

                                        @endif
                                    @else
                                        @if(str_contains(url()->current() , 'filterCourse'))
                                            <a id="changeLang" href="javascript:void(0)"
                                               class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                    <span class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                                @else
                                                    EN
                                                @endif
                                            </a>
                                        @else
                                            <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}"
                                               class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                    <span class="URWGeometric" style="font-family: URWGeometric !important;">AR</span>
                                                @else
                                                    EN
                                                @endif
                                            </a>
                                        @endif
                                    @endif
                            </span>
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                            data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>

    <!-- contain main informative part of the site -->
    <main id="main">
        <!-- two columns -->
        <!-- two columns -->

      <section id="values" class="values mb-5 mt-5">
      <div class="container-fluid" data-aos="fade-up">
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
                  
                 <div class="col-lg-10" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
        <img  src="{{ asset('storage/uploads/news') }}/{{ $blog->$image_src}}" class="element-block image"  alt="no-photo" style="width:100%;">
              <h1 class="gold-color text-center">@php echo $blog->$blog_title; @endphp</h1>


                        <div><p ><strong>@php echo $blog->$content_title @endphp</strong></p>            
                        <div id="social-links">
	<ul>
		<li><a href="https://www.facebook.com/sharer/sharer.php?u={{URL::current()}}" class="social-button " id=""><span class="fa fa-facebook"></span></a></li>
		<li><a href="https://twitter.com/intent/tweet?text=&amp;url={{URL::current()}}" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
		<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{URL::current()}}&amp;title=my share text&amp;summary=" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
		<li><a href="https://wa.me/?text={{URL::current()}}" class="social-button " id=""><span class="fa fa-whatsapp"></span></a></li>    
	</ul>
</div>   

                        </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
          </div>
      </div>
    </section><br><br>

<?php 
$explore_more = DB::table('news')->where('is_blog' , 1)->where('explore_more' , 1)->orderBy(DB::raw('ISNULL(priority), priority'), 'ASC')->limit(3)->get();
$TitleText="title_".app()->getLocale();
?>
 
            <div class="container blog-section {{$dir}}">
                <header class="popular-posts-head">
                            <h2 class="popular-head-heading hr_head">{{trans('messages.explore_more_topics')}}</h2>
                </header>
                <div class="row {{$dir}}">
                            @foreach($explore_more as $explore)
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out" onclick="blogFunction({{ $explore->id }})" style="cursor: pointer">
                            <a href="{{ url('blog') }}/{{ $explore->id }}#innerBlogTitle">
                                <div class="contentRightImage" style="margin:20px auto; height:100% !important;">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $explore->file }}" alt="image description" style="height:100% !important;">
                                    <div class="imageCaption text-center text-white">
                                        <a href="{{ url('blog') }}/{{ $explore->id }}#innerBlogTitle">{{ $explore->$TitleText }}</a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>



    </main>
<br><br><div style="height:3px; background-color:#be9f56;"></div><br><br>
    
    <!-- footer area container -->
    <div class="footer-area bg-dark text-gray blog-footer">
        <div class="container">
            <div class="col-md-12" style="text-align: center;">
                <img src="{{ asset('../frontend/images/logos/logo-dark.png') }}" width="300">
            </div>
            <div class="col-md-12">
                <ul class="socail-networks list-unstyled">
                    <li><a href="https://www.facebook.com/AljhoodGroup" target="_blank"><span class="fab fa-facebook"></span></a>
                    </li>
                    <li><a href="https://twitter.com/AljhoodGroup" target="_blank"><span class="fab fa-twitter"></span></a></li>
                    <li><a href="https://www.instagram.com/aljhoodgroup/" target="_blank"><span class="fab fa-instagram"></span></a></li>
                    <li><a href="https://www.linkedin.com/company/aljhoodgroup/" target="_blank"><span class="fab fa-linkedin">
						</span></a></li>
                    <li><a href="http://api.whatsapp.com/send?phone=+962776003400" target="_blank"><span class="fab fa-whatsapp">
						</span></a></li>
                    <li><a href="https://www.youtube.com/channel/UCa3k29T1ZwytTkC3bC0mBGw" target="_blank"><span class="fab fa-youtube">
						</span></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- back top of the page -->
    <span id="back-top" class="text-center fa fa-caret-up"></span>
    <span id="whats-app" class="text-center fab fa-whatsapp"></span>
    <!-- loader of the page -->
    <div id="loader" class="loader-holder">
        <div class="block"><img src="{{ asset("frontend/images/svg/hearts.svg") }}" width="100" alt="loader"></div>
    </div>
</div>


<!-- include min jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
<!-- include Plugins -->
<script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
<!-- include jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
<!-- include init js -->
<script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>
<!-- include custom js -->
<script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>
<script>

    var locale = '{{request()->getRequestUri()}}';


    @if(app()->getLocale() == "en")
    $(document).ready( function (){

        if (localStorage.getItem('firstVisit') == null) {

            localStorage.setItem('firstVisit',1);
            window.location.href = locale + '?lang=ar';
        }
    })
    @endif

</script>
<script>

    $('.read_more_btn').click(function(){

        $(this).parent().parent().find('.remaining_content').slideDown(1000);
        $(this).parent().parent().find('.read_less_btn').show();
        $(this).parent().parent().find('.part_contant').hide();
        $(this).hide();
    });

    $('.read_less_btn').click(function(){

        $(this).parent().parent().find('.remaining_content').slideUp(1000,function(){
            $(this).parent().parent().find('.read_more_btn').show();
            $(this).parent().parent().find('.part_contant').show();
        });
        $(this).hide();
    });
</script>
<script>
    $(window).load(function () {
        var blogHeight1 = $('#blogContent').innerHeight();
        var blogHeight2 = $('#blogContent2').innerHeight();
        if (blogHeight1 > blogHeight2){
            $('.hidden-scroll').css({
                height: blogHeight2,
            });
            $('#blogContent2').removeClass('hidden-scroll');
        }else {
            $('.hidden-scroll').css({
                height: blogHeight1,
            });
            $('#blogContent').removeClass('hidden-scroll');
        }
    });
</script>
<script>
    var url = $('meta[name=base_url]').attr("content");

    function courseFunction(id) {
        window.location.href = url + "/course/" + id;
    }
</script>
<script>
    var current_url = window.location.pathname;
    window.onload = function(){
        if (current_url != '/aljhood/courses'){
            localStorage.removeItem('course_select_1');
            localStorage.removeItem('course_select_2');
            localStorage.removeItem('course_select_3');
        }
    }
</script>
<script>
    $(document).ready(function (){
        $('#social-links a').attr('target','_blank');
    })
</script>
<script>
    var x = localStorage.getItem('dark');
    $(window).load(function (){
        if (x == 1){
            $('.popular-posts-slider .slick-arrow').css('color' , '#fff');
        }
    })

</script>

</body>
</html>
