<!------------------------- news content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.fnews'))

@section('content')
<?php
$Title="title_".app()->getLocale();
$news_page_title=DB::table('page_contents')->where('ref_page','news_page_title')->first();
$news_view_more_title=DB::table('page_contents')->where('ref_page','news_view_more_title')->first();
$training_course_review_button=DB::table('page_contents')->where('ref_page','training_course_review_button')->first();
$training_similar_course_title=DB::table('page_contents')->where('ref_page','training_similar_course_title')->first();
if(app()->getLocale()=="en"){
$dir="ltr";   
}else{
$dir="rtl";   
}
?>
    @if(app()->getLocale() == "en")
    <div class="acme-news-ticker">
                    <div class="acme-news-ticker-label" style="float: left !important;">{{$news_page_title->$Title}}</div>

        <div class="acme-news-ticker-box">
            <ul class="my-news-ticker">
                @foreach($breaking_news as $t_news)
                    <a href="{{ url('news') }}/{{ $t_news->id }}"><li> {{$t_news->title_en}} |</li></a>
                @endforeach
            </ul>

        </div>
    </div>

    <section class="intro-block news-intro-block">
        <div class="slider news-slider big-slider">
            @foreach($sliders as $slider)
                <div class="news-test">
                <article class="intro-block-slide overlay bg-cover"style="height: 100vh">

                    <div class="col-md-8" style="background-image: url({{ url('storage/uploads/newsSlider')}}/{{ $slider->image1 }}); background-size:cover; background-repeat: no-repeat; height:100%">
                        <div style="padding:59% 10% 28% 10%;">
                            <div class="anim text-left">
                                <a href="{{ url('/news') }}/{{ $slider->news_id }}" target="_blank" style="color:white;">
                                    <span class=" link-hover intro-block-heading " style="font-size:18px color:#000;"> {{$slider->first_title_en}} </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4" style="background:black; height:100%;padding:0;">
                        <div style="height: 50%; width:100%; background: url('{{ url('storage/uploads/newsSlider')}}/{{ $slider->image2 }}'); background-size:cover; background-repeat: no-repeat;">
                            <div style="padding:54% 5% 5% 5%">
                                <div class="anim text-left">
                                    <a href="{{ url('/news') }}/{{ $slider->news2_id }}" target="_blank" style="color:white;">
                                        <span class=" link-hover intro-block-heading" style="font-size:18px color:#000;">{{$slider->second_title_en}} </span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div style="height: 50%; width:100%; background: url('{{ url('storage/uploads/newsSlider')}}/{{ $slider->image3 }}'); background-size:cover; background-repeat: no-repeat;">
                            <div style="padding:54% 5% 5% 5%">
                                <div class="anim text-left">
                                    <a href="{{ url('/news') }}/{{ $slider->news3_id }}" target="_blank" style="color:white;">
                                        <span class=" link-hover intro-block-heading" style="font-size:18px color:#000;"> {{$slider->third_title_en}} </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            @endforeach
        </div>
        <div class="slider fade-slider small-slider">
            @foreach($sliders as $slider)
                <div class="test">
                    <!-- intro block slide -->
                    <article class="intro-block-slide overlay bg-cover"
                             style="background-image: url({{ url("storage/uploads/newsSlider")}}/{{ $slider->image1 }});">
                        <div class="align-wrap container">
                            <div class="align">
                                <div class="anim">
                                    <h1 class="intro-block-heading" style="font-size:18px color:#000;"> {{$slider->first_title_en}}</h1>
                                </div>
                                <div class="anim delay1">
                                </div>
                                @if(!empty($slider->news_id))
                                    <div class="anim delay2">
                                        <div class="btns-wrap">
                                            <a href="{{ url('/news') }}/{{ $slider->news_id }}"
                                               class="btn btn-warning btn-theme text-uppercase" target="_blank">{{$news_view_more_title->$Title}} </a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </article>
                </div>
            @endforeach
        </div>
    </section>

    <!-- breadcrumb nav -->
    <nav class="breadcrumb-nav">
        <div class="container">
            <!-- breadcrumb -->
            <ol class="breadcrumb">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li class="active">News</li>
            </ol>
        </div>
    </nav>

    <!-- news block -->
    <section class="news-block bg-gray our-news-block news-6" id="newsSection">
        <div class="container">
            <header class="seperator-head text-center">
                <h2>{{$news_page_title->$Title}}</h2>
            </header>
            <div class="row">
                @php $count = 0; $num = 6; @endphp
                @foreach($news as $new)
                    <div class="col-xs-6 col-sm-6 col-md-6 news-column-page" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                        <!-- news column post -->
                        @php if ($count == $num) break; @endphp
                        <article class="news-column-post" onclick="newsFunction({{ $new->id }})">
                            <div class="alignleft no-shrink">
                                <a href="{{ url('news') }}/{{ $new->id }}">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $new->file }}" alt="no-photo"></a>
                            </div>
                            <div class="descr-wrap">
                                <h3 class="fw-normal" style="line-height: 1.3;"><a
                                        href="{{ url('news') }}/{{ $new->id }}"> {{ $new->title_en}} </a>
                                </h3>
                                <p> {{ strlen($new->meta_description_en) > 50 ? substr($new->meta_description_en,0,50).'...' :
                                    $new->meta_description_en}} </p>
                                <time datetime="2011-01-12"
                                      class="element-block text-uppercase"> {{ date('d-m-Y', strtotime($new->date) ) }} </time>
                            </div>
                        </article>
                        @php $count++; @endphp
                    </div>
                @endforeach
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="news-view-more" style="display: flex; flex-direction: row; justify-content: center">
                    <a href="javascript:void(0)" id="viewMoreNews"
                       class="btn btn-warning btn-theme text-uppercase">{{$news_view_more_title->$Title}}</a>
                </div>
            </div>
        </div>
    </section>
    <section class="news-block bg-gray our-news-block news-more none" id="newsSectionMore">
        <div class="container">
            <header class="seperator-head text-center">
                <h2>{{$news_page_title->$Title}}</h2>
            </header>
            <div class="row">
                @foreach($news as $new)
                    <div class="col-xs-6 col-sm-6 col-md-6 news-column-page" data-aos="fade-up" data-aos-duration="1500" data-aos-easing="ease-in-out">
                        <!-- news column post -->
                        <article class="news-column-post" onclick="newsFunction({{ $new->id }})">
                            <div class="alignleft no-shrink">
                                <a href="{{ url('news') }}/{{ $new->id }}">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $new->file }}" alt="no-photo"></a>
                            </div>
                            <div class="descr-wrap">
                                <h3 class="fw-normal" style="line-height: 1.3;"><a
                                        href="{{ url('news') }}/{{ $new->id }}"> {{$new->title_en}} </a>
                                </h3>
                                <p> {{strlen($new->meta_description_en) > 50 ? substr($new->meta_description_en,0,50).'...' :
                                    $new->meta_description_en}} </p>
                                <time datetime="2011-01-12"
                                      class="element-block text-uppercase"> {{ date('d-m-Y', strtotime($new->date) ) }} </time>
                            </div>
                        </article>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- subscription aside block -->
    <aside class="subscription-aside-block bg-theme text-white">
        <!-- newsletter sub form -->
        <form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form">
            <div class="row form-holder">
                <div class="col-xs-12 col-sm-6 col">
                    <div class="text-wrap">
                            <span class="element-block icn no-shrink rounded-circle"><i
                                    class="far fa-envelope-open"><span class="sr-only">icn</span></i></span>
                        <div class="inner-wrap">
                            <label for="email">Signup for Newsletter</label>
                            <p>Subscribe to get your daily close of useful courses.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col">
                    <div class="input-group">
                        <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email&hellip;">
                        <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">Subscribe</button>
						</span>
                    </div>
                </div>
            </div>
        </form>
    </aside>
    @else
    
        <div class="acme-news-ticker">
            <div class="acme-news-ticker-label" style="float: right !important;"> {{$news_page_title->$Title}}</div>
            <div class="acme-news-ticker-box ">
                <ul class="my-news-ticker">
                    @foreach($news as $t_news)
                        <a href="{{ url('news') }}/{{ $t_news->id }}"><li> {{$t_news->title_ar}} |</li></a>
                    @endforeach
                </ul>
            </div>
            
            
        </div></div>

        <section class="intro-block news-intro-block">
            <div class="slider news-slider big-slider">
                @foreach($sliders as $slider)
                    <div class="news-test">
                        <article class="intro-block-slide overlay bg-cover rtl"style="height: 100vh">
                            <div class="col-md-4" style="background:black; height:100%;padding:0;">
                                <div style="height: 50%; width:100%; background: url('{{ url('storage/uploads/newsSlider')}}/{{ $slider->image2 }}'); background-size:cover; background-repeat: no-repeat;">
                                    <div style="padding:54% 5% 5% 5%">
                                        <div class="anim text-right">
                                            <a href="{{ url('/news') }}/{{ $slider->news2_id }}" target="_blank" style="color:white;">
                                                <span class=" link-hover intro-block-heading " style=" position: absolute; bottom: 5px; right: 20px; text-underline-offset: 29px; width: 80%; line-height: normal; border-right: 10px solid #c09000; height: 120px; color: #444242; padding: 10px 20px; border-radius: 5px; transition: transform 0.3s ease, background-color 0.3s ease; background: #ffffffc9; ">{{$slider->second_title_ar}} </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div style="height: 50%; width:100%; background: url('{{ url('storage/uploads/newsSlider')}}/{{ $slider->image3 }}'); background-size:cover; background-repeat: no-repeat;">
                                    <div style="padding:54% 5% 5% 5%">
                                        <div class="anim text-right">
                                            <a href="{{ url('/news') }}/{{ $slider->news3_id }}" target="_blank" style="color:white;">
                                                <span class=" link-hover intro-block-heading" style=" position: absolute; bottom: 5px; right: 20px; text-underline-offset: 29px; width: 80%; line-height: normal; border-right: 10px solid #c09000; height: 120px; color: #444242; padding: 10px 20px; border-radius: 5px; transition: transform 0.3s ease, background-color 0.3s ease; background: #ffffffc9; "> {{$slider->third_title_ar}} </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 " style="background-image: url({{ url('storage/uploads/newsSlider')}}/{{ $slider->image1 }}); background-size:cover; background-repeat: no-repeat; height:100%">
                                <div style="padding:59% 10% 28% 10%;">
                                    <div class="anim text-right">
                                            <a  href="{{ url('/news') }}/{{ $slider->news_id }}" target="_blank" style="color:white;">
                                            <span class=" link-hover intro-block-heading" style=" font-size: xxx-large !important;position: absolute; bottom: 5px; right: 20px; text-underline-offset: 29px; width: 80%; line-height: normal; border-right: 10px solid #c09000;color: #444242; padding: 10px 20px; border-radius: 5px; transition: transform 0.3s ease, background-color 0.3s ease; background: #ffffffc9; "> {{$slider->first_title_ar}} </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                @endforeach
            </div>

            <div class="slider fade-slider small-slider">
                @foreach($sliders as $slider)
                    <div class="test">
                        <!-- intro block slide -->
                        <article class="intro-block-slide overlay bg-cover rtl"
                                 style="background-image:  url({{ url("storage/uploads/newsSlider")}}/{{ $slider->image1 }});">
                            <div class="align-wrap container">
                                <div class="align text-right">
                                    <div class="anim">
                                        <h1 class="intro-block-heading" style="font-size:18px color:#000;">{{$slider->first_title_ar}}</h1>
                                    </div>
                                    <div class="anim delay1">
                                        <p>  </p>
                                    </div>
                                    @if(!empty($slider->news_id))
                                        <div class="anim delay2">
                                            <div class="btns-wrap">
                                                <a href="{{ url('/news') }}/{{ $slider->news_id }}"
                                                   class="btn btn-warning btn-theme text-uppercase" target="_blank">{{$news_view_more_title->$Title}}</a>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </article>
                    </div>
                @endforeach
            </div>
        </section>

        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li class="active">أخبار مجموعة الجهود</li>
                </ol>
            </div>
        </nav>

        <!-- news block -->
        <section class="news-block bg-gray our-news-block news-6 rtl" id="newsSection">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2>{{$news_page_title->$Title}}</h2>
                </header>
                <div class="row">
                    @php $count = 0; $num = 6; @endphp
                    @foreach($news as $new)
                        <div class="col-xs-6 col-sm-6 col-md-6 news-column-page" style="float: right" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <!-- news column post -->
                            @php if ($count == $num) break; @endphp
                            <article class="news-column-post" onclick="newsFunction({{ $new->id }})">
                                <div class="alignleft no-shrink">
                                    <a href="{{ url('news') }}/{{ $new->id }}">
                                        <img src="{{ asset('storage/uploads/news') }}/{{ $new->file }}" alt="no-photo"></a>
                                </div>
                                <div class="descr-wrap" style="padding: 30px 25px; height: 200px; overflow: hidden; box-shadow: 0px 0px 12px 2px #adadad; text-wrap: auto;">
                                    <h3 class="fw-normal" style="line-height: 1.3;"><a
                                            href="{{ url('news') }}/{{ $new->id }}"> {{$new->title_ar}} </a>
                                    </h3>
                                    <p> {{strlen($new->meta_description_ar) > 50 ? substr($new->meta_description_ar,0,50).'...' :
                                        $new->meta_description_ar}} </p>
                                    <time datetime="2011-01-12"
                                          class="element-block text-uppercase"> {{ date('d-m-Y', strtotime($new->date) ) }} </time>
                                </div>
                            </article>
                            @php $count++; @endphp
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="news-view-more" style="display: flex; flex-direction: row; justify-content: center">
                        <a href="javascript:void(0)" id="viewMoreNews"
                           class="btn btn-warning btn-theme text-uppercase">{{$news_view_more_title->$Title}}</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="news-block bg-gray our-news-block news-more none rtl" id="newsSectionMore">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2>{{$news_page_title->$Title}}</h2>
                </header>
                <div class="row">
                    @foreach($news as $new)
                        <div class="col-xs-6 col-sm-6 col-md-6 news-column-page" style="float: right" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <!-- news column post -->
                            <article class="news-column-post" onclick="newsFunction({{ $new->id }})">
                                <div class="alignleft no-shrink">
                                    <a href="{{ url('news') }}/{{ $new->id }}">
                                        <img src="{{ asset('storage/uploads/news') }}/{{ $new->file }}" alt="no-photo"></a>
                                </div>
                                <div class="descr-wrap" style="padding: 25px 25px; height: 200px; overflow: hidden; box-shadow: 0px 0px 12px 2px #adadad; text-wrap: auto;">
                                    <h3 class="fw-normal" style="line-height: 1.3;"><a
                                            href="{{ url('news') }}/{{ $new->id }}"> {{$new->title_ar}} </a>
                                    </h3>
                                    <p> {{strlen($new->meta_description_ar) > 50 ? substr($new->meta_description_ar,0,50).'...' :
                                        $new->meta_description_ar}} </p>
                                    <time datetime="2011-01-12"
                                          class="element-block text-uppercase"> {{ date('d-m-Y', strtotime($new->date) ) }} </time>
                                </div>
                            </article>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- subscription aside block -->
        <aside class="subscription-aside-block bg-theme text-white rtl">
            <!-- newsletter sub form -->
            <form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form">
                <div class="row form-holder">
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="text-wrap">
                            <span class="element-block icn no-shrink rounded-circle"><i
                                    class="far fa-envelope-open"><span class="sr-only">icn</span></i></span>
                            <div class="inner-wrap">
                                <label for="email">الاشتراك بالنشرة البريدية</label>
                                <p>اشترك للحصول على نهايتك اليومية من الدورات التدريبية المفيدة.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-control" placeholder="ادخل البريد الالكتروني&hellip;">
                            <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">الاشتراك</button>
						</span>
                        </div>
                    </div>
                </div>
            </form>
        </aside>
    @endif
@stop



@section('scripts')


    <script>
        $(window).load(function () {
            $('#viewMoreNews').click(function () {
                $('.news-6').addClass('none');
                $('.news-more').removeClass('none');
                $(window).scrollTop(1000);
            })
        });
    </script>

@stop
