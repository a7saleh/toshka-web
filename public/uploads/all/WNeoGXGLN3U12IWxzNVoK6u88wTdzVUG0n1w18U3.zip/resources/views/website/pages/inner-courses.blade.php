<!------------------------- about us content -------------------------->

@extends('website.layout.master')

@section('title')
    @if(app()->getLocale() == "en")
        {{ $course->title_en }}
    @else
        {{ $course->title_ar }}
    @endif
@endsection

@section('description')
    @if(app()->getLocale() == "en")
        {{ $course->description_en }}
    @else
        {{ $course->description_ar }}
    @endif
@endsection
@section('description_og')
    @if(app()->getLocale() == "en")
        {{ $course->description_en }}
    @else
        {{ $course->description_ar }}
    @endif
@endsection
@section('description_tw')
    @if(app()->getLocale() == "en")
        {{ $course->description_en }}
    @else
        {{ $course->description_ar }}
    @endif
@endsection

@section('image_og')
    {{ asset("storage/uploads/courses") }}/{{ $course->image }}
@endsection
@section('image_tw')
    {{ asset("storage/uploads/courses") }}/{{ $course->image }}
@endsection

@section('content')

<?php
$Title="title_".app()->getLocale();
app()->getLocale()=="en"?$course_details="course_details":$course_details="course_details_".app()->getLocale();
;
$training_course_apply_button=DB::table('page_contents')->where('ref_page','training_course_apply_button')->first();
$training_course_prochure_button=DB::table('page_contents')->where('ref_page','training_course_prochure_button')->first();
$training_course_review_button=DB::table('page_contents')->where('ref_page','training_course_review_button')->first();
$training_similar_course_title=DB::table('page_contents')->where('ref_page','training_similar_course_title')->first();
$training_course_content_title=DB::table('page_contents')->where('ref_page','training_course_content_title')->first();
$Box1="b1_".app()->getLocale();
$Box2="b2_".app()->getLocale();
$Box3="b3_".app()->getLocale();


$time_commitment_img=DB::table('page_contents')->where('ref_page','=','time_commitment_img')->first();
$days_img=DB::table('page_contents')->where('ref_page','=','days_img')->first();
$activity_img=DB::table('page_contents')->where('ref_page','=','activity_img')->first();
$number_modules_img=DB::table('page_contents')->where('ref_page','=','number_modules_img')->first();
$subject_area_img=DB::table('page_contents')->where('ref_page','=','subject_area_img')->first();
$accreditation_img=DB::table('page_contents')->where('ref_page','=','accreditation_img')->first();
$course_language_img=DB::table('page_contents')->where('ref_page','=','course_language_img')->first();
$activity_type_img=DB::table('page_contents')->where('ref_page','=','activity_type_img')->first();
$reviews_course_title=DB::table('page_contents')->where('ref_page','=','reviews_course_title')->first();

$tab1=DB::table('page_contents')->where('ref_page','=','tab1')->first();
$tab3=DB::table('page_contents')->where('ref_page','=','tab3')->first();
$tab4=DB::table('page_contents')->where('ref_page','=','tab4')->first();
$tab5=DB::table('page_contents')->where('ref_page','=','tab5')->first();
$tab6=DB::table('page_contents')->where('ref_page','=','tab6')->first();
$tab7=DB::table('page_contents')->where('ref_page','=','tab7')->first();
if(app()->getLocale()=="en"){
$dir="ltr";
$align="text-left";
}else{
$dir="rtl"; 
$align="text-right";
}
?>
 <?php

$useragent=$_SERVER['HTTP_USER_AGENT'];

if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
$devic=1;

}else{
$devic=0;
}
?>

<div class="container-fluid" style="margin-top:6%; width:100%;">
<div class="container">
<div class="row"  style="box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1), /* ظل ناعم خفيف */ 0 20px 40px rgba(0, 0, 0, 0.2); /* ظل عميق أكثر واقعية */">
    
<div class="col-lg-6 col-md-6" style="max-height: 600px; margin-top: 4%; padding-top: 18px;">  

                        <aside class="col-xs-12 col-md-12" id="sidebar">
                            <!-- widget course select -->
                            <div class="aligncenter" style="margin: 0px">
                                @if(!empty($course->video))
                                    <iframe id="courseImage" src="{{ $course->video }}" title="{{ $course->title_en }}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                               @elseif(!empty($course->inner_image))
                                    <img id="courseImage" src="{{ asset("storage/uploads/courses") }}/{{ $course->inner_image }}" alt="image description" style="height: auto;margin-top: 15px; width: 100%; border-radius: 10px; margin-bottom: 15px;">
                                @else
                                    <img id="courseImage" src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}" alt="image description" style="width: 100%; margin-bottom: 15px;">
                                @endif
                            </div>

                        </aside>
</div>

<div class="col-lg-6 col-md-6 mt-5 text-center">
<h1 style="color: #805900; margin-top: 25px; margin-bottom: 25px; border-radius: 29px 5px; DISPLAY: BLOCK; border-bottom: 3PX SOLID #ffbe26; BORDER-RIGHT: 3PX SOLID #c3c0c0; FONT-SIZE: 29PX; text-shadow: 1px 1px 1px #c4c4cb; padding: 15PX; direction:{{$dir}};" > @php echo $course->$Title; @endphp</h1>    
<p>@php echo $course->$course_details; @endphp</p>
</div></div>
</div></div>

<div class="container-fluid">
<div class="container"> 
<div class="row">
    
@if(app()->getLocale()=="en")   

<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="color: #B4975A; background-color:#f8f8f8; margin-top: 25px; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box1}}</button>
    </div>
    <div class="flip-card-back">
<button style="color: #000; background-color:#f8f8f8; margin-top: 25px; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box1}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif

<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="color: #B4975A; background-color:#f8f8f8; margin-top: 25px; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box2}}</button>
    </div>
    <div class="flip-card-back">
<button style="color: #000; background-color:#f8f8f8; margin-top: 25px; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box2}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif
<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="color: #B4975A; background-color:#f8f8f8;margin-top: 25px; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box3}}</button>
    </div>
    <div class="flip-card-back">
<button style="color: #000; background-color:#f8f8f8; margin-top: 25px;margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box3}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif


<div class="col-lg-12 col-md-12 col-xs-12 mt-5 text-center" style="margin-top: 45px;"> 
<button style="color: #B4975A; background-color:#fff; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn"></button>
</div>
  
@else
<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="display: none;color: #646362; background-color: #ffffff; margin: 10px; padding: 13px 10px; border: 1px solid #c0c0c5; border-radius: 30px; width: 100%; font-weight: bold;" class="btn">{{ $course->$Box3}}</button>
    </div>
    <div class="flip-card-back">
<button style="display: none;color: #000; background-color:#f8f8f8; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box3}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif

<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="display: none;color: #646362; background-color: #ffffff; margin: 10px; padding: 13px 10px; border: 1px solid #c0c0c5; border-radius: 30px; width: 100%; font-weight: bold;" class="btn">{{ $course->$Box2}}</button>
    </div>
    <div class="flip-card-back">
<button style="display: none;color: #646362; background-color: #ffffff; margin: 10px; padding: 13px 10px; border: 1px solid #c0c0c5; border-radius: 30px; width: 100%; font-weight: bold;" class="btn">{{ $course->$Box2}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif
<div class="box  col-lg-4 col-md-4 col-xs-12 mt-5 text-center" style="margin-top: 25px;"> 
<div class="flip-card" style="margin-bottom:10px !important!; height:auto !important";>
  <div class="flip-card-inner">
    <div class="flip-card-front">
<button style="display: none;color: #646362; background-color: #ffffff; margin: 10px; padding: 13px 10px; border: 1px solid #c0c0c5; border-radius: 30px; width: 100%; font-weight: bold;" class="btn">{{ $course->$Box1}}</button>
    </div>
    <div class="flip-card-back">
<button style="display: none;color: #000; background-color:#f8f8f8; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn">{{ $course->$Box1}}</button>
</div></div></div></div>
@if($devic)
<br><br>
@endif


<div class="col-lg-12 col-md-12 col-xs-12 mt-5 text-center" style="margin-top: 45px;"> 
<button style="color: #B4975A; background-color:#fff; margin:20px; border-radius:10px; width:100%; font-weight:bold;" class="btn"></button>
</div>

@endif


<div class="col-lg-12 col-md-12 col-xs-12 mb-5 text-center">
<h2 style="border-bottom: 3px dashed #e7e7e7; color: #4e4c49; text-align: right; padding: 20px 10px; margin: 25px; border-right: 4px solid #3b94f9; background: #ffffff;">{{$training_course_content_title->$Title}}</h2>  
</div>

<div class="container text-left"> 
<div class="col-lg-12 col-md-12 col-xs-12 mt-5 text-center" style="margin-bottom: 0px; border-radius: 15px;">
    <section id="values" class="values mb-5">
    
    <div class="row mb-5"><div class="box" style="border-bottom: 0 !important;max-width: 900px; margin: 0 auto;border: 1px solid #dbdbdb; ">
@if(app()->getLocale()=="en")    
    <div class="row" >
     
    <div class="col-lg-6 col-md-6 col-xs-12 {{$align}}">
     <img src="{{$activity_type_img->image}}" style="padding:10px; margin:10px;"/>
     {{ $course->activity_type }}     
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12 {{$align}}">
     <img src="{{$course_language_img->image}}" style="padding:10px; margin:10px;"/>
    {{ $course->course_language }}
    </div></div>
   
<div class="row">
<div class="col-lg-6 col-md-6 col-xs-12 pt-15 {{$align}}">
     <img src="{{$accreditation_img->image}}" style="padding:10px; margin:10px;" />
@foreach($accreditations as $accreditation)
{{ $accreditation }}
<?php break;?>
@endforeach
</div>
<div class="col-lg-6 col-md-6 col-xs-12  {{$align}}">
     <img src="{{$subject_area_img->image}}" style="padding:10px; margin:10px;" />
@foreach($subject_area as $sub)
{{ $sub }}
<?php break;?>
@endforeach
</div></div>

@else
    <div class="row" >
     
    <div class="col-lg-6 col-md-6 col-xs-12 {{$align}}" style="direction:rtl!important;color: #5f6463; height: 80px;overflow: hidden;">
     <img src="{{$activity_type_img->image}}" style="padding:10px; margin:10px;"/>
         {{$course->activity_type}} 

    </div>
    <div class="col-lg-6 col-md-6 col-xs-12 {{$align}}" style="direction:rtl!important;color: #5f6463; height: 80px;overflow: hidden;">
     <img src="{{$course_language_img->image}}" style="padding:10px; margin:10px;" />
    {{ $course->course_language }}
    </div></div>
   
<div class="row">
<div class="col-lg-6 col-md-6 col-xs-12 pt-15 {{$align}}" style="direction:rtl!important;color: #5f6463; height: 80px;overflow: hidden;">
<img src="{{$accreditation_img->image}}" style="padding:10px; margin:10px;" />
@foreach($accreditations as $accreditation)
{{ $accreditation }}
<?php break;?>
@endforeach
</div>
<div class="col-lg-6 col-md-6 col-xs-12  {{$align}}" style="direction:rtl!important;color: #5f6463; height: 80px;overflow: hidden;">
<img src="{{$subject_area_img->image}}" style="padding:10px; margin:10px;" />
@foreach($subject_area as $sub)
{{ $sub }}
<?php break;?>
@endforeach
</div></div>
@endif
</div></div></section></div>    
 
<div class="col-lg-12 col-md-12 col-xs-12 mt-5 text-center" style="margin-bottom: 10px; border-radius: 15px;">
    <section id="values" class="values mb-5">
    
    <div class="row mb-5"><div class="box" style="border-top: none !important;max-width: 900px; margin: 0 auto; border: 1px solid #dbdbdb;" >
@if(app()->getLocale()=="en")    
    
    <div class="row" >
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}">
     <img src="{{$number_modules_img->image}}" style="padding:10px; margin:10px;"/>
     {{ $course->number_modules }}
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}">
     <img src="{{$activity_img->image}}" style="padding:10px; margin:10px;"/>
    {{ $course->activity }}
    </div></div>
    
    <div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12  pt-15 {{$align}}">
        
     <img src="{{$days_img->image}}" style="padding:10px; margin:10px;"/>
{{ $course->days }}
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}">
    
     <img src="{{$time_commitment_img->image}}" style="padding:10px; margin:10px;"/>
{{ $course->time_commitment }}
                                        
    </div>
    </div>
@else
    <div class="row" >
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}" style="direction: rtl;color: #5f6463; height: 80px;overflow: hidden;">
     <img src="{{$number_modules_img->image}}" style="padding:10px; margin:10px;"/>
     {{ $course->number_modules }}
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}">
    {{ $course->activity }}
     <img src="{{$activity_img->image}}" style="padding:10px; margin:10px;"/>
    </div></div>
    
    <div class="row">
    <div class="col-lg-6 col-md-6 col-xs-12  pt-15 {{$align}}" style="direction: rtl;color: #5f6463; height: 80px;overflow: hidden;">
     <img src="{{$days_img->image}}" style="padding:10px; margin:10px;"/>
{{ $course->days }}
    </div>
    <div class="col-lg-6 col-md-6 col-xs-12  {{$align}}" style="direction: rtl;color: #5f6463; height: 80px;overflow: hidden;">
     <img src="{{$time_commitment_img->image}}" style="padding:10px; margin:10px;"/>
    
<span>{{ $course->time_commitment }}</span>
                                        
    </div>
    </div>
@endif   
</div></div></section></div>    


</div></div></div></div>  


<div class="container">
<div class="col-lg-12 col-md-12 col-xs-12 mb-5 text-center">
<h2 style="border-bottom: 3px dashed #e7e7e7; color: #4e4c49; text-align: right; padding: 20px 10px; margin: 25px; border-right: 4px solid #3b94f9; background: #ffffff;">ملــخـص النــشاط</h2>
</div>
<div class="row">
<div class="container" style="border:0px solid #f1f1f1; border-radius:15px;">
<div class="col-lg-12 col-md-12">
    
@if(app()->getLocale() == "en")      
  <ul class="nav nav-tabs" style="font-size:17px;">
    <li class="active"><a href="#tab1" data-toggle="tab" style="color:#B4975A;">{{$tab1->$Title}}</a></li>  
    <li class=""><a href="#tab3" data-toggle="tab" style="color:#B4975A;">{{$tab3->$Title}}</a></li>  
    <li class=""><a href="#tab4" data-toggle="tab" style="color:#B4975A;">{{$tab4->$Title}}</a></li>  
    <li class=""><a href="#tab5" data-toggle="tab" style="color:#B4975A;">{{$tab5->$Title}}</a></li>  
    <li class=""><a href="#tab6" data-toggle="tab" style="color:#B4975A;">{{$tab6->$Title}}</a></li>  
    <li class=""><a href="#tab7" data-toggle="tab" style="color:#B4975A;">{{$tab7->$Title}}</a></li>  
  </ul>
@else
@if(!$devic)
  <ul class="nav nav-tabs" style="font-size:15px;">

@else
  <ul class="nav nav-tabs" style="font-size:17px;">

@endif
    <li class=""><a href="#tab7" data-toggle="tab" style="color:#393432">{{$tab7->$Title}}</a></li>  
    <li class=""><a href="#tab6" data-toggle="tab" style="color:#393432">{{$tab6->$Title}}</a></li>  
    <li class=""><a href="#tab5" data-toggle="tab" style="color:#393432">{{$tab5->$Title}}</a></li>  
    <li class=""><a href="#tab4" data-toggle="tab" style="color:#393432">{{$tab4->$Title}}</a></li>  
    <li class=""><a href="#tab3" data-toggle="tab" style="color:#393432">{{$tab3->$Title}}</a></li>  
    <li class="active"><a href="#tab1" data-toggle="tab" style="color:#B4975A;">{{$tab1->$Title}}</a></li>  
  </ul>

@endif
</div><div class="col-lg-12 col-md-12" style=" line-height: normal;max-width: 1060px; margin: 9px 5%; float: right; padding: 3%; background: #f9f9f9; border: 1px solid #f3eded; ">
  <div class="tab-content">
      
    <div class="tab-pane" id="tab3">
      <div class="panel panel-default">
        <div id="collapseOne3" class="panel-collapse collapse in">
          <div class="panel-body">
        <p><span style="font-weight:bold">  @php echo app()->getLocale() == "en"?$course->details_en:$course->details_ar; @endphp </span></p>

          </div></div></div></div>    

 

     <div class="tab-pane" id="tab7">
      <div class="panel panel-default">
        <div id="collapseOne7" class="panel-collapse collapse in">
          <div class="panel-body">
                            <p class="">@php echo app()->getLocale() == "en"?$course->your_class:$course->your_class_ar; @endphp</p>

          </div></div></div></div>  

          
     <div class="tab-pane" id="tab6">
      <div class="panel panel-default">
        <div id="collapseOne6" class="panel-collapse collapse in">
          <div class="panel-body">
                             <p> @php echo app()->getLocale() == "en"?$course->skills:$course->skills_ar; @endphp</p>  

          </div></div></div></div>   
          
          
   <div class="tab-pane" id="tab4">
      <div class="panel panel-default">
        <div id="collapseOne4" class="panel-collapse collapse in">
          <div class="panel-body">
              
                        <p> @php echo app()->getLocale() == "en"?$course->prerequisites:$course->prerequisites_ar; @endphp</p>              

          </div></div></div></div>   
          
   <div class="tab-pane" id="tab5">
      <div class="panel panel-default">
          
        <div id="collapseOne5" class="panel-collapse collapse in">
          <div class="panel-body">
              <br>
              <p> @php echo app()->getLocale() == "en"?$course->what_you_will_learn:$course->what_you_will_learn_ar; @endphp </p>
          </div></div></div></div>      

      
    <div class="tab-pane active" id="tab1">
      <div class="panel panel-default">
        <div id="collapseOne1" class="panel-collapse collapse in">
          <div class="panel-body">

 <p>@php echo app()->getLocale() == "en"?$course2->course_details:$course2->course_details_ar; @endphp</p></div>                                             
              
          </div>
        </div>
      </div>
    </div>
    

    
    
</div></div>


</div></div></div>

<div class="row">
<div class="col-lg-12 col-md-12 text-center" style="margin-top: 50px;">
    
                              
                               <a href="{{ url('apply-course') }}/{{$course->id}}">
                                <button class="button7 btn-theme" style="vertical-align:middle;color: white; box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.2); background: #3b94f9;">
                                <span>{{$training_course_apply_button->$Title}} <i class="fas fa-external-link-alt"></i></span>
                                </button></a>
                                    
                               <a href="{{ url('storage/uploads/course-brochure') }}/{{ $course->brochure }}" target="_blank">
                                <button class="button7 btn-theme" style="vertical-align: middle; border: 1px solid; color: #000000; background: #ffffff;">
                                <span>{{$training_course_prochure_button->$Title}} <i class="fas fa-download"></i></span>
                                </button></a>
                        </div>    
</div><br><br></div>   

@if(app()->getLocale() == "en")
        @if(!empty($reviews[0]))
            <section class="reviews" style="background-color: #f9f9f9;">
                <div class="container-fluid">
                <header class="popular-posts-head">
                            <h2 class="popular-head-heading hr_head">{{$reviews_course_title->$Title}}</h2>
                </header>
                    <br>
                    @if(!empty($videos[0]))
                    <section class="news-block container">
                        <div class="row slider videos-slider">
                            @foreach($videos as $video)
                                <div class="col-xs-12 col-sm-12 col-md-12" id="youtube_video">
                                    <!-- news post -->
                                    <article class="news-post">
                                        <div class="aligncenter">
                                            <iframe class="youtube-video" width="560" height="315" src="{{ $video->video }}"
                                                    title="YouTube video player" frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen>
                                            </iframe>
                                        </div>
                                    </article>
                                </div>
                            @endforeach
                        </div>
                    </section>
                    @endif
                    <div class="row">
                        <div class="reviews-section" style="margin: 20px 20px">
                            <div class="slider testimonail-slider">
                                @foreach($reviews as $review)
                                    <div class="review-slider-content">
                                        <!-- testimonial quote -->
                                        <blockquote class="testimonial-quote font-roboto" style=" background: #ffffff; box-shadow: 1px 1px 6px 4px #e3e3e3; direction: rtl; border: 1px solid #d3d3d3; padding: 30px 10px; ">
                                            <p> @php echo $review->review;  @endphp </p>
                                            @if($review->stars == 1)
                                                <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i></p>
                                            @elseif($review->stars == 2)
                                                <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                            @elseif($review->stars == 3)
                                                <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                            @elseif($review->stars == 4)
                                                <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                            @elseif($review->stars == 5)
                                                <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                            @endif
                                        </blockquote>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        @endif
        
@else
@if(!empty($reviews[0]))
                <section class="reviews" style="background-color: #f9f9f9;">
                    <div class="container-custom">
                <header class="popular-posts-head {{$dir}}">
                            <h2 class="popular-head-heading hr_head">{{$reviews_course_title->$Title}}</h2>
                </header>                        <br>
                        @if(!empty($videos[0]))
                            <section class="news-block container">
                                <div class="row slider videos-slider">
                                    @foreach($videos as $video)
                                        <div class="col-xs-12 col-sm-12 col-md-12" id="youtube_video">
                                            <!-- news post -->
                                            <article class="news-post">
                                                <div class="aligncenter">
                                                    <iframe class="youtube-video" width="560" height="315" src="{{ $video->video }}"
                                                            title="YouTube video player" frameborder="0"
                                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                            allowfullscreen>
                                                    </iframe>
                                                </div>
                                            </article>
                                        </div>
                                    @endforeach
                                </div>
                            </section>
                        @endif
                        <div class="row">
                            <div class="reviews-section" style="margin: 20px 20px">
                                <div class="slider testimonail-slider">
                                    @foreach($reviews as $review)
                                        <div class="review-slider-content">
                                            <!-- testimonial quote -->
                                            <blockquote class="testimonial-quote font-roboto" style=" background: #ffffff; box-shadow: 1px 1px 6px 4px #e3e3e3; direction: rtl; border: 1px solid #d3d3d3; padding: 30px 10px; ">
                                                <p> @php echo $review->review;  @endphp </p>
                                                @if($review->stars == 1)
                                                    <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i></p>
                                                @elseif($review->stars == 2)
                                                    <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                                @elseif($review->stars == 3)
                                                    <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                                @elseif($review->stars == 4)
                                                    <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                                @elseif($review->stars == 5)
                                                    <p><span style="font-weight: bold"></span> <i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i><i class="fas fa-star" style="color: #ffb100"></i></p>
                                                @endif
                                            </blockquote>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            @endif
@endif
        
        
            @if(!empty($related_courses))
                <section class="popular-posts-block container-fluid {{$dir}}">
                    <header class="popular-posts-head" >
                        <h2 class="popular-head-heading hr_head" style="font-family: 'URWGeometric';text-shadow: 1px 1px 1px #ffffff;">{{$training_similar_course_title->$Title}}</h2>
                    </header>
                    <div class="row">
                        <!-- popular posts slider -->
                        <div id="popular_post1" class="slider related-course-slider popular-courses {{$dir}}">
                            @foreach($related_courses as $course)
                                <div onclick="courseFunction({{ $course->id }})">
                                    <div class="col-xs-12 {{$dir}}">
                                        <!-- popular post -->
                                        <a href="{{ url('course') }}/{{$course->id}}">
                                            <article class="popular-post popular-course">
                                                <div class="aligncenter">
                                                    <img src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}"
                                                         alt="no-photo">
                                                </div>
                                                <div>
                                                </div>

                                            <p style="margin-top: 20px; margin-bottom: 20px;" class="post-heading"><a
                                                    href="{{ url('course') }}/{{$course->id}}">
                                                    @php echo $course->$Title;@endphp
                                                </a>
                                            </p>
                                                <footer class="post-foot gutter-reset hidden">
                                                    <ul class="list-unstyled post-statuses-list" style="padding-right: 0">
                                                        <li>
                                                            <a href="javascript:void(0)">
                                                <span class="fas icn fa-clock no-shrink"><span
                                                        class="sr-only"></span></span>
                                                                <strong class="text fw-normal"> @php echo app()->getLocale() == "en"?$course->duration:$course->duration_ar; @endphp</strong>
                                                            </a>
                                                        </li><br>
                                                        <li>
                                                            <a href="javascript:void(0)">
                                                                <i class="fas fa-chart-line"></i>
                                                                <strong class="text fw-normal"> @php echo app()->getLocale() == "en"?$course->activity_type:$course->activity_type_ar; @endphp</strong>
                                                            </a>
                                                        </li><br>
                                                        <li>
                                                            <a href="javascript:void(0)">
                                                                <i class="far fa-chart-bar"></i>
                                                                <strong class="text fw-normal">
                                                                    {{$course->level}}

                                                                </strong>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </footer>
                                            </article>
                                        </a>

                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </section>
        @endif
        <!-- subscription aside block -->
        </section>


    <input id="date_dd" value="{{ $date }}"  style="display: none;">
    <input id="date_dd2" value="{{ $date2 }}"  style="display: none;">
@stop
@section('scripts')

@if(app()->getLocale() == "en")
    <script>
        // Set the date we're counting down to
        var reg_date = $('#date_dd').val();

        $(window).load(function (){

            console.log(reg_date);
        })
        var countDownDate = new Date(reg_date).getTime();
        // Update the count down every 1 second
        var countdownfunction = setInterval(function () {
            // Get todays date and time
            var now = new Date().getTime();
            // Find the distance between now an the count down date
            var diff = countDownDate - now;
            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(diff / (1000 * 60 * 60 * 24));
            var hours = Math.floor(
                (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
            ) - 3;
            var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((diff % (1000 * 60)) / 1000);
            // Output the result in an element with id="countdown"
            document.getElementById("countdowndays").innerHTML = days;
            document.getElementById("countdownhours").innerHTML = hours;
            document.getElementById("countdownminutes").innerHTML = minutes ;
            document.getElementById("countdownseconds").innerHTML = seconds;
            // If the count down is over, write some text
            if (diff < 0) {
                clearInterval(countdownfunction);
                document.getElementById("countdowndays").innerHTML = 0;
                document.getElementById("countdownhours").innerHTML = 0;
                document.getElementById("countdownminutes").innerHTML = 0;
                document.getElementById("countdownseconds").innerHTML = 0;
            }
        }, 1000);
    </script>
@else
    <script>
        if ($(window).width() > 992){
            var reg_date = $('#date_dd').val();
            // Set the date we're counting down to
            var countDownDate = new Date(reg_date).getTime();
            // Update the count down every 1 second
            var countdownfunction = setInterval(function () {
                // Get todays date and time
                var now = new Date().getTime();
                // Find the distance between now an the count down date
                var diff = countDownDate - now;
                // Time calculations for days, hours, minutes and seconds
                var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                var hours = Math.floor(
                    (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
                ) - 3;
                var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((diff % (1000 * 60)) / 1000);
                // Output the result in an element with id="countdown"
                document.getElementById("countdowndaysAr").innerHTML = days;
                document.getElementById("countdownhoursAr").innerHTML = hours;
                document.getElementById("countdownminutesAr").innerHTML = minutes ;
                document.getElementById("countdownsecondsAr").innerHTML = seconds;
                // If the count down is over, write some text
                if (diff < 0) {
                    clearInterval(countdownfunction);
                    document.getElementById("countdowndaysAr").innerHTML = 0;
                    document.getElementById("countdownhoursAr").innerHTML = 0;
                    document.getElementById("countdownminutesAr").innerHTML = 0;
                    document.getElementById("countdownsecondsAr").innerHTML = 0;
                }
            }, 1000);
        } else{
            var reg_date = $('#date_dd2').val();
            // Set the date we're counting down to
            var countDownDate = new Date(reg_date).getTime();
            // Update the count down every 1 second
            var countdownfunction = setInterval(function () {
                // Get todays date and time
                var now = new Date().getTime();
                // Find the distance between now an the count down date
                var diff = countDownDate - now;
                // Time calculations for days, hours, minutes and seconds
                var days = Math.floor(diff / (1000 * 60 * 60 * 24));
                var hours = Math.floor(
                    (diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
                );
                var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((diff % (1000 * 60)) / 1000);
                // Output the result in an element with id="countdown"
                document.getElementById("countdowndaysArRes").innerHTML = days;
                document.getElementById("countdownhoursArRes").innerHTML = hours;
                document.getElementById("countdownminutesArRes").innerHTML = minutes ;
                document.getElementById("countdownsecondsArRes").innerHTML = seconds;
                // If the count down is over, write some text
                if (diff < 0) {
                    clearInterval(countdownfunction);
                    document.getElementById("countdowndaysArRes").innerHTML = 0;
                    document.getElementById("countdownhoursArRes").innerHTML = 0;
                    document.getElementById("countdownminutesArRes").innerHTML = 0;
                    document.getElementById("countdownsecondsArRes").innerHTML = 0;
                }
            }, 1000);
        }

    </script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<script>
    var viewportContent = '';
    if (window.devicePixelRatio = 1) {
        viewportContent = 'width=device-width, initial-scale=0.8, maximum-scale=0.8, user-scalable=0, target-densityDpi=device-dpi';
    } else if (window.devicePixelRatio == 2) {
        viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0';
    } else if (window.devicePixelRatio == .78) {
        viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, target-densityDpi=device-dpi';
    } else if (window.devicePixelRatio == 1.5) {
        viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, target-densityDpi=device-dpi';
    }
     $('head').append('<meta name="viewport" content="' + viewportContent + '">');
</script>

@endif

@stop

