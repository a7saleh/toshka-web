<!DOCTYPE html>
<html lang="ar">
<head>
	<!-- set the encoding of your site -->
	<meta charset="utf-8">
	<!-- set the viewport width and initial-scale on mobile devices -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- set the HandheldFriendly -->
	<meta name="HandheldFriendly" content="True">
	<!-- set the description -->
	<meta name="description" content="اكتشف مدونات تعليمية وتدريبية شاملة من مجموعة الجهود، تتناول موضوعات متنوّعة تغطي أحدث التقنيات، المهارات، والتطوير الشخصي والمهني. تابع مدونتنا للاستفادة من محتوى غني ومعرفة مفيدة تساهم في تحسين مهاراتك وتوسيع آفاقك.">
    <meta property="og:description" content="اكتشف مدونات تعليمية وتدريبية شاملة من مجموعة الجهود، تغطي أحدث التقنيات، المهارات، والتطوير الشخصي والمهني. استفد من محتوى غني ومعرفة مفيدة لتطوير مهاراتك وتوسيع آفاقك.">
   <meta name="twitter:description" content="اكتشف مدونات تعليمية وتدريبية شاملة من مجموعة الجهود، تغطي أحدث التقنيات، المهارات، والتطوير الشخصي والمهني. استفد من محتوى غني ومعرفة مفيدة لتطوير مهاراتك وتوسيع آفاقك.">

	<!-- set the Keyword -->
	<meta name="keywords" content="مجموعة الجهود, مدونات تعليمية, تدريب, تطوير المهارات, تقنيات حديثة, تعلم عن بعد, محتوى تعليمي, تطوير شخصي, تطوير مهني, مهارات العمل, تعليم إلكتروني, مدونات تدريبية">
	<meta name="author" content="aljhood">
    <!-- base url -->
    <meta name="base_url" content="{{url('/')}}">
    <link rel="canonical" href="{{ request()->url() }}">
    <!-- csrf token -->
    <meta name="csrf_token" content="{{ csrf_token() }}">
    <!-- set the page title -->
    @if(app()->getLocale() == "en")
        <title>AL JHOOD - {{ trans('messages.blog') }}</title>
    @else
        <title class="rtl">الجهود - {{ trans('messages.blog') }}</title>
    @endif

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
	<!-- include google roboto font cdn link -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
	<!-- include the site bootstrap stylesheet -->
	<link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
	<!-- include the plugins stylesheet -->
	<link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
	<!-- include the colors stylesheet -->
	<link rel="stylesheet" href="{{ asset("frontend/css/colors.css") }}">
	<!-- include the custom stylesheet -->
	<link rel="stylesheet" href="{{ asset("frontend/css/custom.css") }}">
	<!-- include the site responsive stylesheet -->
	<link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
	<!-- include pannellum 360 image viewer -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/>
    <!-- include animate css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=67286397f1a61800125d516c&product=sop' async='async'></script>

@if(app()->getLocale() == "ar")
        <style>
        
@media only screen and (max-width: 600px) {
.rmbuttonrm{
font-size:10px!important; 
min-width:90px!important;
margin-top:50px!important; 

}
.blog-page{
 margin-top:0px!important;   
}
.viewonmobile{
display:block!important;
} 
.widthmobile{
width:90px!important; 
font-size:10px!important; 
}
.titlemobile{
background-color:#fff;    
}    
}            
        
            @font-face {
                font-family: 'URWGeometric';
                src: url('{{ url('/') }}/frontend/css/fonts/URWG.ttf') format('truetype');
            }
            a, p, span, li, h1, h2, h3, h4, h5, h6, input, label, textarea, datalist , dd , div , font , blockquote , strong{
                font-family: URWGeometric;
            }
            blockquote{
                font-family: URWGeometric !important;
            }
            li a{
                font-family: URWGeometric !important;
            }
            strong{
                font-family: URWGeometric !important;
            }

            h3  a{
                font-family: URWGeometric !important;

            }
            @media (max-width: 767px) {
                .pagination{
                    padding-right: 0;
                }
                .page-header-blog .navbar-default .navbar-nav > li > a{
                    text-align: right;
                }
                .main-navigation{
                    padding: 0;
                }
                .page-header-blog .navbar-default .navbar-nav > .dropdown:after{
                    left: unset !important;
                    right: 90%;
                }
                .ul-nopad{
                    padding: 0;
                }
                .ul-nopad1{
                    padding: 0;
                    margin: 13px 0 0 0;
                }
            }
            .extra2-slider .slick-arrow.slick-next {
                left: 11% !important;
            }
            .extra2-slider .slick-arrow.slick-prev {
                left: 0 !important;
            }
        </style>
    @else
        <style>
        
@media only screen and (max-width: 600px) {
.rmbuttonrm{
font-size:10px!important; 
min-width:90px!important; 
margin-top:50px!important; 
}
.blog-page{
 margin-top:0px!important;   
}
.viewonmobile{
display:block!important;
} 
.widthmobile{
width:90px!important; 
font-size:10px!important; 
}
.titlemobile{
background-color:#fff;    
}    
}            
        
        
        
            @media (max-width: 767px) {
                .page-header-blog .navbar-default .navbar-nav > li > a{
                    text-align: left !important;
                }
                .main-navigation{
                    padding: 0;
                }
                .page-header-blog .navbar-default .navbar-nav > .dropdown:after{
                    left: unset !important;
                }
                .navbar-search-form{
                    margin: 0 15px 0 0;
                }
                .ul-nopad{
                    padding: 0;
                }
                .ul-nopad1{
                    padding: 0;
                    margin: 13px 0 0 0;
                }
            }
        </style>
    @endif
    
<?php
$TitleText="title_".app()->getLocale();
$DescriptionText="description_".app()->getLocale();
$Title="title_".app()->getLocale();
$blog_read_more_button=DB::table('page_contents')->where('ref_page','blog_read_more_button')->first();
$blog_latest_title=DB::table('page_contents')->where('ref_page','blog_latest_title')->first();
$blog_popular_title=DB::table('page_contents')->where('ref_page','blog_popular_title')->first();
$blog_explore_title=DB::table('page_contents')->where('ref_page','blog_explore_title')->first();
if(app()->getLocale()=="en"){
$dir="ltr";   
}else{
$dir="rtl";   
}
?>
@if(app()->getLocale() == "ar")
<?php 

$dir="rtl";

?>
@else
<?php 

$dir="ltr";

?>
@endif
</head>
<body id="bolg_content">

	@php
        use Carbon\Carbon;
        $time = Carbon::now();
        $end_of_url = explode('.', \Request::route()->getName());
        $end_of_url = end($end_of_url);
	@endphp


	<!-- main container of all the page elements -->
	    <div id="wrapper">

		<div class="upper-header-blog">
		    <a href="https://www.aljhood.com/public/home">
			<img src="{{ asset('../frontend/images/logos/logo-dark.png') }}" width="300">
			</a>
		</div>

		<div class="container">
			<div class="row ">
                <div class="col-sm-3 col-xs-3 col-md-6 settings-blog-1 ltr">
                    <ul class="ul-nopad">
                        <li> <a href="{{ url('/') }}"> <img src="{{ asset('../frontend/images/backtohome.png') }}" width="50"> </a> </li>
                                <li>
                                <div class="settings-blog">
                                    <i id="darkMood" class="fa fa-moon"> </i> 
                                
                            </div></li>
                              @if(app()->getLocale() == "en")
                             <li style="display:none;"> <a href="?lang=ar" class="lang-text" style="color: black"><i class="fa fa-globe"></i>&nbsp;<b>AR</b></a></li>
                             @else
                             <li style="display:none;"><a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}" class="lang-text" style="color: black"><i class="fa fa-globe"></i>&nbsp;<b>EN</b></a></li>
                             @endif
                    </ul>
                </div>
				<div class="col-sm-9 col-xs-9 col-md-6 settings-blog-icons ltr">
					<ul class="ul-nopad1">
                        <li> <a href="https://www.facebook.com/AljhoodGroup" target="_blank"><i class="fab fa-facebook-square"></i></a> </li>
                        <li> <a href="https://www.instagram.com/aljhoodgroup/" target="_blank"><i class="fab fa-instagram"></i></a> </li>
                        <li> <a href="https://www.linkedin.com/company/aljhoodgroup/" target="_blank"><i class="fab fa-linkedin-in"></i></a> </li>
                        <li> <a href="https://twitter.com/AljhoodGroup" target="_blank"><i class="fab fa-twitter"></i></a> </li>
                        <li> <a href="http://api.whatsapp.com/send?phone=+962776003400" target="_blank"><i class="fab fa-whatsapp"></i></a> </li>
                        <li> <a href="https://www.youtube.com/channel/UCa3k29T1ZwytTkC3bC0mBGw" target="_blank"><i class="fab fa-youtube"></i></a> </li>
					</ul>
				</div>
			</div>
		</div>
		<!-- header of the page -->

        <section class="intro-block blog-page  text-center">
            <div class="slider fade-slider">
                @foreach($sliders as $slider)
                <div>
                    <!-- intro block slide -->
                    <article class="intro-block-slide overlay bg-cover" style="background-image: url({{ url('storage/uploads/sliders') }}/{{$slider->image}});">
                        <div class="align-wrap container flex-box none-slider {{$dir}}">
                            <div class="align blog-page-text">
                                    <div class="anim text-center">
                                        <h1><p style="color:#be9f56!important;">@php echo $slider->$TitleText @endphp</p></h1>
                                    </div>
                                    <div class="anim delay1">
                                        <p> @php echo $slider->$DescriptionText @endphp</p>
                                    </div>
                                @if(!empty($slider->link))
                                    <div class="anim delay2">
                                        <div class="btns-wrap">
                                            <a href="{{ $slider->link }}"
                                               class="btn btn-warning btn-theme text-uppercase" target="_blank">{{$blog_read_more_button->$Title}}</a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                        @if(!empty($slider->link))
                            <div class="anim delay2">
                                <div class="btns-wrap">
                                    <div class="widthmobile">
                                    <div class="titlemobile">
                                    <p class="viewonmobile" style="color:#be9f56!important; display:none;">@php echo $slider->$TitleText @endphp</p>
                                    </div>
                                    <a href="{{ $slider->link }}"
                                       class="btn btn-warning btn-theme text-uppercase rmbuttonrm" target="_blank" style="margin-top: 115px ; padding-top: 5px; padding-bottom: 5px;">{{$blog_read_more_button->$Title}}</a>
                                </div></div>
                            </div>
                        @endif
                    </article>
                </div>
                @endforeach
            </div>
        </section>
		<!-- contain main informative part of the site -->




        <main class="blog-page {{$dir}}">
            <div class="container blog-section">
                <header class="popular-posts-head">
                    <h2 class="popular-head-heading hr_head">{{$blog_latest_title->$Title}}</h2>
                </header>
                <div class="row {{$dir}}">
                    @foreach($latest_articles as $article)
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out" onclick="blogFunction({{ $article->id }})" style="cursor: pointer">
                            <a href="{{ url('blog') }}/{{ $article->id }}#innerBlogTitle">
                                <div class="contentRightImage" style="margin:20px auto;">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $article->file }}" alt="image description">
                                    <div class="imageCaption text-center text-white">
                                        <a style="font-size:18px; font-weight:bold;" href="{{ url('blog') }}/{{ $article->id }}#innerBlogTitle">{{ $article->$TitleText }}</a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
 
            <div class="container blog-section">
                <header class="popular-posts-head">
                            <h2 class="popular-head-heading hr_head">{{$blog_popular_title->$Title}}</h2>
                </header>
                <div class="row {{$dir}}">
                            @foreach($blogs as $blog)
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out" onclick="blogFunction({{ $article->id }})" style="cursor: pointer">
                            <a href="{{ url('blog') }}/{{ $blog->id }}#innerBlogTitle">
                                <div class="contentRightImage" style="margin:20px auto;">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $blog->file }}" alt="image description">
                                    <div class="imageCaption text-center text-white">
                                        <a style="font-size:18px; font-weight:bold;" href="{{ url('blog') }}/{{ $blog->id }}#innerBlogTitle">{{ $blog->$TitleText }}</a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
 
            <div class="container blog-section">
                <header class="popular-posts-head">
                            <h2 class="popular-head-heading hr_head">{{$blog_explore_title->$Title}}</h2>
                </header>
                <div class="row {{$dir}}">
                            @foreach($explore_more as $explore)
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out" onclick="blogFunction({{ $article->id }})" style="cursor: pointer">
                            <a href="{{ url('blog') }}/{{ $explore->id }}#innerBlogTitle">
                                <div class="contentRightImage" style="margin:20px auto; height:auto% !important;">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $explore->file }}" alt="image description" style="height:100% !important;">
                                    <div class="imageCaption text-center text-white">
                                        <a style="font-size:18px; font-weight:bold;" href="{{ url('blog') }}/{{ $explore->id }}#innerBlogTitle">{{ $explore->$TitleText }}</a>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>

                </div>
                @if($links == 1)
                    <div style="display: flex; flex-direction: row; justify-content: center;">
                        <div style="text-align: center;">{{ $blogs->links() }}</div>
                    </div>
                @endif
                @if($links == 1)
                    <div class="pt-15" style="display: flex; flex-direction: row; justify-content: center;">
                        <div style="text-align: center;"> {{ $blogs->lastItem() }}
                            of {{ $blogs->total() }} Blogs.
                        </div>
                    </div>
                @endif
            </div>
        </main>



		<!-- footer area container -->
		<div class="footer-area bg-dark text-gray blog-footer">
			<div class="container">
				<div class="col-md-12" style="text-align: center;">
					<a href="https://www.aljhood.com/public/home">
    <img src="{{ asset('../frontend/images/logos/logo-dark.png') }}" width="300">
</a>
				</div>
				<div class="col-md-12">
					<ul class="socail-networks list-unstyled">
						<li><a href="https://www.facebook.com/AljhoodGroup" target="_blank"><span class="fab fa-facebook"></span></a>
						</li>
						<li><a href="https://twitter.com/AljhoodGroup" target="_blank"><span class="fab fa-twitter"></span></a></li>
						<li><a href="https://www.instagram.com/aljhoodgroup/" target="_blank"><span class="fab fa-instagram"></span></a></li>
						<li><a href="https://www.linkedin.com/company/aljhoodgroup/" target="_blank"><span class="fab fa-linkedin">
						</span></a></li>
						<li><a href="http://api.whatsapp.com/send?phone=+962776003400" target="_blank"><span class="fab fa-whatsapp">
						</span></a></li>
						<li><a href="https://www.youtube.com/channel/UCa3k29T1ZwytTkC3bC0mBGw" target="_blank"><span class="fab fa-youtube">
						</span></a></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- back top of the page -->
		<span id="back-top" class="text-center fa fa-caret-up"></span>
        <span id="whats-app" class="text-center fab fa-whatsapp"></span>
		<!-- loader of the page -->

    </div>



<!-- include min jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
<!-- include Plugins -->
<script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
<!-- include jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
<!-- include init js -->
<script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>
<!-- include custom js -->
<script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>

    var locale = '{{request()->getRequestUri()}}';


    @if(app()->getLocale() == "en")
    $(document).ready( function (){

        if (localStorage.getItem('firstVisit') == null) {

            localStorage.setItem('firstVisit',1);
            window.location.href = locale + '?lang=ar';
        }
    })
    @endif

</script>

<script>

	$('.read_more_btn').click(function(){

		$(this).parent().parent().find('.remaining_content').slideDown(1000);
		$(this).parent().parent().find('.read_less_btn').show();
		$(this).parent().parent().find('.part_contant').hide();
		$(this).hide();
	});

	$('.read_less_btn').click(function(){

		$(this).parent().parent().find('.remaining_content').slideUp(1000,function(){
			$(this).parent().parent().find('.read_more_btn').show();
			$(this).parent().parent().find('.part_contant').show();
		});
		$(this).hide();
	});
</script>
    <script>
        var url = $('meta[name=base_url]').attr("content");
        function blogFunction(id) {
            window.location.href = url + "/blog/" + id + "#innerBlogTitle";
        }
    </script>
    <script>
        var current_url = window.location.pathname;
        window.onload = function(){
            if (current_url != '/aljhood/courses'){
                localStorage.removeItem('course_select_1');
                localStorage.removeItem('course_select_2');
                localStorage.removeItem('course_select_3');
            }
        }
    </script>
    <script>
        var x = localStorage.getItem('dark');
        $(window).load(function (){
            if (x == 1){
                $('.extra2-slider .slick-arrow').css('color' , '#fff');
            }
        })

    </script>
    <script>
        AOS.init();
    </script>

</body>
</html>
