<!------------------------- about us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.courses_compare'))

@section('content')
    @php
        $lang = 1;
    @endphp
<?php

$Title="title_".app()->getLocale();
$compare_learn=DB::table('page_contents')->where('ref_page','compare_learn')->first();
$compare_skills=DB::table('page_contents')->where('ref_page','compare_skills')->first();
$compare_date=DB::table('page_contents')->where('ref_page','compare_date')->first();
$compare_activity=DB::table('page_contents')->where('ref_page','compare_activity')->first();
$compare_acc=DB::table('page_contents')->where('ref_page','compare_acc')->first();
$choose_commitment=DB::table('page_contents')->where('ref_page','choose_commitment')->first();
$compare_apply=DB::table('page_contents')->where('ref_page','compare_apply')->first();
$compare_view_details=DB::table('page_contents')->where('ref_page','compare_view_details')->first();
$compare_activity_type=DB::table('page_contents')->where('ref_page','compare_activity_type')->first();
$compare_title=DB::table('page_contents')->where('ref_page','compare_title')->first();

?>
    @if(app()->getLocale() == "en")

        <section class="container price-block" style="margin-top: 20px">
            <div class="go-back" style="margin: 15px 0 ;">
                <a href="{{ url('aljhood/courses') }}"><i class="fas fa-arrow-circle-left"></i> Go Back</a>
            </div>
            @if(empty($course1[0]->id) && empty($course2[0]->id) && empty($course3[0]->id))
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center alert alert-danger alert-dismissible show" role="alert">
                            Please select at least one course
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                </div>
            @endif
            <header class="popular-posts-head">
                <h2 class="popular-head-heading hr_head">{{$compare_title->$Title}}</h2>
            </header>
            <div class="row" id="rowHeight">
                @if(!empty($course1[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse1">
                        <div class="compare-head"  id="myHeader1">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; right: 8%;">
                                @csrf
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2> @php echo $course1[0]->title_en; @endphp</h2>
                            <br><p> @php echo $course1[0]->subject_area; @endphp</p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight1">
                            <div class="what-will-you-learn">
                                <h3>{{$compare_learn->$Title}}</h3>
                                <div class="read-more what-will-you-learn1 toggle-overflow">
                                    <p> @php echo $course1[0]->what_you_will_learn; @endphp</p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto;">
                                <h3>{{$compare_skills->$Title}}</h3>
                                <div class="read-more skills1 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course1[0]->skills; @endphp </p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date1 toggle-overflow2">
                                    <p> @php echo $course1[0]->start_date; @endphp </p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}}</h3>
                                <div class="read-more time-commitment1 toggle-overflow2">
                                    <p> @php echo $course1[0]->time_commitment; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                <div class="read-more activity1 toggle-overflow2">
                                    <p> @php echo $course1[0]->activity; @endphp</p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}}</h3>
                                <div class="read-more activity-type1 toggle-overflow2">
                                    <p> @php echo $course1[0]->activity_type; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation1 toggle-overflow2">
                                    <p> @php echo $course1[0]->accreditation; @endphp</p>
                                </div>
                            </div>
                            <div class="all-btns">
                                <div class="btns">
                                    <a href="{{ url('course') }}/{{$course1[0]->id}}"
                                       class="btn btn-default btn-tall text-uppercase">{{$compare_view_details->$Title}}</a>
                                </div>
                                <div class="btns">
                                    <a href="{{ url('aljhood/apply-course?course_id=').$course1[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>Compare Course</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course2">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-3">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course3">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                <div class="form-group">
                                    <select class="arrow_down" name="course-select-1">
                                        <option value="0" selected="selected">Choose Course</option>
                                        @foreach($courses as $course)
                                            <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">Add To Compare</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
                @if(!empty($course2[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse2">
                        <div class="compare-head"  id="myHeader2">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; right: 8%;">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2> @php echo $course2[0]->title_en; @endphp</h2>
                            <br><p> @php echo $course2[0]->subject_area; @endphp </p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight2">
                            <div class="what-will-you-learn">
                                <h3>{{$compare_learn->$Title}}</h3>
                                <div class="read-more what-will-you-learn2 toggle-overflow">
                                    <br><p> @php echo $course2[0]->what_you_will_learn; @endphp</p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto;">
                                <h3>{{$compare_skills->$Title}}</h3>
                                <div class="read-more skills2 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course2[0]->skills; @endphp</p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date2 toggle-overflow2">
                                    <p> @php echo $course2[0]->start_date; @endphp</p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}}</h3>
                                <div class="read-more time-commitment2 toggle-overflow2">
                                    <p> @php echo $course2[0]->time_commitment; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                <div class="read-more activity2 toggle-overflow2">
                                    <p> @php echo $course2[0]->activity; @endphp</p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}}</h3>
                                <div class="read-more activity-type2 toggle-overflow2">
                                    <p> @php echo $course2[0]->activity_type; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation2 toggle-overflow2">
                                    <p> @php echo $course2[0]->accreditation; @endphp</p>
                                </div>
                            </div>
                            <div class="all-btns">
                                <div class="btns">
                                    <a href="{{ url('course') }}/{{$course2[0]->id}}"
                                       class="btn btn-default btn-tall text-uppercase">{{$compare_view_details->$Title}}</a>
                                </div>
                                <div class="btns">
                                    <a href="{{ url('aljhood/apply-course?course_id=').$course2[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>Compare Another Course</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course2">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-3">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course3">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course1[0]->id))
                                <div class="form-group">
                                    <select class="arrow_down" name="course-select-2">
                                        <option value="0" selected="selected">Choose Course</option>
                                        @foreach($courses as $course)
                                            <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                        @endforeach
                                    </select>
                                </div>
                                @else
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-1">
                                            <option value="0" selected="selected">Choose Course</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif
                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">Add To Compare</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
                @if(!empty($course3[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse3">
                        <div class="compare-head"  id="myHeader3">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; right: 8%;">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2>@php echo $course3[0]->title_en; @endphp </h2>
                            <br><p> @php echo $course3[0]->subject_area; @endphp</p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight3">
                            <div class="what-will-you-learn">
                                <h3>{{$compare_learn->$Title}}</h3>
                                <div class="read-more what-will-you-learn3 toggle-overflow">
                                    <p> @php echo $course3[0]->what_you_will_learn; @endphp </p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course2[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn) > 315 || strlen($course3[0]->what_you_will_learn) > 315)
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn) > 315 )
                                        <p class="read-more-btn">+ Read More</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto;">
                                <h3>{{$compare_skills->$Title}}</h3>
                                <div class="read-more skills3 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course3[0]->skills; @endphp </p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date3 toggle-overflow2">
                                    <p> @php echo $course3[0]->start_date; @endphp </p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}}</h3>
                                <div class="read-more time-commitment3 toggle-overflow2">
                                    <p> @php echo $course3[0]->time_commitment; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                <div class="read-more activity3 toggle-overflow2">
                                    <p> @php echo $course3[0]->activity; @endphp </p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}}</h3>
                                <div class="read-more activity-type3 toggle-overflow2">
                                    <p> @php echo $course3[0]->activity_type; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation3 toggle-overflow2">
                                    <p> @php echo $course3[0]->accreditation; @endphp</p>
                                </div>
                            </div>
                            <div class="all-btns">
                                <div class="btns">
                                    <a href="{{ url('course') }}/{{$course3[0]->id}}"
                                       class="btn btn-default btn-tall text-uppercase">{{$compare_view_details->$Title}}</a>
                                </div>
                                <div class="btns">
                                    <a href="{{ url('aljhood/apply-course?course_id=').$course3[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>Compare Another Course</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                <div class="form-group" style="display: none">
                                    <select class="arrow_down course-dropdown" name="course-select-1">
                                        <option value="{{ $course1[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                    </select>
                                </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                <div class="form-group" style="display: none">
                                    <select class="arrow_down course-dropdown" name="course-select-2">
                                        <option value="{{ $course2[0]->id }}" selected="selected" name="course1">Choose Course</option>
                                    </select>
                                </div>
                                @endif
                                @if(empty($course1[0]->id) && empty($course2[0]->id))
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-1">
                                            <option value="0" selected="selected" name="course1">Choose Course</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @elseif(!empty($course1[0]->id) && empty($course2[0]->id))
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-2">
                                            <option value="0" selected="selected" name="course1">Choose Course</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @else
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-3">
                                            <option value="0" selected="selected" name="course1">Choose Course</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_en; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif

                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">Add To Compare</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
            </div>

            <div class="go-back" style="margin: 50px 0 0 0;">
                <a href="{{ url('aljhood/courses') }}"><i class="fas fa-arrow-circle-left"></i> Go Back</a>
            </div>
        </section>
    @else
        <section id="arabicCompare" class="container price-block rtl" style="margin-top: 20px">
            <div class="go-back" style="margin: 15px 0 ;">
                <a href="{{ url('aljhood/courses') }}"><i class="fas fa-arrow-circle-left"></i> السابق</a>
            </div>
            @if(empty($course1[0]->id) && empty($course2[0]->id) && empty($course3[0]->id))
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center alert alert-danger alert-dismissible show" role="alert">
                            الرجاء اختيار دورة واحدة على الأقل
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true" style="float: left">&times;</span>
                            </button>
                        </div>
                    </div>
                </div>
            @endif
            <header class="popular-posts-head">
                <h2 class="popular-head-heading hr_head">{{$compare_title->$Title}}</h2>
            </header>
            <div class="row" id="rowHeight">
                @if(!empty($course3[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse3">
                        <div class="compare-head"  id="myHeader3">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; left: 8%;">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2>@php echo $course3[0]->title_ar; @endphp </h2>
                            <br><p style="text-align: center !important;"> @php echo $course3[0]->subject_area_ar; @endphp</p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight3">
                            <div class="what-will-you-learn">
                                <h3> {{$compare_learn->$Title}} </h3>
                                <div class="read-more what-will-you-learn3 toggle-overflow">
                                    <p> @php echo $course3[0]->what_you_will_learn_ar; @endphp </p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto;">
                                <h3>{{$compare_skills->$Title}}</h3>
                                <div class="read-more skills3 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course3[0]->skills_ar; @endphp </p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date3 toggle-overflow2">
                                    <p> @php echo $course3[0]->start_date; @endphp </p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}}</h3>
                                <div class="read-more time-commitment3 toggle-overflow2">
                                    <p> @php echo $course3[0]->time_commitment_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                 <div class="read-more activity3 toggle-overflow2">
                                    <p> @php echo $course3[0]->activity_ar; @endphp </p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}} </h3>
                                <div class="read-more activity-type3 toggle-overflow2">
                                    <p> @php echo $course3[0]->activity_type_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation3 toggle-overflow2">
                                    <p> @php echo $course3[0]->accreditation_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="btns">
                                <a href="{{ url('course') }}/{{$course3[0]->id}}"
                                   class="btn btn-default btn-tall text-uppercase"> {{$compare_view_details->$Title}}</a>
                            </div>
                            <div class="btns">
                                <a href="{{ url('aljhood/apply-course?course_id=').$course3[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}} </a>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>قارن دورة اخرى</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(empty($course1[0]->id) && empty($course2[0]->id))
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-1">
                                            <option value="0" selected="selected" name="course1">اختر الدورة</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @elseif(!empty($course1[0]->id) && empty($course2[0]->id))
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-2">
                                            <option value="0" selected="selected" name="course1">اختر الدورة</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @else
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-3">
                                            <option value="0" selected="selected" name="course1">اختر الدورة</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif

                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">اضافة للمقارنة</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
                @if(!empty($course2[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse2">
                        <div class="compare-head"  id="myHeader2">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; left: 8%;">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course1">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2> @php echo $course2[0]->title_ar; @endphp</h2>
                            <br><p style="text-align: center !important;"> @php echo $course2[0]->subject_area_ar; @endphp </p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight2">
                            <div class="what-will-you-learn">
                                <h3>{{$compare_learn->$Title}}</h3>
                                <div class="read-more what-will-you-learn2 toggle-overflow">
                                    <p> @php echo $course2[0]->what_you_will_learn_ar; @endphp</p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto;">
                                <h3> {{$compare_skills->$Title}} </h3>
                                <div class="read-more skills2 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course2[0]->skills_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date2 toggle-overflow2">
                                    <p> @php echo $course2[0]->start_date; @endphp</p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}} </h3>
                                <div class="read-more time-commitment2 toggle-overflow2">
                                    <p> @php echo $course2[0]->time_commitment_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                <div class="read-more activity2 toggle-overflow2">
                                    <p> @php echo $course2[0]->activity_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}} </h3>
                                <div class="read-more activity-type2 toggle-overflow2">
                                    <p> @php echo $course2[0]->activity_type_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation2 toggle-overflow2">
                                    <p> @php echo $course2[0]->accreditation_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="btns">
                                <a href="{{ url('course') }}/{{$course2[0]->id}}"
                                   class="btn btn-default btn-tall text-uppercase">{{$compare_view_details->$Title}} </a>
                            </div>
                            <div class="btns">
                                <a href="{{ url('aljhood/apply-course?course_id=').$course2[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}} </a>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>قارن دورة اخرى</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course2">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-3">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course3">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course1[0]->id))
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-2">
                                            <option value="0" selected="selected">Cاختر دورة</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @else
                                    <div class="form-group">
                                        <select class="arrow_down" name="course-select-1">
                                            <option value="0" selected="selected">اختر دورة</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endif
                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">اضافة للمقارنة</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
                @if(!empty($course1[0]->id))
                    <div class="col-xs-12 col-sm-4" id="compareCourse1">
                        <div class="compare-head"  id="myHeader1">
                            <form action="{{ url('compare') }}" method="GET" style="position:absolute; left: 8%;">
                                @csrf
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course1">اختر الدورة</option>
                                        </select>
                                    </div>
                                @endif
                                <button type="submit" style="color: white;cursor: pointer; background: none; border: none"><i class="fas fa-times"></i></button>
                            </form>
                            <h2> @php echo $course1[0]->title_ar; @endphp</h2>
                            <br><p style="text-align: center !important;"> @php echo $course1[0]->subject_area_ar; @endphp</p>
                        </div>
                        <div class="list-unstyled price-list text-left" id="compareCourseHeight1">
                            <div class="what-will-you-learn">
                                <h3>{{$compare_learn->$Title}}</h3>
                                <div class="read-more what-will-you-learn1 toggle-overflow">
                                    <p> @php echo $course1[0]->what_you_will_learn_ar; @endphp</p>
                                </div>
                                @if(!empty($course1[0]) && !empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course2[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course2[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]) && !empty($course3[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course2[0]) && !empty($course3[0]))
                                    @if(strlen($course2[0]->what_you_will_learn_ar) > 315 || strlen($course3[0]->what_you_will_learn_ar) > 315)
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @elseif(!empty($course1[0]))
                                    @if(strlen($course1[0]->what_you_will_learn_ar) > 315 )
                                        <p class="read-more-btn">+ اقرأ المزيد</p>
                                    @else
                                        <br>
                                    @endif
                                @endif
                            </div>

                            <div class="skills" style="overflow-y:auto; text-align:center;">
                                <h3> {{$compare_skills->$Title}} </h3>
                                <div class="read-more skills1 toggle-overflow" style="overflow-y:auto;">
                                    <p> @php echo $course1[0]->skills_ar; @endphp </p>
                                </div>
                            </div>
                            <div class="course-date">
                                <h3>{{$compare_date->$Title}}</h3>
                                <div class="read-more course-date1 toggle-overflow2">
                                    <p> @php echo $course1[0]->start_date; @endphp </p>
                                </div>
                            </div>
                            <div class="time-commitment">
                                <h3>{{$choose_commitment->$Title}} </h3>
                                <div class="read-more time-commitment1 toggle-overflow2">
                                    <p> @php echo $course1[0]->time_commitment_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="activity">
                                <h3>{{$compare_activity->$Title}}</h3>
                                <div class="read-more activity1 toggle-overflow2">
                                    <p> @php echo $course1[0]->activity_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="activity-type">
                                <h3>{{$compare_activity_type->$Title}} </h3>
                                <div class="read-more activity-type1 toggle-overflow2">
                                    <p> @php echo $course1[0]->activity_type_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="accreditation">
                                <h3>{{$compare_acc->$Title}}</h3>
                                <div class="read-more accreditation1 toggle-overflow2">
                                    <p> @php echo $course1[0]->accreditation_ar; @endphp</p>
                                </div>
                            </div>
                            <div class="btns">
                                <a href="{{ url('course') }}/{{$course1[0]->id}}"
                                   class="btn btn-default btn-tall text-uppercase">{{$compare_view_details->$Title}} </a>
                            </div>
                            <div class="btns">
                                <a href="{{ url('aljhood/apply-course?course_id=').$course1[0]->id }}" class="btn btn-default bg-custom text-uppercase">{{$compare_apply->$Title}} </a>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-xs-12 col-sm-4">
                        <div class="list-unstyled price-list text-center">
                            <div class="add-to-compare-head">
                                <h2>اختر دورة</h2>
                            </div>
                            <form action="{{ url('compare') }}" method="GET">
                                @csrf
                                @if(!empty($course1[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-1">
                                            <option value="{{ $course1[0]->id }}" selected="selected" name="course1">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course2[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-2">
                                            <option value="{{ $course2[0]->id }}" selected="selected" name="course2">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                @if(!empty($course3[0]->id))
                                    <div class="form-group" style="display: none">
                                        <select class="arrow_down course-dropdown" name="course-select-3">
                                            <option value="{{ $course3[0]->id }}" selected="selected" name="course3">اختر دورة</option>
                                        </select>
                                    </div>
                                @endif
                                <div class="form-group">
                                    <select class="arrow_down" name="course-select-1">
                                        <option value="0" selected="selected">اختر دورة</option>
                                        @foreach($courses as $course)
                                            <option value="{{ $course->id }}"> @php echo $course->title_ar; @endphp </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-default bg-custom text-uppercase" type="submit">اضافة للمقارنة</button>
                                </div>
                            </form>
                        </div>
                    </div>
                @endif
            </div>

            <div class="go-back" style="margin: 50px 0 0 0;">
                <a href="{{ url('aljhood/courses') }}"><i class="fas fa-arrow-circle-left"></i> السابق</a>
            </div>
        </section>

    @endif

@stop

@section('scripts')
{{--    @if(empty($course1[0]->id) && empty($course2[0]->id) && empty($course3[0]->id))--}}
{{--        <script>--}}
{{--            @if(app()->getLocale() == "en")--}}
{{--            $(document).ready(function (){--}}
{{--                alert('please select at least one course');--}}
{{--            })--}}
{{--            @else--}}
{{--            $(document).ready(function (){--}}
{{--                alert('الرجاء اختيار دورة واحدة على الأقل');--}}
{{--            })--}}
{{--            @endif--}}
{{--        </script>--}}
{{--    @endif--}}


    <script>
        var x = $('#compareCourseHeight1').innerHeight();
        if (window.innerWidth > 991){
            $(window).load(function (){
                var width = $('#compareCourse1').width();
                $(window).on('scroll',function(){
                    var scroll = $(this).scrollTop();
                    if (scroll >= 400){
                        $('.compare-head').css({
                            'visibility' : 'visible',
                            'position' : 'fixed',
                            'width' : width,
                            'top' : '0',
                            'z-index' : '1',
                        });
                        $('.header-holder').removeClass('sticky');
                    }
                    if(scroll < 300){
                        $('.compare-head').css({
                            'visibility' : 'visible',
                            'position' : 'unset',
                            'width' : width,
                            'top' : '0',
                        })
                        $('.header-holder').removeClass('sticky');
                    }

                    if(scroll > x + 100){
                        $('.compare-head').css({
                            'visibility' : 'hidden',
                        })
                        $('.header-holder').removeClass('sticky');
                    }


                })
            })
        }


        if (window.innerWidth > 768) {
            window.onscroll = function () {
                myFunction()
            };

            var height = document.getElementById("compareCourseHeight1");
            var header = document.getElementById("myHeader1");
            var header2 = document.getElementById("myHeader2");
            var header3 = document.getElementById("myHeader3");
            var sticky = height.offsetTop;

            function myFunction() {
                if (window.pageYOffset > sticky) {
                    // header.classList.add("sticky-compare");
                    // header2.classList.add("sticky-compare");
                    // header3.classList.add("sticky-compare");
                } else {
                    // header.classList.remove("sticky-compare");
                    // header2.classList.remove("sticky-compare");
                    // header3.classList.remove("sticky-compare");
                }
            }
        }

    </script>
    @if(app()->getLocale() == "en")
        <script>
            $(window).load(function (){
                $('.list-unstyled.price-list .description .read-more-btn').click(function(){

                    $('.list-unstyled.price-list .description .read-more').toggleClass('toggle-overflow').animate();
                    var desc1 = $('.description1').innerHeight();
                    var desc2 = $('.description2').innerHeight();
                    var desc3 = $('.description3').innerHeight();
                    if (desc1 > desc2 && desc1 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc2 > desc1 && desc2 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc2);
                    } else if(desc3 > desc1 && desc3 > desc2){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc3);
                    } else if(desc1 == desc2 && desc1 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc1 == desc3 && desc1 > desc2){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc2 == desc3 && desc2 > desc1){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc2);
                    } else{
                        console.log('error height');
                        $('.list-unstyled.price-list .description .read-more').css('height' , 'auto');
                    }
                    if ($(this).text() == "+ Read More"){
                        $('.list-unstyled.price-list .description .read-more-btn').text("- Read Less");
                    } else{
                        $('.list-unstyled.price-list .description .read-more-btn').text("+ Read More");
                    }
                    setTimeout(function() {
                        x = $('#compareCourseHeight1').innerHeight();
                    }, 1000);
                })
            })
            $(window).load(function (){
                $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').click(function(){
                    $('.list-unstyled.price-list .what-will-you-learn .read-more').toggleClass('toggle-overflow');
                    var learn1 = $('.what-will-you-learn1').innerHeight();
                    var learn2 = $('.what-will-you-learn2').innerHeight();
                    var learn3 = $('.what-will-you-learn3').innerHeight();
                    if (learn1 > learn2 && learn1 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn2 > learn1 && learn2 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn2);
                    } else if(learn3 > learn1 && learn3 > learn2){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn3);
                    }else if(learn1 == learn2 && learn1 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn1 == learn3 && learn1 > learn2){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn2 == learn3 && learn2 > learn1){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn2);
                    } else{
                        console.log('error height');
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , 'auto');
                    }
                    if ($(this).text() == "+ Read More"){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').text("- Read Less");
                    }
                    else{
                        $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').text("+ Read More");
                    }
                    setTimeout(function() {
                        x = $('#compareCourseHeight1').innerHeight();
                    }, 1000);

                })
            })

        </script>
    @else
        <script>
            $(window).load(function (){
                $('.list-unstyled.price-list .description .read-more-btn').click(function(){
                    $('.list-unstyled.price-list .description .read-more').toggleClass('toggle-overflow').animate();
                    var desc1 = $('.description1').innerHeight();
                    var desc2 = $('.description2').innerHeight();
                    var desc3 = $('.description3').innerHeight();
                    if (desc1 > desc2 && desc1 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc2 > desc1 && desc2 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc2);
                    } else if(desc3 > desc1 && desc3 > desc2){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc3);
                    } else if(desc1 == desc2 && desc1 > desc3){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc1 == desc3 && desc1 > desc2){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc1);
                    } else if(desc2 == desc3 && desc2 > desc1){
                        $('.list-unstyled.price-list .description .read-more').css('height' , desc2);
                    } else{
                        console.log('error height');
                        $('.list-unstyled.price-list .description .read-more').css('height' , 'auto');
                    }
                    if ($(this).text() == "+ اقرأ المزيد"){
                        $('.list-unstyled.price-list .description .read-more-btn').text("- اقرأ أقل");
                    }
                    else{
                        $('.list-unstyled.price-list .description .read-more-btn').text("+ اقرأ المزيد");
                    }
                    setTimeout(function() {
                        x = $('#compareCourseHeight1').innerHeight();
                    }, 1000);

                })
            })
            $(window).load(function (){
                $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').click(function(){
                    $('.list-unstyled.price-list .what-will-you-learn .read-more').toggleClass('toggle-overflow');
                    var learn1 = $('.what-will-you-learn1').innerHeight();
                    var learn2 = $('.what-will-you-learn2').innerHeight();
                    var learn3 = $('.what-will-you-learn3').innerHeight();
                    if (learn1 > learn2 && learn1 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn2 > learn1 && learn2 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn2);
                    } else if(learn3 > learn1 && learn3 > learn2){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn3);
                    }else if(learn1 == learn2 && learn1 > learn3){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn1 == learn3 && learn1 > learn2){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn1);
                    } else if(learn2 == learn3 && learn2 > learn1){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , learn2);
                    } else{
                        console.log('error height');
                        $('.list-unstyled.price-list .what-will-you-learn .read-more').css('height' , 'auto');
                    }
                    if ($(this).text() == "+ اقرأ المزيد"){
                        $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').text("- اقرأ أقل");
                    }
                    else {
                        $('.list-unstyled.price-list .what-will-you-learn .read-more-btn').text("+ اقرأ المزيد");
                    }
                    setTimeout(function() {
                        x = $('#compareCourseHeight1').innerHeight();
                    }, 1000);

                })
            })

        </script>
    @endif

@stop
