<!------------------------- contact us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.contactus'))

@section('content')

<?php $banner=DB::table('page_contents')->where('ref_page','=','contact_banner')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
?>

	<!-- heading banner -->
    @if(app()->getLocale() == "en")
    
        <header class="heading-banner text-dark bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        
	<!-- breadcrumb nav -->
	<nav class="breadcrumb-nav">
		<div class="container">
			<!-- breadcrumb -->
			<ol class="breadcrumb">
				<li><a href="{{ url('/') }}">Home</a></li>
				<li class="active">Contact Us</li>
			</ol>
		</div>
	</nav>

	<!-- contact block -->
	<section class="contact-block">
		<div class="container">
			<header class="seperator-head text-center">
				<h2  class="h2h2h2"> @php echo $content->title_en; @endphp</h2>
				<p> @php echo $content->description_en; @endphp </p>
			</header>
			<!-- contact form -->
			<div class="row" style="box-shadow:5px 5px 10px grey;">
				<div class="col-md-4 details col-sm-4" style="margin-top: 30px ; padding: 0 30px">
					<h2>  @php echo $call->title_en @endphp <br> <span>  @php echo $call->description_en; @endphp  </span> </h2>
					<address class="ft-address">
						<dl>
							<dt><span class="fas fa-phone-square"><span class="sr-only"> @php echo $phone->title_en; @endphp </span></span></dt>
							<dd><a href="tel:{{ $phone->description_en }}"> @php echo $phone->description_en; @endphp</a></dd>
							<dt><span class="fas fa-envelope-square"><span class="sr-only">  @php echo $email->title_en; @endphp</span></span></dt>
							<dd><a href="mailto:{{ $email->description_en }}">  @php echo $email->description_en; @endphp</a></dd>
							<dt><span class="fas fa-map-marker"><span class="sr-only">  @php echo $location->title_en ; @endphp</span></span></dt>
							<dd> @php echo $location->description_en ; @endphp</dd>
						</dl>
					</address>
				</div>
				<div class="col-md-8 col-sm-8" style="margin-top: 30px">
					<form id="contact_form"  class="contact-form" action="javascript:void(0)" enctype="multipart/form-data">
							<div class="form-group">
                                <input type="text" class="form-control element-block" placeholder="Your Name" name="report_type" value="contact" style="display: none">
                                <input id="name" type="text" class="form-control element-block" placeholder="Your Name" name="name" required>
							</div>
							<div class="form-group">
								<input id="email" type="email" class="form-control element-block" placeholder="Email" name="email" required>
							</div>
							<div class="form-group">
								<textarea id="message" class="form-control element-block" placeholder="Message" name="message" required></textarea>
							</div>
						<div class="text-center">
							<button  type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">Send Message</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</section>
	<section class="container countries text-center" style="max-width: 800px !important;">
        <div class="row slider extra3-slider">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <div class="country-icon">
                    <img src="{{ asset('frontend/images/icons/icons-01.png') }}" alt="">
                </div>
                <div class="country-name">
                    <h6>Jordan</h6>
                </div>
                <div class="country-location">
                    <a type="button" data-toggle="modal" data-target="#seeMapJordan">(See Map)</a>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <div class="country-icon">
                    <img src="{{ asset('frontend/images/icons/icons-02.png') }}" alt="">
                </div>
                <div class="country-name">
                    <h6>Saudi Arabia</h6>
                </div>
                <div class="country-location">
                    <a type="button" data-toggle="modal" data-target="#seeMapSaudi">(See Map)</a>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <div class="country-icon">
                    <img src="{{ asset('frontend/images/icons/icons-03.png') }}" alt="">
                </div>
                <div class="country-name">
                    <h6>Libya</h6>
                </div>
                <div class="country-location">
                    <a type="button" data-toggle="modal" data-target="#seeMapLibya">(See Map)</a>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <div class="country-icon">
                    <img src="{{ asset('frontend/images/icons/icons-04.png') }}" alt="">
                </div>
                <div class="country-name">
                    <h6>Sudan</h6>
                </div>
                <div class="country-location">
                    <a type="button" data-toggle="modal" data-target="#seeMapSudan" hidden>(See Map)</a>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <div class="country-icon">
                    <img src="{{ asset('frontend/images/icons/icons-05.png') }}" alt="">
                </div>
                <div class="country-name">
                    <h6>Iraq</h6>
                </div>
                <div class="country-location ">
                    <a type="button" data-toggle="modal" data-target="#seeMapSudan" hidden>(See Map)</a>
                </div>
            </div>
        </div>

        <div class="divider" style="margin-top: 20px"></div>
        <div class="more-countries text-right more-more">
            <p type="button" data-toggle="modal" data-target="#viewMoreCountries" class="col-lg-3" style="cursor: pointer"> View More Countries <i class="fas fa-chevron-right"></i></p>
        </div>
	</section>
	<!-- subscription aside block -->
	<aside class="subscription-aside-block bg-theme text-white">
		<!-- newsletter sub form -->
		<form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form" enctype="multipart/form-data">
			<div class="row form-holder">
				<div class="col-xs-12 col-sm-6 col">
					<div class="text-wrap">
						<span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span class="sr-only">icn</span></i></span>
						<div class="inner-wrap">
							<label for="email">Signup for Newsletter</label>
							<p>Subscribe to get your daily close of useful courses.</p>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col">
					<div class="input-group">
						<input type="email" id="email" name="email" class="form-control" placeholder="Enter your email&hellip;">
						<span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">Subscribe</button>
						</span>
					</div>
				</div>
			</div>
		</form>
	</aside>

    {{--    Modals    --}}
    <div class="modal fade bd-example-modal-lg" id="viewMoreCountries" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="{{ asset('frontend/images/countries') }}/countries.jpg">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="seeMapJordan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d3383.5503665981073!2d35.87718397317888!3d32.000202268839345!3m2!1i1024!2i768!4f13.1!2m1!1sAljhood%20Croup!5e0!3m2!1sen!2sjo!4v1684416127393!5m2!1sen!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="seeMapSaudi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d905.7934241746734!2d46.697117899999995!3d24.755233!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2efd6307effad5%3A0x4b656c11126f993a!2zODA0NCDYt9ix2YrZgiDYp9io2Yog2KjZg9ixINin2YTYtdiv2YrZgiDYp9mE2YHYsdi52YrYjCDYp9mE2YXYsdiz2YTYp9iq2Iwg2KfZhNix2YrYp9i2IDEyNDY02Iwg2KfZhNiz2LnZiNiv2YrYqQ!5e0!3m2!1sar!2sjo!4v1684416764647!5m2!1sar!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="seeMapLibya" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3351.0385257520547!2d13.19223851518447!3d32.870700080943855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMzLCsDUyJzE0LjUiTiAxM8KwMTEnMzkuOSJF!5e0!3m2!1sen!2sjo!4v1684416456573!5m2!1sen!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="seeMapSudan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1692.5387581564253!2d35.854884991929275!3d31.95879369964148!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe3f0312bde5d5c6b!2sRumman%20tech!5e0!3m2!1sen!2sjo!4v1636534992633!5m2!1sen!2sjo" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="contactFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="{{ url('frontend/images/reports/Contact-us-en.jpeg') }}">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">Check our privacy policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @else
        <header class="heading-banner text-dark bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li class="active">تواصل معنا</li>
                </ol>
            </div>
        </nav>

        <!-- contact block -->
        <section class="contact-block rtl">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2  class="h2h2h2"> @php echo $content->title_ar; @endphp</h2>
                    <p> @php echo $content->description_ar; @endphp </p>
                </header>
                <!-- contact form -->
                <div class="row" style="box-shadow:5px 5px 10px grey;">
                    <div class="col-md-4 details col-sm-4" style="margin-top: 30px ; padding: 0 30px">
                        <h2 style="letter-spacing: 0 !important;">  @php echo $call->title_ar @endphp <br> <span>  @php echo $call->description_ar; @endphp  </span> </h2>
                        <address class="ft-address">
                            <dl>
                                <dt><span class="fas fa-phone-square"><span class="sr-only"> @php echo $phone->title_ar; @endphp </span></span></dt>
                                <dd><a href="tel:{{ $phone->description_en }}"> @php echo $phone->description_ar; @endphp</a></dd>
                                <dt><span class="fas fa-envelope-square"><span class="sr-only">  @php echo $email->title_ar; @endphp</span></span></dt>
                                <dd><a href="mailto:{{ $email->description_en }}">  @php echo $email->description_ar; @endphp</a></dd>
                                <dt><span class="fas fa-map-marker"><span class="sr-only">  @php echo $location->title_ar ; @endphp</span></span></dt>
                                <dd> @php echo $location->description_ar ; @endphp</dd>
                            </dl>
                        </address>
                    </div>
                    <div class="col-md-8 col-sm-8" style="margin-top: 30px">
                        <form id="contact_form"  class="contact-form" action="javascript:void(0)" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="text" class="form-control element-block" placeholder="Your Name" name="report_type" value="contact" style="display: none">
                                <input id="name" type="text" class="form-control element-block" placeholder="الاسم" name="name" required>
                            </div>
                            <div class="form-group">
                                <input id="email" type="email" class="form-control element-block" placeholder="البريد الالكتروني" name="email" required>
                            </div>
                            <div class="form-group">
                                <textarea id="message" class="form-control element-block" placeholder="الرسالة" name="message" required></textarea>
                            </div>
                            <div class="text-center">
                                <button  type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">ارسال</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <section class="container countries text-center rtl" style="max-width: 800px !important;">
            <div class="row slider extra3-slider" style="direction: ltr">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 rtl">
                    <div class="country-icon">
                        <img src="{{ asset('frontend/images/icons/icons-01.png') }}" alt="">
                    </div>
                    <div class="country-name">
                        <h6>الاردن</h6>
                    </div>
                    <div class="country-location">
                        <a type="button" data-toggle="modal" data-target="#seeMapJordan" style="font-size: 11px">(مشاهدة الموقع)</a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 rtl">
                    <div class="country-icon">
                        <img src="{{ asset('frontend/images/icons/icons-02.png') }}" alt="">
                    </div>
                    <div class="country-name">
                        <h6>السعودية</h6>
                    </div>
                    <div class="country-location">
                        <a type="button" data-toggle="modal" data-target="#seeMapSaudi" style="font-size: 11px">(مشاهدة الموقع)</a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 rtl">
                    <div class="country-icon">
                        <img src="{{ asset('frontend/images/icons/icons-03.png') }}" alt="">
                    </div>
                    <div class="country-name">
                        <h6>ليبيا</h6>
                    </div>
                    <div class="country-location">
                        <a type="button" data-toggle="modal" data-target="#seeMapLibya" style="font-size: 11px">(مشاهدة الموقع)</a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 rtl">
                    <div class="country-icon">
                        <img src="{{ asset('frontend/images/icons/icons-04.png') }}" alt="">
                    </div>
                    <div class="country-name">
                        <h6>السودان</h6>
                    </div>
                    <div class="country-location ">
                        <a type="button" data-toggle="modal" data-target="#seeMapSudan" style="font-size: 11px" hidden>(مشاهدة الموقع)</a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 rtl">
                    <div class="country-icon">
                        <img src="{{ asset('frontend/images/icons/icons-05.png') }}" alt="">
                    </div>
                    <div class="country-name">
                        <h6>العراق</h6>
                    </div>
                    <div class="country-location ">
                        <a type="button" data-toggle="modal" data-target="#seeMapSudan" style="font-size: 11px" hidden>(مشاهدة الموقع)</a>
                    </div>
                </div>
            </div>
            <div class="divider" style="margin-top: 20px"></div>
            <div class="more-countries text-left more-more">
                <p type="button" data-toggle="modal" data-target="#viewMoreCountries" class="col-lg-3" style="cursor: pointer"> مشاهدة المزيد من البلدان <i class="fas fa-chevron-left"></i></p>
            </div>
        </section>
        <!-- subscription aside block -->
        <aside class="subscription-aside-block bg-theme text-white rtl">
            <!-- newsletter sub form -->
            <form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form">
                <div class="row form-holder">
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="text-wrap">
                            <span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span class="sr-only">icn</span></i></span>
                            <div class="inner-wrap">
                                <label for="email">الاشتراك بالنشرة البريدية</label>
                                <p>اشترك للحصول على نهايتك اليومية من الدورات التدريبية المفيدة.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-control" placeholder="ادخل البريد الالكتروني&hellip;">
                            <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">الاشتراك</button>
						</span>
                        </div>
                    </div>
                </div>
            </form>
        </aside>

        {{--    Modals    --}}
        <div class="modal fade bd-example-modal-lg" id="viewMoreCountries" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ asset('frontend/images/countries') }}/countries.jpg">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bd-example-modal-lg" id="seeMapJordan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d3383.5503665981073!2d35.87718397317888!3d32.000202268839345!3m2!1i1024!2i768!4f13.1!2m1!1sAljhood%20Croup!5e0!3m2!1sen!2sjo!4v1684416127393!5m2!1sen!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div></div>
        <div class="modal fade bd-example-modal-lg" id="seeMapSaudi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d905.7934241746734!2d46.697117899999995!3d24.755233!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2efd6307effad5%3A0x4b656c11126f993a!2zODA0NCDYt9ix2YrZgiDYp9io2Yog2KjZg9ixINin2YTYtdiv2YrZgiDYp9mE2YHYsdi52YrYjCDYp9mE2YXYsdiz2YTYp9iq2Iwg2KfZhNix2YrYp9i2IDEyNDY02Iwg2KfZhNiz2LnZiNiv2YrYqQ!5e0!3m2!1sar!2sjo!4v1684416764647!5m2!1sar!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>Success!
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bd-example-modal-lg" id="seeMapLibya" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
<iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3351.0385257520547!2d13.19223851518447!3d32.870700080943855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMzLCsDUyJzE0LjUiTiAxM8KwMTEnMzkuOSJF!5e0!3m2!1sen!2sjo!4v1684416456573!5m2!1sen!2sjo" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bd-example-modal-lg" id="seeMapSudan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1692.5387581564253!2d35.854884991929275!3d31.95879369964148!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe3f0312bde5d5c6b!2sRumman%20tech!5e0!3m2!1sen!2sjo!4v1636534992633!5m2!1sen!2sjo" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bd-example-modal-lg" id="contactFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/Contact-us-ar.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">تحقق من سياسة الخصوصية</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif



@stop
@section('scripts')
<script>

    $('#contact_form').submit(function (){
        var formData = new FormData();
        var url = $('meta[name=base_url]').attr("content");
        var csrf_token = $('meta[name=csrf_token]').attr("content");
        formData.append("report_type", "contact");
        formData.append("name", $('#name').val());
        formData.append("email", $('#email').val());
        formData.append("message", $('#message').val());
        formData.append("_token", csrf_token);
        console.log(formData);

        $.ajax({
            url: url+'/contactForm',
            type: 'post',
            data: formData,
            cache : false,
            processData: false,
            contentType: false,
            success: function(){
                console.log('Yes');
                $('#contactFormModal').modal('show');
                $("#contact_form")[0].reset();
            },
            error: function (){
                console.log('error');
            }
        });
    })

</script>
@stop
