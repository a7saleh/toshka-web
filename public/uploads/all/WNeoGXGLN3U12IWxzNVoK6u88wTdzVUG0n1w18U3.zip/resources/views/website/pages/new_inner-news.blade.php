<!------------------------- inner news content -------------------------->
@extends('website.layout.master')

@section('title')
    @if(app()->getLocale() == "en")
        {{ $news[0]->title_en }}
    @else
        {{ $news[0]->title_ar }}
    @endif
@endsection
@section('description')
    @if(app()->getLocale() == "en")
        {{ $news[0]->meta_description_en }}
    @else
        {{ $news[0]->meta_description_ar }}
    @endif
@endsection
@section('description_og')
    @if(app()->getLocale() == "en")
    
        {{ $news[0]->meta_description_en }}
    @else
        {{ $news[0]->meta_description_ar }}
    @endif
@endsection
@section('description_tw')
    @if(app()->getLocale() == "en")
        {{ $news[0]->meta_description_en }}
    @else
        {{ $news[0]->meta_description_ar }}
    @endif
@endsection

@section('image_og')
    {{ asset('storage/uploads/news') }}/{{ $news[0]->file }}
@endsection
@section('image_tw')
    {{ asset('storage/uploads/news') }}/{{ $news[0]->file }}
@endsection



<?php
$Title="title_".app()->getLocale();
$news_page_title=DB::table('page_contents')->where('ref_page','news_page_title')->first();
$news_keep_reading_title=DB::table('page_contents')->where('ref_page','news_keep_reading_title')->first();
?>

@section('content')
    @if(app()->getLocale() == "en")
	<header class="heading-banner bgCover" style="padding: 0; margin: 0;">
		<div class="acme-news-ticker" style="border-bottom: 2px solid #999;">
		    <div class="acme-news-ticker-label">{{$news_page_title->$Title}}</div>
		    <div class="acme-news-ticker-box">
		        <ul class="my-news-ticker">
		        	@foreach($recent_news as $r_news)
                        <a href="{{ url('news') }}/{{ $r_news->id }}"><li> @php echo $r_news->title_en @endphp |</li></a>
		        	@endforeach
		        </ul>
		    </div>
		</div>
	</header>

	<!-- breadcrumb nav -->
	<nav class="breadcrumb-nav">
		<div class="containers" style="margin: 0 10px">
			<!-- breadcrumb -->
			<ol class="breadcrumb">
				<li><a href="{{ url('/') }}">Home</a></li>
				<li><a href="{{ url('aljhood/news') }}">News</a></li>
				<li class="active">{{ $news[0]->title_en }}</li>
			</ol>
		</div>
	</nav>
	<!-- text info block -->
    <div class="container">
        <?php  $img_url_name=$news[0]->inner_image??$news[0]->file;?>
        <img src="{{ asset('storage/uploads/news') }}/{{$img_url_name}}" class="element-block image"  alt="no-photo" style="width:100%;">

        <article class="container-fluid text-info-block news-section">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 animate__animated animate__backInLeft">
                    <h1> @php echo $news[0]->title_en @endphp</h1>
                    <p style="color:#55555570; font-weight: 600;"> <i class="fa fa-clock"> </i> {{ date('d-m-Y', strtotime($news[0]->date) ) }} </p>
                    <p style="text-align: justify;">  @php echo $news[0]->content_en @endphp</p>

                    <div class="inner-news-page">
                    <div id="social-links">
	<ul>
		<li><a href="https://www.facebook.com/sharer/sharer.php?u={{URL::current()}}" class="social-button " id=""><span class="fa fa-facebook"></span></a></li>
		<li><a href="https://twitter.com/intent/tweet?text=my share text&amp;url={{URL::current()}}" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
		<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{URL::current()}}&amp;title=my share text&amp;summary=" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
		<li><a href="https://wa.me/?text={{URL::current()}}" class="social-button " id=""><span class="fa fa-whatsapp"></span></a></li>    
	</ul>
</div>
                   </div>
                    <section class="popular-posts-block container">
                        <header class="popular-posts-head">
                            <h2 class="popular-head-heading hr_head">{{$news_keep_reading_title->$Title}}</h2>
                        </header>
                        <div class="row">
                            <!-- popular posts slider -->
                            <div id="popular_news" class="slider related-course-slider popular-courses">
                                @foreach($keep_reading as $key => $t_news)
                                    <div>
                                        <div class="col-xs-12">
                                            <!-- popular post -->
                                            <a href="{{ url('news') }}/{{ $t_news->id }}">
                                                <article class="popular-post popular-course">
                                                    <div class="aligncenter">
                                                        <img class="news-img-height" src="{{ asset('storage/uploads/news') }}/{{ $t_news->file }}"
                                                             alt="no-photo">
                                                    </div>

                                                    <h6 style="margin-top: 5px;" class="post-heading news-h3-height">
                                                        <a href="{{ url('news') }}/{{ $t_news->id }}">
                                                            @php echo $t_news->title_en @endphp
                                                        </a>
                                                    </h6>
                                                </article>
                                            </a>

                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </article>
    </div>
    <!-- subscription aside block -->
    <aside class="subscription-aside-block bg-theme text-white" style="background-color: #222222; border-bottom: 1px solid #3f3f3f">
        <!-- newsletter sub form -->
        <form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form">
            <div class="row form-holder">
                <div class="col-xs-12 col-sm-6 col">
                    <div class="text-wrap">
                        <span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span
                                    class="sr-only">icn</span></i></span>
                        <div class=" -wrap">
                            <label for="email">Signup for Newsletter</label>
                            <p>Subscribe to get your daily close of useful courses.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col">
                    <div class="input-group">
                        <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email&hellip;">
                        <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">Subscribe</button>
						</span>
                    </div>
                </div>
            </div>
        </form>
    </aside>
    <!-- counter aside -->

    @else
    
        <header class="heading-banner bgCover" style="padding: 0; margin: 0;">
            <div class="acme-news-ticker" style="border-bottom: 2px solid #999;">
                <div class="acme-news-ticker-label" style="float: right !important;">الاخبار</div>

                <div class="acme-news-ticker-box">
                    <ul class="my-news-ticker">
                        @foreach($recent_news as $r_news)
                            <a href="{{ url('news') }}/{{ $r_news->id }}"><li> @php echo $r_news->title_ar @endphp |</li></a>
                        @endforeach
                    </ul>

                </div>
            </div>
        </header>

        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="containers" style="margin: 0 10px">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li><a href="{{ url('/aljhood/news') }}">الاخبار</a></li>
                    <li class="active">{{ $news[0]->title_ar }}</li>
                </ol>
            </div>
        </nav>
        <!-- text info block -->
        <div class="container">
                    <?php  $img_url_name=$news[0]->inner_image??$news[0]->file;?>
        <img src="{{ asset('storage/uploads/news') }}/{{$img_url_name}}" class="element-block image"  alt="no-photo" style="width:100%;">
            <article class="container-fluid text-info-block news-section rtl">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 animate__animated animate__backInLeft">
                        <h1> @php echo $news[0]->title_ar @endphp</h1>
                        <p style="color:#55555570; font-weight: 600;"> <i class="fa fa-clock"> </i> {{ date('Y-m-d', strtotime($news[0]->created_at) ) }} </p>
                        <p style="text-align: justify;">  @php echo $news[0]->content_ar @endphp</p>

                        <div class="inner-news-page-ar">
                        <div id="social-links">
	<ul>
		<li><a href="https://www.facebook.com/sharer/sharer.php?u={{URL::current()}}" class="social-button " id=""><span class="fa fa-facebook"></span></a></li>
		<li><a href="https://twitter.com/intent/tweet?text=&amp;url={{URL::current()}}" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
		<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{URL::current()}}&amp;title=my share text&amp;summary=" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
		<li><a href="https://wa.me/?text={{URL::current()}}" class="social-button " id=""><span class="fa fa-whatsapp"></span></a></li>    
	</ul>
</div>
                   </div>
                    </div>
                        <section class="popular-posts-block container" style="direction: ltr">
                            <header class="popular-posts-head rtl">
                                <h2 class="popular-head-heading hr_head">{{$news_keep_reading_title->$Title}}</h2>
                            </header>
                            <div class="row">
                                <!-- popular posts slider -->
                                <div id="popular_news" class="slider related-course-slider popular-courses">
                                    @foreach($keep_reading as $key => $t_news)
                                        <div>
                                            <div class="col-xs-12">
                                                <!-- popular post -->
                                                <a href="{{ url('news') }}/{{ $t_news->id }}">
                                                    <article class="popular-post popular-course rtl">
                                                        <div class="aligncenter">
                                                            <img class="news-img-height" src="{{ asset('storage/uploads/news') }}/{{ $t_news->file }}"
                                                                 alt="no-photo">
                                                        </div>

                                                    <h6 style="margin-top:5px;" class="post-heading news-h3-height">
                                                        <a href="{{ url('news') }}/{{ $t_news->id }}">
                                                            @php echo $t_news->title_en @endphp
                                                        </a>
                                                    </h6>
                                                    </article>
                                                </a>

                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </article>
        </div>
        <!-- subscription aside block -->
        <aside class="subscription-aside-block bg-theme text-white rtl" style="background-color: #222222; border-bottom: 1px solid #3f3f3f">
            <!-- newsletter sub form -->
            <form action="javascript:void(0)" id="newsLetterForm" class="container newsletter-sub-form">
                <div class="row form-holder">
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="text-wrap">
                        <span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span
                                    class="sr-only">icn</span></i></span>
                            <div class="inner-wrap">
                                <label for="email">الاشتاك بالنشرة البريدية</label>
                                <p>اشترك للحصول على نهايتك اليومية من الدورات التدريبية المفيدة.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-control" placeholder="ادحل البيريد الالكتروني&hellip;">
                            <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">الاشتراك</button>
						</span>
                        </div>
                    </div>
                </div>
            </form>
        </aside>
        <!-- counter aside -->

    @endif
@stop

@section('scripts')
	<script>
		//subscribe form news section
		$('.form-submit').click(function(e){
		  document.querySelector('.form-submit').classList.add('form-active');
		});
	</script>
@stop
