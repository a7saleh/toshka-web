<!------------------------- about us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.aboutus'))

@section('content')


<?php $banner=DB::table('page_contents')->where('ref_page','=','about_banner')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
$Description_Name='description_'.app()->getLocale();
if(app()->getLocale()=="en"){
$TextAlign="left";   
}else{
$TextAlign="right";   
}
?>

        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->

        <!-- text info block -->    
    
     @if(app()->getLocale()=="ar")
     <div class="container section_about text-right rtl">

                <nav class="breadcrumb-nav gall-bread">
                    <div class="container">
                        <!-- breadcrumb -->
                        <ol class="breadcrumb">
                            <li><a href="{{ url('/') }}">الرئيسية</a></li>
                            <li class="active"> الجهود قصة نجاح</li>
                        </ol>
                    </div>
                </nav>
@else
<div class="container section_about text-center">

        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">@lang('Home')</a></li>
                    <li class="active">About Us</li>
                </ol>
            </div>
        </nav>
@endif


    @foreach($head_content as $content)
    
    @if(app()->getLocale()=="ar")
    
            <div class="row"  style="background-color:#be9f56; padding:25px; opacity:0.9; border-radius:10px;color:white;">
                <div class="col-md-7" style="padding:1%; text-align:{{$TextAlign}};">
                    <p style="color:white; font-weight:bold; font-size:21px;"><strong style="color:white;">@php echo $content->$Title_Name; @endphp</strong></p>
                    <p style=" color:white; font-weight:bold;"><strong style="color:white;"> 
                    @php echo $content->$Description_Name; @endphp    
                    </strong></p>
                    <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->url }}" alt="" style="width:200px;">
                </div>
                <div class="col-md-5">
                    <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" alt="" style="height:80%;">
                </div>
            </div>
            
@else
            <div class="row"  style="background-color:#be9f56; padding:25px; opacity:0.9; border-radius:10px;color:white;">
                <div class="col-md-5">
                    <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" alt="" style="height:80%;">
                </div>                <div class="col-md-7" style="padding:1%; text-align:{{$TextAlign}};">
                    <p style="color:white; font-weight:bold; font-size:21px;"><strong style="color:white;">@php echo $content->$Title_Name; @endphp</strong></p>
                    <p style="padding-top:15px; color:white; font-weight:bold;"><strong style="color:white;"> 
                    @php echo $content->$Description_Name; @endphp    
                    </strong></p>
                    <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->url }}" alt="" style="width:200px;">
                </div>
            </div>

@endif
            
            @endforeach
            
            
    <section id="values" class="values mb-5">
      <div class="container" data-aos="fade-up">
@foreach($contents as $key => $content)
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="0"></div>
                  
                 <div class="col-lg-10" data-aos="fade-up" data-aos-delay="0">
            <div class="box" style="border:3px solid #be9f56;">
              <h2 class="gold-color">@php echo $content->$Title_Name; @endphp</h2>
              <p><strong>@php echo $content->$Description_Name; @endphp</strong></p>
    @if(!empty($content->image))
        <img  src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" class="element-block image"  alt="no-photo">
    @else
        <iframe  src="{{ $content->video }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    @endif
            </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="0"></div>
          </div>
@endforeach          
      </div>
    </section><br><br>
            
</div>       
@stop
