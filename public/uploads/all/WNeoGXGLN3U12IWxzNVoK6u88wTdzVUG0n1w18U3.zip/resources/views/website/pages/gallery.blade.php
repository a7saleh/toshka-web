<!------------------------- gallery content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.gallery'))

@section('content')
    @if($checkLang == 1)
        @php
            $lang = 1;
        @endphp
    @endif
<?php
$search_course_form_activity_place=DB::table('page_contents')->where('ref_page','search_course_form_activity_place')->first();
$gallery_form_course=DB::table('page_contents')->where('ref_page','gallery_form_course')->first();
$gallery_form_date=DB::table('page_contents')->where('ref_page','gallery_form_date')->first();

?>
    @if(app()->getLocale() == "en")
        <div class="gallery holder" style="background-image:url(https://img.rawpixel.com/s3fs-private/rawpixel_images/website_content/rm309-adj-01.jpg?w=800&dpr=1&fit=default&crop=default&q=65&vib=3&con=3&usm=15&bg=F4F4F3&ixlib=js-2.2.1&s=2204002a48c0d2dc60c1a27a4cc4fd97); background-repeat: no-repeat; background-size: cover;">


        <section class="gallery-section margin-top-90">
            <nav class="breadcrumb-nav gall-bread">
                <div class="container">
                    <!-- breadcrumb -->
                    <ol class="breadcrumb">
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li class="active">Gallery</li>
                    </ol>
                </div>
            </nav>
            <div class="container filter-gallery">
                <div class="row" style="margin-top: 30px">
                    <form action="{{ url('filterGallery') }}" method="GET">
                        @csrf
                        <div class="form-group col-md-3 col-sm-4 col-xs-12">
                            <select class="arrow_down" id="course_id" name="course">
                                <option value="" disabled="disabled" selected="selected">{{$gallery_form_course->title_en}}</option>
                                <option value="all">ALL</option>
                                <option value="other">other</option>
                                @foreach($courses as $course)
                                    <option value="{{ $course->id }}"> {{ $course->title_en }} </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-3 col-sm-4 col-xs-12">
                            <input type="text" id="course_date" class="form-control arrow_down gallery-calendar" placeholder="{{$gallery_form_date->title_en}}" name="date" autocomplete="off" readonly style="background-color: #fff !important;">
                        </div>
                        <div class="form-group col-md-3 col-sm-4 col-xs-12">
                            <select class="arrow_down" id="location" name="location">
                                <option value="" disabled="disabled" selected="selected">{{$search_course_form_activity_place->title_en}}</option>
                                <option value="all">ALL</option>
                                @foreach($locations as $location)
                                    <option value="{{ $location->id }}"> {{ $location->country_name }} </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-md-3 col-sm-3 col-xs-12" style="display: flex; flex-direction: row; justify-content: center; align-items: center">
                            <button class="btn btn-block btn-aljhood filter_courses filter_gallery_btn"  style="width: 48%">Filter</button>
                            <a href="{{ url('aljhood/gallery') }}" class="btn btn-block btn-aljhood filter_courses filter_gallery_btn"  style="width: 48% ; margin: 0 5px">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            @if(count($gallery) != 0)
            <div class="container blog-section gallery-content gallery-posts">
                @php
                    $galleryDuration = 1000;
                    $counter = 0 ;
                @endphp

                @foreach($gallery as  $gal)
                    <div class="col-md-4 mr-auto-75-wt mr-auto-75-wt-new" data-aos="fade-up" data-aos-duration="{{ $galleryDuration + $counter }}" data-aos-easing="ease-in-out" onclick="galleryFunction({{ $gal->id }})" style="cursor: pointer">
                        <a href="{{ url('gallery') }}/{{ $gal->id }}">
                            <div class="widget widget-blog">
                                <div class="widget-blog-cover">
                                    <img src="{{ asset('storage/uploads/gallery') }}/{{ $gal->cover_photo }}" alt="no-photo">
                                </div>
                                <div class="widget-blog-content">
                                    <h5><a href="{{ url('gallery') }}/{{ $gal->id }}">{{ $gal->title_en }}</a></h5>
                                    <p><i class="fa fa-map-marker"></i> {{ $gal->location->country_name }}</p>
                                    @if(!empty($gal->id))
                                        <p> <i class="fa fa-calendar"></i> {{ $gal->date }}</p>
                                    @endif
                                </div>
                            </div>
                        </a>
                    </div>
                    @php
                        $counter = 300;
                        $galleryDuration = $galleryDuration + $counter;
                    @endphp

                @endforeach
            </div>
            @else
                <div class="container blog-section gallery-content">
                    <div class="row">
                        <div class="col-lg-12">
                            @if($course_request == 'faked' && $date_request == 'faked' && $location_request == 'faked')
                                <p class="text-center">Please select at least one search option.</p>
                            @else
                                <p class="text-center">No albums found related to your search. Try selecting another search option.</p>
                            @endif
                        </div>
                    </div>
                </div>
            @endif
        </section>


    @if($links == 1)
        <div style="display: flex; flex-direction: row; justify-content: center;">
            <div style="text-align: center;">{{ $gallery->links() }}</div>
        </div>
    @endif
    @if($links == 1)
        <div class="pt-15" style="display: flex; flex-direction: row; justify-content: center;">
            <div style="text-align: center;"> {{ $gallery->lastItem() }}
                of {{ $gallery->total() }} Albums.
            </div>
        </div>
    @endif



</div>
    @else
        <div class="gallery holder rtl" style="background-image:url(https://img.rawpixel.com/s3fs-private/rawpixel_images/website_content/rm309-adj-01.jpg?w=800&dpr=1&fit=default&crop=default&q=65&vib=3&con=3&usm=15&bg=F4F4F3&ixlib=js-2.2.1&s=2204002a48c0d2dc60c1a27a4cc4fd97); background-repeat: no-repeat; background-size: cover;">
            <section class="gallery-section margin-top-90">
                <nav class="breadcrumb-nav gall-bread">
                    <div class="container">
                        <!-- breadcrumb -->
                        <ol class="breadcrumb">
                            <li><a href="{{ url('/') }}">الرئيسية</a></li>
                            <li class="active">الصور</li>
                        </ol>
                    </div>
                </nav>
                <div class="container filter-gallery">
                    <div class="row" style="margin-top:30px">
                        <form action="{{ url('filterGallery') }}" method="GET" class="about-us-sec1">
                            @csrf
                            <div class="form-group col-md-3 col-sm-3 col-xs-12" style="display: flex; flex-direction: row; justify-content: center; align-items: center">
                                <button class="btn btn-block btn-primary filter_courses filter_gallery_btn" style="width: 48%">بحث</button>
                                <a href="{{ url('aljhood/gallery') }}" class="btn btn-block btn-primary filter_courses filter_gallery_btn" style="width: 48% ; margin: 0 5px">حذف</a>
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <select class="arrow_down" id="location" name="location">
                                    <option value="" disabled="disabled" selected="selected">{{$search_course_form_activity_place->title_ar}}</option>
                                    <option value="all">ALL</option>
                                    @foreach($locations as $location)
                                        <option value="{{ $location->id }}"> {{ $location->country_name_ar }} </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <input type="text" id="course_date" class="form-control arrow_down rtl gallery-calendar" placeholder="{{$gallery_form_date->title_ar}}" name="date" autocomplete="off" readonly style="background-color: #fff !important;">
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <select class="arrow_down" id="course_id" name="course">
                                    <option value="" disabled="disabled" selected="selected">{{$gallery_form_course->title_ar}}</option>
                                    <option value="all">الكل</option>
                                    <option value="other">أخرى</option>
                                    @foreach($courses as $course)
                                        <option value="{{ $course->id }}"> {{ $course->title_ar }} </option>
                                    @endforeach
                                </select>
                            </div>
                        </form>
                        <form action="{{ url('filterGallery') }}" method="GET" class="about-us-sec2">
                            @csrf
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <select class="arrow_down" id="course_id" name="course">
                                    <option value="" disabled="disabled" selected="selected">اسم الدورة</option>
                                    <option value="all">ALL</option>
                                    <option value="other">other</option>
                                    @foreach($courses as $course)
                                        <option value="{{ $course->id }}"> {{ $course->title_ar }} </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <input type="text" id="course_date" class="form-control arrow_down rtl gallery-calendar" placeholder="يوم/شهر/سنة" name="date" autocomplete="off" readonly style="background-color: #fff !important;">
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <select class="arrow_down" id="location" name="location">
                                    <option value="" disabled="disabled" selected="selected">الموقع</option>
                                    <option value="all">ALL</option>
                                    @foreach($locations as $location)
                                        <option value="{{ $location->id }}"> {{ $location->country_name_ar }} </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-3 col-sm-3 col-xs-12" style="display: flex; flex-direction: row; justify-content: center; align-items: center">
                                <button class="btn btn-block btn-aljhood filter_courses filter_gallery_btn" style="width: 48%">بحث</button>
                                <a href="{{ url('aljhood/gallery') }}" class="btn btn-block btn-aljhood filter_courses filter_gallery_btn" style="width: 48%; margin: 0 5px">حذف</a>
                            </div>
                        </form>
                    </div>
                </div>

                @if(count($gallery) != 0)
                <div class="container blog-section gallery-content">
                    @php
                        $galleryDuration = 1000;
                        $counter = 0 ;
                    @endphp
                    <div class="row">
                    @foreach($gallery as  $gal)
                        <div class="col-lg-3" data-aos="fade-up" data-aos-duration="{{ $galleryDuration + $counter }}" data-aos-easing="ease-in-out" onclick="galleryFunction({{ $gal->id }})" style="cursor: pointer; float: right;">
                            <a href="{{ url('gallery') }}/{{ $gal->id }}">
                                <div class="widget widget-blog" style="height: 300px">
                                    <div class="widget-blog-cover">
                                        <img src="{{ asset('storage/uploads/gallery') }}/{{ $gal->cover_photo }}" alt="no-photo">
                                    </div>
                                    <div class="widget-blog-content">
                                        <h5><a href="{{ url('gallery') }}/{{ $gal->id }}">{{ $gal->title_ar }}</a></h5>
                                        <p><i class="fa fa-map-marker"></i> {{ $gal->location->country_name_ar }}</p>
                                        @if(!empty($gal->id))
                                            <p> <i class="fa fa-calendar"></i> {{ $gal->date }}</p>
                                        @endif
                                    </div>
                                </div>
                            </a>
                        </div>
                        @php
                            $counter = 300;
                            $galleryDuration = $galleryDuration + $counter;
                        @endphp
                    @endforeach
                    </div>

                </div>
                @else
                    <div class="container blog-section gallery-content">
                        <div class="row">
                            <div class="col-lg-12">
                                @if($course_request == 'faked' && $date_request == 'faked' && $location_request == 'faked')
                                    <p class="text-center">يرجى تحديد خيار بحث واحد على الأقل.</p>
                                @else
                                    <p class="text-center">لم يتم العثور على ألبومات متعلقة ببحثك. حاول تحديد خيار بحث آخر.</p>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif

                @if($links == 1)
                    <div style="display: flex; flex-direction: row; justify-content: center;">
                        <div style="text-align: center;">{{ $gallery->links() }}</div>
                    </div>
                @endif
                @if($links == 1)
                    <div class="pt-15" style="display: flex; flex-direction: row; justify-content: center;">
                        <div style="text-align: center;"> {{ $gallery->lastItem() }} من {{ $gallery->total() }}
                            البوم .
                        </div>

                    </div>
                @endif
            </section>
        </div>
    @endif
@stop


@section('scripts')


@stop
