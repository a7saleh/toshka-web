<!------------------------- search page content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.search'))

@section('content')
@if(app()->getLocale() == "en")
<!-- heading banner -->
<header class="heading-banner text-white bgCover"
style="background-image: url({{ url('frontend/images/banners/Not-Found.jpeg') }}); background-position: center;">
	<div class="container holder">
	</div>
</header>
<!-- breadcrumb nav -->
<nav class="breadcrumb-nav">
	<div class="container">
		<!-- breadcrumb -->
		<ol class="breadcrumb">
			<li><a href="{{ url('/') }}">Home</a></li>
			<li class="active">Search Page</li>
		</ol>
	</div>
</nav>

@if(count($news) == 0 && count($courses) == 0)

    <section class="container search-section-no-results" style="margin-top:5%;margin-bottom:5%;">
    	<div class="row">
    		<div class="col-md-12">
    			<p style="text-align:center; font-size: 18px;"> No results found! </p>
    		</div>
    	</div>
    </section>

@endif

@if(count($courses) > 0)
	<section class="container search-section-courses">
		<h2>Courses results:</h2>
		<div class="row">
			@foreach($courses as $course)
			    <div class="col-md-4">
			    	<a href="{{ url('course') }}/{{ $course->id }}&cdefghijklmnopqrstuvw">
				        <div class="widget widget-blog" style="min-height: 368px;">
				            <div class="widget-blog-cover" style="padding-top:0px;">
				                <img src="{{ asset('storage/uploads/courses') }}/{{ $course->image }}" alt="no-photo" style="width: 100% !important;">
				            </div>
				            <div class="widget-blog-content">
				                <h5>{{ $course->title_en }}</h5>
				                <p class="part_contant"> <b>Start Date : </b>  {{ $course->start_date }} </p>
				            </div>
				        </div>
				    </a>
			    </div>
			@endforeach
		</div>
	</section>
@endif

@if(count($news) > 0)
<section class="container search-section-news">
	<h2>News results:</h2>
	<div class="row">
		@foreach($news as $new)
		    <div class="col-md-4">
		    	<a href="{{ url('news') }}/{{ $new['id'] }}&cdefghijklmnopqrstuvw">
			        <div class="widget widget-blog" style="min-height: 368px;">
			            <div class="widget-blog-cover" style="padding-top:0px;">
			                <img src="{{ asset('storage/uploads/news') }}/{{ $new['file'] }}" alt="no-photo" style="width: 100% !important;">
			            </div>
			            <div class="widget-blog-content">
			                <h5>{{ $new['title_en'] }}</h5>
			                <p class="part_contant">

			                	<?php
				                	if(strlen($new['meta_description_en']) > 50) {
				                		echo substr($new['meta_description_en'],0,50).'...';
				                	}else{
				                		echo $new['meta_description_en'];
				                	}
				                ?>
			                </p>
			            </div>
			        </div>
			    </a>
		    </div>
		@endforeach
	</div>
</section>
@endif

@else

    <!-- heading banner -->
    <header class="heading-banner text-white bgCover"
            style="background-image: url({{ url('frontend/images/banners/Not-Found.jpeg') }}); background-position: center;">
        <div class="container holder">
        </div>
    </header>
    <!-- breadcrumb nav -->
    <nav class="breadcrumb-nav rtl">
        <div class="container">
            <!-- breadcrumb -->
            <ol class="breadcrumb">
                <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                <li class="active">البحث</li>
            </ol>
        </div>
    </nav>

    @if(count($news) == 0 && count($courses) == 0)

        <section class="container search-section-no-results" style="margin-top:5%;margin-bottom:5%;">
            <div class="row">
                <div class="col-md-12">
                    <p style="text-align:center; font-size: 18px;"> لا يوجد نتائج للبحث </p>
                </div>
            </div>
        </section>

    @endif

    @if(count($courses) > 0)
        <section class="container search-section-courses rtl">
            <h2>الدورات :</h2>
            <div class="row">
                @foreach($courses as $course)
                    <div class="col-md-4" style="float: right">
                        <a href="{{ url('course') }}/{{$course->id}}">
                            <div class="widget widget-blog" style="min-height: 368px;">
                                <div class="widget-blog-cover" style="padding-top:0px;">
                                    <img src="{{ asset('storage/uploads/courses') }}/{{ $course->image }}" alt="no-photo" style="width: 100% !important;">
                                </div>
                                <div class="widget-blog-content">
                                    <h5>{{ $course->title_ar }}</h5>
                                    <p class="part_contant"> <b>تاريخ الدورة : </b>  {{ $course->start_date }} </p>
                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </section>
    @endif

    @if(count($news) > 0)
        <section class="container search-section-news rtl">
            <h2>الأخبار :</h2>
            <div class="row">
                @foreach($news as $new)
                    <div class="col-md-4" style="float: right">
                        <a href="{{ url('news') }}/{{ $new['id'] }}&cdefghijklmnopqrstuvw">
                            <div class="widget widget-blog" style="min-height: 368px;">
                                <div class="widget-blog-cover" style="padding-top:0px;">
                                    <img src="{{ asset('storage/uploads/news') }}/{{ $new['file'] }}" alt="no-photo" style="width: 100% !important;">
                                </div>
                                <div class="widget-blog-content">
                                    <h5>{{ $new['title_ar'] }}</h5>
                                    <p class="part_contant">

                                        <?php
                                        if(strlen($new['meta_description_ar']) > 50) {
                                            echo substr($new['meta_description_ar'],0,50).'...';
                                        }else{
                                            echo $new['meta_description_ar'];
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </section>
    @endif
@endif
@stop
