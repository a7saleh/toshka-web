<!------------------------- strategies content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.strategies'))

@section('content')

    <?php  
    if(app()->getLocale() == "en"){
        $dir="ltr";
        $order="asc";
    }else{
        $dir="rtl";  
        $order="desc";

    }
    
    
    ?>
    
<!-- heading banner -->
<?php
 $banner=DB::table('page_contents')->where('ref_page','=','strategy_banner')->first();
 $strategy_values_title=DB::table('page_contents')->where('ref_page','=','strategy_values_title')->first();
 $values = DB::table('page_contents')->where('ref_page' , 'values')->get();

$Title_Name='title_'.app()->getLocale();
$Title='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
?>
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav {{$dir}}">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">{{ trans('messages.home')}}</a></li>
                <li class="active">{{ trans('messages.strategy')}}</li>
                </ol>
            </div>
        </nav>
        <!-- text info block -->
        <?php
         $contents=DB::table('page_contents')->where('ref_page','=','strategy')->orderBy('id',$order)->get();
         $Title="title_".app()->getLocale();
         $Description="description_".app()->getLocale();

        ?>
        
        
      <section id="values" class="values mb-5 mt-5">
      <div class="container" data-aos="fade-up">
@foreach($contents as $key => $content)
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
                  
                 <div class="col-lg-10" data-aos="fade-up" data-aos-delay="200">
            <div class="box" style="border:3px solid #be9f56;">
                
              <h2 class="gold-color">@php echo $content->$Title; @endphp</h2>
              <p><strong>@php echo $content->$Description; @endphp</strong></p> 
              
    @if(!empty($content->image) || !empty($content->video))
                
    @if(!empty($content->image))
        <img  src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" class="element-block image"  alt="no-photo" style="width:100%;">
    @else
        <iframe  src="{{ $content->video }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    @endif 
    @endif


            </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
          </div>
@endforeach          
      </div>
    </section><br><br>
   
          <section class="container how-work-block text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
            <header class="seperator-head">
                <h2>{{$strategy_values_title->$Title}}</h2>
            </header>
            <!-- steps guide holder -->
            <div class="row">
            <div class="steps-guide-holder slider values-slider">
@foreach($values as $value)                
                
                    <div class="col-xs-4 col-sm-4 col-md-4">
                        <!-- guide column -->
                        <div class="guide-column text-center">
                            <img src="{{ asset('storage/uploads/page-contents') }}/{{ $value->image }}" alt="" style="width:100%;" class="img-responsive"><br>
                            <h3 class="fw-normal">{{$value->$Title}}</h3>
                        </div>
                    </div>
@endforeach                   
            </div>
            </div>
        </section>

@stop
