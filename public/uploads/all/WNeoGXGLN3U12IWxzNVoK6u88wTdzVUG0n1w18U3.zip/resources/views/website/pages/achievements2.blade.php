<!------------------------- achievements content -------------------------->

@extends('website.layout.master')


@section('title', trans('messages.achievements'))

@section('content')

<?php
$banner=DB::table('page_contents')->where('ref_page','=','achivment_banner')->first();
$Title_Name='title_'.app()->getLocale();
$Description_Name='description_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
?>


        <header class="heading-banner text-black bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        
        
     @if(app()->getLocale()=="ar")
     <div class="container section_about text-right rtl">

                <nav class="breadcrumb-nav gall-bread">
                    <div class="container">
                        <!-- breadcrumb -->
                        <ol class="breadcrumb">
                        <li><a href="{{ url('/') }}">الرئيسية</a></li>
                            <li class="active"> إنطلاقة الجهود</li>
                        </ol>
                    </div>
                </nav>
@else
<div class="container section_about text-center">

        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">@lang('Home')</a></li>
                    <li class="active">Achievements</li>
                </ol>
            </div>
        </nav>
@endif        

</div>        
        
        
        

    <section id="values" class="values mb-5 mt-5">
      <div class="container" data-aos="fade-up">
@foreach($contents as $key => $content)
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
                  
                 <div class="col-lg-10" data-aos="fade-up" data-aos-delay="200">
            <div class="box" style="border:3px solid #be9f56;">
                
    <!--<div style="border:4px solid ##be9f56;"></div>-->
              <h2 class="gold-color">@php echo $content->$Title_Name; @endphp</h2>
              <p><strong>@php echo $content->$Description_Name; @endphp</strong></p>
              
    @if(!empty($content->image) || !empty($content->video))
                
    @if(!empty($content->image))
        <img  src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" class="element-block image"  alt="no-photo">
    @else
        <iframe  src="{{ $content->video }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    @endif 
    @endif
            </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
          </div>
@endforeach          
      </div>
    </section><br><br>
    
    
@stop
