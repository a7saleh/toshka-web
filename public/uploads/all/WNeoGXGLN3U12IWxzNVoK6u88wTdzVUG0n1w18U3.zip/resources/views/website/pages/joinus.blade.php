<!------------------------- join us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.joinus'))

@section('content')

<?php $banner=DB::table('page_contents')->where('ref_page','=','join-us_banner')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
$values = DB::table('page_contents')->where('ref_page' , 'join_us_sections')->get();
$Title='title_'.app()->getLocale();

$join_form_title=DB::table('page_contents')->where('ref_page','=','join_form_title')->first();


?>

    @if(app()->getLocale() == "en")
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">Join Us</li>
                </ol>
            </div>
        </nav>

        <!-- join block -->
        <section class="contact-block">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2> @php echo $content[0]->title_en; @endphp </h2>
                    <p> @php echo $content[0]->description_en; @endphp </p>
                </header>
                <!-- contact form -->
                <div class="row" style="display: flex; flex-direction: row; justify-content: center;">
                    <div class="col-lg-6">
                        <div class="row" style="box-shadow:1px 1px 5px grey;padding: 20px;">
                            <form id="joinForm" class="contact-form" action="javascript:void(0)" enctype="multipart/form-data">
                                @csrf
                                <label for="name" class="col-lg-4">Name :</label>
                                <div class="form-group col-md-4 col-sm-4">
                                    <input name="report_type" type="text" class="form-control element-block" value="join" style="display: none">
                                    <input id="first_name" name="first_name" type="text" class="form-control element-block" placeholder="First Name*"
                                           required="required">
                                </div>
                                <div class="form-group col-md-4 col-sm-4">
                                    <input id="last_name" name="last_name" type="text" class="form-control element-block" placeholder="Last Name*"
                                           required="required">
                                </div>
                                <label for="area_code" class="col-lg-4">Phone Num :</label>
                                <div class="form-group col-md-3 col-sm-3">
                                    <input id="area_code" name="area_code" type="text" class="form-control element-block" placeholder="Area Code*"
                                           required="required">
                                </div>
                                <div class="form-group col-md-5 col-sm-5">
                                    <input id="number" name="number" type="text" class="form-control element-block" placeholder="You Mobile Number*"
                                           required="required">
                                </div>
                                <label for="email" class="col-lg-4">Email :</label>
                                <div class="form-group col-md-8 col-sm-8">
                                    <input id="email" name="email" type="email" class="form-control element-block" placeholder="example@email.com*" required="required">
                                </div>
                                <label for="department" class="col-lg-4">Department :</label>
                                <div class="form-group col-md-8 col-sm-8">
                                    <select id="department" name="department" style="width:100%;" class="element-block arrow_down">
                                        <option selected="selected"> Select Department*</option>
                                        @foreach($values as $value)        
                                        <option value="{{$value->$Title}}">{{$value->$Title}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <label for="resume" class="col-lg-4">Upload Resume :</label>
                                <div class="form-group file-input-1 col-md-8 col-sm-8">
                                    <input id="resume" name="resume" type="file" required="required"
                                           class="form-control element-block">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container join-us-countries text-center">
            <div class="row">
                <div class="col-md-12">
                    <img src="{{ asset('frontend/images/countries') }}/countries.png">
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center become-trainer">
                    <h2>To become a trainer</h2>
                    <a href="{{ url('/aljhood/instructor-form') }}" class="btn btn-theme btn-warning" target="_blank"> click here</a>
                </div>
            </div>
        </section>
        <br><br>

        <div class="modal fade bd-example-modal-lg" id="joinFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/join-us-en.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">Check our privacy policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
        <!-- heading banner -->
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">لصفحة الرئيسية</a></li>
                    <li class="active">انضم لنا</li>
                </ol>
            </div>
        </nav>

        <!-- join block -->
        <section class="contact-block rtl">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2> @php echo $content[0]->title_ar; @endphp </h2>
                    <p> @php echo $content[0]->description_ar; @endphp </p>
                </header>
                <!-- contact form -->
                <div class="row" style="display: flex; flex-direction: row; justify-content: center;">
                    <div class="col-lg-6">
                        <div class="row" style="box-shadow:1px 1px 5px grey;padding: 20px;">
                            <form id="joinForm" class="contact-form join-form-ar-no-pad" action="javascript:void(0)" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <div class="form-group col-lg-12">
                                        <label for="name" class="form-group col-lg-2 col-md-2 col-sm-2 col-xs-12" style="margin-bottom: 0 ; float: right">الاسم :</label>
                                        <div class="form-group col-lg-5 col-md-5 col-sm-5 col-xs-12" style="float: right">
                                            <input id="first_name" name="first_name" type="text" class="form-control element-block" placeholder="الاسم الاول*"
                                                   required="required">
                                        </div>
                                        <input name="report_type" type="text" class="form-control element-block" value="join" style="display: none">
                                        <div class="form-group col-lg-5 col-md-5 col-sm-5 col-xs-12" style="float: right">
                                            <input id="last_name" name="last_name" type="text" class="form-control element-block" placeholder="الاسم الاخير*"
                                                   required="required">
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-12">
                                        <label for="area_code" class="col-lg-2 col-md-2 col-sm-2 col-xs-12" style="padding: 0 15px; float: right">رقم الهاتف :</label>
                                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-4" style="float: right">
                                            <input id="area_code" name="area_code" type="text" class="form-control element-block" placeholder="رمز المنطقة*"
                                                   required="required">
                                        </div>
                                        <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-8" style="float: right">
                                            <input id="number" name="number" type="text" class="form-control element-block" placeholder="رقم الهاتف*"
                                                   required="required">
                                        </div>
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <label for="email" class="col-lg-2 col-md-2 col-sm-2 col-xs-12" style="padding: 0 15px; float: right">البريد الالكتروني :</label>
                                        <div class="form-group col-lg-10 col-md-10 col-sm-10 col-xs-12" style="float: right">
                                            <input id="email" name="email" type="email" class="form-control element-block" placeholder="البريد الالكتروني*" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <label for="department" class="col-lg-2 col-md-2 col-sm-2 col-xs-12" style="padding: 0 15px; float: right">القسم :</label>
                                        <div class="form-group col-lg-10 col-md-10 col-sm-10 col-xs-12" style="float: right">
                                            <select id="department" name="department" style="width:100%;" class="element-block arrow_down" required="required">
                                                <option selected="selected"> اخر القسم*</option>
                                        @foreach($values as $value)        
                                        <option value="{{$value->$Title}}">{{$value->$Title}}</option>
                                        @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-12">
                                        <label for="resume" class="col-lg-2" style="padding: 0 15px; float: right">السيرة الذاتية :</label>
                                        <div class="form-group file-input-1 col-md-10 col-sm-10" style="float: right">
                                            <input id="resume" name="resume" type="file"
                                                   class="form-control element-block">
                                        </div>
                                    </div>

                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">
                                        ارسال
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="container join-us-countries text-center rtl">
            <div class="row">
                <div class="col-md-12">
                    <img src="{{ asset('frontend/images/countries') }}/countries.png">
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center become-trainer">
                    <h2>انضم لنا</h2>
                    <a href="{{ url('/aljhood/instructor-form') }}" class="btn btn-theme btn-warning" target="_blank" style="font-size: 18px"> انقر هنا</a>
                </div>
            </div>
        </section>
        <br><br>

        <div class="modal fade bd-example-modal-lg" id="joinFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/join-us-ar.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">تحقق من سياسة الخصوصية</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif

@stop

@section('scripts')
    <script>

        $('#joinForm').submit(function (){

            var resume = $('input[type=file]')[0].files[0];
            var formData = new FormData();
            var url = $('meta[name=base_url]').attr("content");
            var csrf_token = $('meta[name=csrf_token]').attr("content");
            formData.append("report_type", "join");
            formData.append("resume" , resume);
            formData.append("first_name", $('#first_name').val());
            formData.append("last_name", $('#last_name').val());
            formData.append("area_code", $('#area_code').val());
            formData.append("number", $('#number').val());
            formData.append("email", $('#email').val());
            formData.append("department", $('#department').val());
            formData.append("_token", csrf_token);
            console.log(formData);

            $.ajax({
                url: url+'/joinForm',
                type: 'post',
                data: formData,
                cache : false,
                processData: false,
                contentType: false,
                success: function(){
                    console.log('Yes');
                    $('#joinFormModal').modal('show');
                    $("#joinForm")[0].reset();
                },
                error: function (){
                    console.log('error');
                }
            });
        })

    </script>
@stop
