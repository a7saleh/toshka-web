<!------------------------- join us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.apply'))

@section('content')
<?php
$Title="title_".app()->getLocale();
$apply_course_desc1=DB::table('page_contents')->where('ref_page','apply_course_desc1')->first();
$apply_course_desc2=DB::table('page_contents')->where('ref_page','apply_course_desc2')->first();
$welcome_to_aljhood_course_page=DB::table('page_contents')->where('ref_page','welcome_to_aljhood_course_page')->first()??"welcome_to_aljhood_course_page";

?>
    @if(app()->getLocale() == "en")
        <!-- join block -->
        <section class="contact-block apply-course" style="margin-top: 90px">
            <div class="container">
                <header class="popular-posts-head">
                    
                    <h2 class="popular-head-heading" style="color: #2f2f2f">{{$welcome_to_aljhood_course_page->title_en}}</h2>
                </header>
                <!-- contact form -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="application-info" style="max-width: 75%; margin: 0 0 30px 0">
                            <div class="">
                                <h3> {{$apply_course_desc1->$Title}} </h3>
                            </div>
                            <div class="">
                                <h5>@php echo $apply_course_desc2->$Title @endphp</h5>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row" style="box-shadow:1px 1px 5px grey;padding: 20px;">
                            @if(Session::has('success'))
                                <div class="alert alert-success">
                                    <h4>{{Session::get('success')}}</h4>
                                </div>
                           
                            @endif
                            <div class="apply-course-form-head text-center" style="padding: 0 0 10px 10px">
                                <h4>{{ $course[0]->title_en }}</h4>
                            </div>
                            <form onsubmit="mySubmitFunction()" action="{{ url('applyCourse') }}" method="post" class="contact-form apply-course-form" id="applyCourseForm" enctype="multipart/form-data">
                                @csrf
                                <input type="text" id="course_id" name="course_id" value="{{ $course[0]->id }}" style="display: none">
                                <label for="full_name" class="col-lg-12">Name :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="name" id="name" type="text" class="form-control element-block" placeholder="Name*"
                                           required="required">
                                </div>
                                <label for="email" class="col-lg-12">Email :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="email" id="email" type="email" class="form-control element-block" placeholder="Email*" required="required">
                                </div>
                                <label for="number" class="col-lg-12">Mobile Number :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="number" id="number" type="tel" class="form-control element-block" placeholder="You Mobile Number*"
                                           required="required">
                                </div>
                                <label for="departement" class="col-lg-12">Country :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <select  name="country" id="country" style="width:100%;" class=" form-control element-block arrow_down" required="required">
                                        <option selected="selected"> Select Country*</option>
                                        <option value="Afghanistan">Afghanistan</option>
                                        <option value="Aland Islands">Aland Islands</option>
                                        <option value="Albania">Albania</option>
                                        <option value="Algeria">Algeria</option>
                                        <option value="American Samoa">American Samoa</option>
                                        <option value="Andorra">Andorra</option>
                                        <option value="Angola">Angola</option>
                                        <option value="Anguilla">Anguilla</option>
                                        <option value="Antarctica">Antarctica</option>
                                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                        <option value="Argentina">Argentina</option>
                                        <option value="Armenia">Armenia</option>
                                        <option value="Aruba">Aruba</option>
                                        <option value="Australia">Australia</option>
                                        <option value="Austria">Austria</option>
                                        <option value="Azerbaijan">Azerbaijan</option>
                                        <option value="Bahamas">Bahamas</option>
                                        <option value="Bahrain">Bahrain</option>
                                        <option value="Bangladesh">Bangladesh</option>
                                        <option value="Barbados">Barbados</option>
                                        <option value="Belarus">Belarus</option>
                                        <option value="Belgium">Belgium</option>
                                        <option value="Belize">Belize</option>
                                        <option value="Benin">Benin</option>
                                        <option value="Bermuda">Bermuda</option>
                                        <option value="Bhutan">Bhutan</option>
                                        <option value="Bolivia">Bolivia</option>
                                        <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                        <option value="Botswana">Botswana</option>
                                        <option value="Bouvet Island">Bouvet Island</option>
                                        <option value="Brazil">Brazil</option>
                                        <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                        <option value="Brunei Darussalam">Brunei Darussalam</option>
                                        <option value="Bulgaria">Bulgaria</option>
                                        <option value="Burkina Faso">Burkina Faso</option>
                                        <option value="Burundi">Burundi</option>
                                        <option value="Cambodia">Cambodia</option>
                                        <option value="Cameroon">Cameroon</option>
                                        <option value="Canada">Canada</option>
                                        <option value="Cape Verde">Cape Verde</option>
                                        <option value="Cayman Islands">Cayman Islands</option>
                                        <option value="Central African Republic">Central African Republic</option>
                                        <option value="Chad">Chad</option>
                                        <option value="Chile">Chile</option>
                                        <option value="China">China</option>
                                        <option value="Christmas Island">Christmas Island</option>
                                        <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                        <option value="Colombia">Colombia</option>
                                        <option value="Comoros">Comoros</option>
                                        <option value="Congo">Congo</option>
                                        <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                                        <option value="Cook Islands">Cook Islands</option>
                                        <option value="Costa Rica">Costa Rica</option>
                                        <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                                        <option value="Croatia">Croatia</option>
                                        <option value="Cuba">Cuba</option>
                                        <option value="Curacao">Curacao</option>
                                        <option value="Cyprus">Cyprus</option>
                                        <option value="Czech Republic">Czech Republic</option>
                                        <option value="Denmark">Denmark</option>
                                        <option value="Djibouti">Djibouti</option>
                                        <option value="Dominica">Dominica</option>
                                        <option value="Dominican Republic">Dominican Republic</option>
                                        <option value="Ecuador">Ecuador</option>
                                        <option value="Egypt">Egypt</option>
                                        <option value="El Salvador">El Salvador</option>
                                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                                        <option value="Eritrea">Eritrea</option>
                                        <option value="Estonia">Estonia</option>
                                        <option value="Ethiopia">Ethiopia</option>
                                        <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                        <option value="Faroe Islands">Faroe Islands</option>
                                        <option value="Fiji">Fiji</option>
                                        <option value="Finland">Finland</option>
                                        <option value="France">France</option>
                                        <option value="French Guiana">French Guiana</option>
                                        <option value="French Polynesia">French Polynesia</option>
                                        <option value="French Southern Territories">French Southern Territories</option>
                                        <option value="Gabon">Gabon</option>
                                        <option value="Gambia">Gambia</option>
                                        <option value="Georgia">Georgia</option>
                                        <option value="Germany">Germany</option>
                                        <option value="Ghana">Ghana</option>
                                        <option value="Gibraltar">Gibraltar</option>
                                        <option value="Greece">Greece</option>
                                        <option value="Greenland">Greenland</option>
                                        <option value="Grenada">Grenada</option>
                                        <option value="Guadeloupe">Guadeloupe</option>
                                        <option value="Guam">Guam</option>
                                        <option value="Guatemala">Guatemala</option>
                                        <option value="Guernsey">Guernsey</option>
                                        <option value="Guinea">Guinea</option>
                                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                                        <option value="Guyana">Guyana</option>
                                        <option value="Haiti">Haiti</option>
                                        <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                        <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                        <option value="Honduras">Honduras</option>
                                        <option value="Hong Kong">Hong Kong</option>
                                        <option value="Hungary">Hungary</option>
                                        <option value="Iceland">Iceland</option>
                                        <option value="India">India</option>
                                        <option value="Indonesia">Indonesia</option>
                                        <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                        <option value="Iraq">Iraq</option>
                                        <option value="Ireland">Ireland</option>
                                        <option value="Isle of Man">Isle of Man</option>
                                        <option value="Israel">Israel</option>
                                        <option value="Italy">Italy</option>
                                        <option value="Jamaica">Jamaica</option>
                                        <option value="Japan">Japan</option>
                                        <option value="Jersey">Jersey</option>
                                        <option value="Jordan">Jordan</option>
                                        <option value="Kazakhstan">Kazakhstan</option>
                                        <option value="Kenya">Kenya</option>
                                        <option value="Kiribati">Kiribati</option>
                                        <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                        <option value="Korea, Republic of">Korea, Republic of</option>
                                        <option value="Kosovo">Kosovo</option>
                                        <option value="Kuwait">Kuwait</option>
                                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                                        <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                        <option value="Latvia">Latvia</option>
                                        <option value="Lebanon">Lebanon</option>
                                        <option value="Lesotho">Lesotho</option>
                                        <option value="Liberia">Liberia</option>
                                        <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                        <option value="Liechtenstein">Liechtenstein</option>
                                        <option value="Lithuania">Lithuania</option>
                                        <option value="Luxembourg">Luxembourg</option>
                                        <option value="Macao">Macao</option>
                                        <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                                        <option value="Madagascar">Madagascar</option>
                                        <option value="Malawi">Malawi</option>
                                        <option value="Malaysia">Malaysia</option>
                                        <option value="Maldives">Maldives</option>
                                        <option value="Mali">Mali</option>
                                        <option value="Malta">Malta</option>
                                        <option value="Marshall Islands">Marshall Islands</option>
                                        <option value="Martinique">Martinique</option>
                                        <option value="Mauritania">Mauritania</option>
                                        <option value="Mauritius">Mauritius</option>
                                        <option value="Mayotte">Mayotte</option>
                                        <option value="Mexico">Mexico</option>
                                        <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                        <option value="Moldova, Republic of">Moldova, Republic of</option>
                                        <option value="Monaco">Monaco</option>
                                        <option value="Mongolia">Mongolia</option>
                                        <option value="Montenegro">Montenegro</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Morocco">Morocco</option>
                                        <option value="Mozambique">Mozambique</option>
                                        <option value="Myanmar">Myanmar</option>
                                        <option value="Namibia">Namibia</option>
                                        <option value="Nauru">Nauru</option>
                                        <option value="Nepal">Nepal</option>
                                        <option value="Netherlands">Netherlands</option>
                                        <option value="Netherlands Antilles">Netherlands Antilles</option>
                                        <option value="New Caledonia">New Caledonia</option>
                                        <option value="New Zealand">New Zealand</option>
                                        <option value="Nicaragua">Nicaragua</option>
                                        <option value="Niger">Niger</option>
                                        <option value="Nigeria">Nigeria</option>
                                        <option value="Niue">Niue</option>
                                        <option value="Norfolk Island">Norfolk Island</option>
                                        <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                        <option value="Norway">Norway</option>
                                        <option value="Oman">Oman</option>
                                        <option value="Pakistan">Pakistan</option>
                                        <option value="Palau">Palau</option>
                                        <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                        <option value="Panama">Panama</option>
                                        <option value="Papua New Guinea">Papua New Guinea</option>
                                        <option value="Paraguay">Paraguay</option>
                                        <option value="Peru">Peru</option>
                                        <option value="Philippines">Philippines</option>
                                        <option value="Pitcairn">Pitcairn</option>
                                        <option value="Poland">Poland</option>
                                        <option value="Portugal">Portugal</option>
                                        <option value="Puerto Rico">Puerto Rico</option>
                                        <option value="Qatar">Qatar</option>
                                        <option value="Reunion">Reunion</option>
                                        <option value="Romania">Romania</option>
                                        <option value="Russian Federation">Russian Federation</option>
                                        <option value="Rwanda">Rwanda</option>
                                        <option value="Saint Barthelemy">Saint Barthelemy</option>
                                        <option value="Saint Helena">Saint Helena</option>
                                        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                        <option value="Saint Lucia">Saint Lucia</option>
                                        <option value="Saint Martin">Saint Martin</option>
                                        <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                        <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                        <option value="Samoa">Samoa</option>
                                        <option value="San Marino">San Marino</option>
                                        <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                        <option value="Saudi Arabia">Saudi Arabia</option>
                                        <option value="Senegal">Senegal</option>
                                        <option value="Serbia">Serbia</option>
                                        <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                                        <option value="Seychelles">Seychelles</option>
                                        <option value="Sierra Leone">Sierra Leone</option>
                                        <option value="Singapore">Singapore</option>
                                        <option value="Sint Maarten">Sint Maarten</option>
                                        <option value="Slovakia">Slovakia</option>
                                        <option value="Slovenia">Slovenia</option>
                                        <option value="Solomon Islands">Solomon Islands</option>
                                        <option value="Somalia">Somalia</option>
                                        <option value="South Africa">South Africa</option>
                                        <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                        <option value="South Sudan">South Sudan</option>
                                        <option value="Spain">Spain</option>
                                        <option value="Sri Lanka">Sri Lanka</option>
                                        <option value="Sudan">Sudan</option>
                                        <option value="Suriname">Suriname</option>
                                        <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                        <option value="Swaziland">Swaziland</option>
                                        <option value="Sweden">Sweden</option>
                                        <option value="Switzerland">Switzerland</option>
                                        <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                        <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                        <option value="Tajikistan">Tajikistan</option>
                                        <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                        <option value="Thailand">Thailand</option>
                                        <option value="Timor-Leste">Timor-Leste</option>
                                        <option value="Togo">Togo</option>
                                        <option value="Tokelau">Tokelau</option>
                                        <option value="Tonga">Tonga</option>
                                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                        <option value="Tunisia">Tunisia</option>
                                        <option value="Turkey">Turkey</option>
                                        <option value="Turkmenistan">Turkmenistan</option>
                                        <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                        <option value="Tuvalu">Tuvalu</option>
                                        <option value="Uganda">Uganda</option>
                                        <option value="Ukraine">Ukraine</option>
                                        <option value="United Arab Emirates">United Arab Emirates</option>
                                        <option value="United Kingdom">United Kingdom</option>
                                        <option value="United States">United States</option>
                                        <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                        <option value="Uruguay">Uruguay</option>
                                        <option value="Uzbekistan">Uzbekistan</option>
                                        <option value="Vanuatu">Vanuatu</option>
                                        <option value="Venezuela">Venezuela</option>
                                        <option value="Viet Nam">Viet Nam</option>
                                        <option value="Virgin Islands, British">Virgin Islands, British</option>
                                        <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                                        <option value="Wallis and Futuna">Wallis and Futuna</option>
                                        <option value="Western Sahara">Western Sahara</option>
                                        <option value="Yemen">Yemen</option>
                                        <option value="Zambia">Zambia</option>
                                        <option value="Zimbabwe">Zimbabwe</option>
                                    </select>
                                </div>
                                <label for="company" class="col-lg-12">Company Name :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="company" id="company" type="text" class="form-control element-block" placeholder="Company*"
                                           required="required">
                                </div>
                                <label for="job_title" class="col-lg-12">Position :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="job_title" id="job_title" type="text" class="form-control element-block" placeholder="Job Title*"
                                           required="required">
                                </div>

                                <input type="text" style="display: none" value="{{ $course[0]->id }}">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <br><br>
        <div class="modal fade bd-example-modal-lg" id="applyCourseFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/Suggest-course-en.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">Check our privacy policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
    
        <!-- join block -->
        <section class="contact-block apply-course rtl" style="margin-top: 90px">
            <div class="container">
                <header class="popular-posts-head">
            
                </header>

                <!-- contact form -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row" style="box-shadow:1px 1px 5px grey;padding: 20px;">
                            @if(Session::has('success'))
                                <div class="alert alert-success">
                                    <h4>{{Session::get('success')}}</h4>
                                </div>
                             
                            @endif
                            <div class="apply-course-form-head text-center" style="padding: 0 0 10px 10px">
                                <h4>{{ $course[0]->title_ar }}</h4>
                            </div>
                            <form onsubmit="mySubmitFunction()" action="{{ url('applyCourse') }}" method="post" class="contact-form apply-course-form" id="applyCourseForm" enctype="multipart/form-data">
                                @csrf
                                <input type="text" id="course_id" name="course_id" value="{{ $course[0]->id }}" style="display: none">
                                <label for="full_name" class="col-lg-12">الإسم (عربي) :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="name" id="name" type="text" class="form-control element-block"                                     <input name="en_name" id="en_name" type="text" class="form-control element-block" placeholder="  الاسم الثلاثي"
                                           required="required">
                                </div>
                                <label for="full_name" class="col-lg-12">الإسم (انجليزي) :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="name_en" id="name_en" type="text" class="form-control element-block" placeholder="  الاسم الثلاثي"
                                           required="required">
                                </div>
                                <label for="email" class="col-lg-12">البريد الالكتروني :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="email" id="email" type="email" class="form-control element-block" placeholder="البريد الألكتروني" required="required">
                                </div>
                               <div class="form-group col-md-12 col-sm-12">
                                    <select name="country" id="country" style="width:100%;" class="element-block arrow_down form-control" required="required">
                                        <option selected="selected"> اختر البلد*</option>
                                        <option value="AW">آروبا</option>
	<option value="AZ">أذربيجان</option>
	<option value="AM">أرمينيا</option>
	<option value="ES">أسبانيا</option>
	<option value="AU">أستراليا</option>
	<option value="AF">أفغانستان</option>
	<option value="AL">ألبانيا</option>
	<option value="DE">ألمانيا</option>
	<option value="AG">أنتيجوا وبربودا</option>
	<option value="AO">أنجولا</option>
	<option value="AI">أنجويلا</option>
	<option value="AD">أندورا</option>
	<option value="UY">أورجواي</option>
	<option value="UZ">أوزبكستان</option>
	<option value="UG">أوغندا</option>
	<option value="UA">أوكرانيا</option>
	<option value="IE">أيرلندا</option>
	<option value="IS">أيسلندا</option>
	<option value="ET">اثيوبيا</option>
	<option value="ER">اريتريا</option>
	<option value="EE">استونيا</option>
	<option value="AR">الأرجنتين</option>
	<option value="JO">الأردن</option>
	<option value="EC">الاكوادور</option>
	<option value="AE">الامارات العربية المتحدة</option>
	<option value="BS">الباهاما</option>
	<option value="BH">البحرين</option>
	<option value="BR">البرازيل</option>
	<option value="PT">البرتغال</option>
	<option value="PS">فلسطين</option>
	<option value="BA">البوسنة والهرسك</option>
	<option value="GA">الجابون</option>
	<option value="ME">الجبل الأسود</option>
	<option value="DZ">الجزائر</option>
	<option value="DK">الدانمرك</option>
	<option value="CV">الرأس الأخضر</option>
	<option value="SV">السلفادور</option>
	<option value="SN">السنغال</option>
	<option value="SD">السودان</option>
	<option value="SE">السويد</option>
	<option value="EH">الصحراء الغربية</option>
	<option value="SO">الصومال</option>
	<option value="CN">الصين</option>
	<option value="IQ">العراق</option>
	<option value="VA">الفاتيكان</option>
	<option value="PH">الفيلبين</option>
	<option value="AQ">القطب الجنوبي</option>
	<option value="CM">الكاميرون</option>
	<option value="CG">الكونغو - برازافيل</option>
	<option value="KW">الكويت</option>
	<option value="HU">المجر</option>
	<option value="IO">المحيط الهندي البريطاني</option>
	<option value="MA">المغرب</option>
	<option value="TF">المقاطعات الجنوبية الفرنسية</option>
	<option value="MX">المكسيك</option>
	<option value="SA">المملكة العربية السعودية</option>
	<option value="GB">المملكة المتحدة</option>
	<option value="NO">النرويج</option>
	<option value="AT">النمسا</option>
	<option value="NE">النيجر</option>
	<option value="IN">الهند</option>
	<option value="US">الولايات المتحدة الأمريكية</option>
	<option value="JP">اليابان</option>
	<option value="YE">اليمن</option>
	<option value="GR">اليونان</option>
	<option value="ID">اندونيسيا</option>
	<option value="IR">ايران</option>
	<option value="IT">ايطاليا</option>
	<option value="PG">بابوا غينيا الجديدة</option>
	<option value="PY">باراجواي</option>
	<option value="PK">باكستان</option>
	<option value="PW">بالاو</option>
	<option value="BW">بتسوانا</option>
	<option value="PN">بتكايرن</option>
	<option value="BB">بربادوس</option>
	<option value="BM">برمودا</option>
	<option value="BN">بروناي</option>
	<option value="BE">بلجيكا</option>
	<option value="BG">بلغاريا</option>
	<option value="BZ">بليز</option>
	<option value="BD">بنجلاديش</option>
	<option value="PA">بنما</option>
	<option value="BJ">بنين</option>
	<option value="BT">بوتان</option>
	<option value="PR">بورتوريكو</option>
	<option value="BF">بوركينا فاسو</option>
	<option value="BI">بوروندي</option>
	<option value="PL">بولندا</option>
	<option value="BO">بوليفيا</option>
	<option value="PF">بولينيزيا الفرنسية</option>
	<option value="PE">بيرو</option>
	<option value="TZ">تانزانيا</option>
	<option value="TH">تايلند</option>
	<option value="TW">تايوان</option>
	<option value="TM">تركمانستان</option>
	<option value="TR">تركيا</option>
	<option value="TT">ترينيداد وتوباغو</option>
	<option value="TD">تشاد</option>
	<option value="TG">توجو</option>
	<option value="TV">توفالو</option>
	<option value="TK">توكيلو</option>
	<option value="TO">تونجا</option>
	<option value="TN">تونس</option>
	<option value="TL">تيمور الشرقية</option>
	<option value="JM">جامايكا</option>
	<option value="GI">جبل طارق</option>
	<option value="GD">جرينادا</option>
	<option value="GL">جرينلاند</option>
	<option value="AX">جزر أولان</option>
	<option value="AN">جزر الأنتيل الهولندية</option>
	<option value="TC">جزر الترك وجايكوس</option>
	<option value="KM">جزر القمر</option>
	<option value="KY">جزر الكايمن</option>
	<option value="MH">جزر المارشال</option>
	<option value="MV">جزر الملديف</option>
	<option value="UM">جزر الولايات المتحدة البعيدة الصغيرة</option>
	<option value="SB">جزر سليمان</option>
	<option value="FO">جزر فارو</option>
	<option value="VI">جزر فرجين الأمريكية</option>
	<option value="VG">جزر فرجين البريطانية</option>
	<option value="FK">جزر فوكلاند</option>
	<option value="CK">جزر كوك</option>
	<option value="CC">جزر كوكوس</option>
	<option value="MP">جزر ماريانا الشمالية</option>
	<option value="WF">جزر والس وفوتونا</option>
	<option value="CX">جزيرة الكريسماس</option>
	<option value="BV">جزيرة بوفيه</option>
	<option value="IM">جزيرة مان</option>
	<option value="NF">جزيرة نورفوك</option>
	<option value="HM">جزيرة هيرد وماكدونالد</option>
	<option value="CF">جمهورية افريقيا الوسطى</option>
	<option value="CZ">جمهورية التشيك</option>
	<option value="DO">جمهورية الدومينيك</option>
	<option value="CD">جمهورية الكونغو الديمقراطية</option>
	<option value="ZA">جمهورية جنوب افريقيا</option>
	<option value="GT">جواتيمالا</option>
	<option value="GP">جوادلوب</option>
	<option value="GU">جوام</option>
	<option value="GE">جورجيا</option>
	<option value="GS">جورجيا الجنوبية وجزر ساندويتش الجنوبية</option>
	<option value="DJ">جيبوتي</option>
	<option value="JE">جيرسي</option>
	<option value="DM">دومينيكا</option>
	<option value="RW">رواندا</option>
	<option value="RU">روسيا</option>
	<option value="BY">روسيا البيضاء</option>
	<option value="RO">رومانيا</option>
	<option value="RE">روينيون</option>
	<option value="ZM">زامبيا</option>
	<option value="ZW">زيمبابوي</option>
	<option value="CI">ساحل العاج</option>
	<option value="WS">ساموا</option>
	<option value="AS">ساموا الأمريكية</option>
	<option value="SM">سان مارينو</option>
	<option value="PM">سانت بيير وميكولون</option>
	<option value="VC">سانت فنسنت وغرنادين</option>
	<option value="KN">سانت كيتس ونيفيس</option>
	<option value="LC">سانت لوسيا</option>
	<option value="MF">سانت مارتين</option>
	<option value="SH">سانت هيلنا</option>
	<option value="ST">ساو تومي وبرينسيبي</option>
	<option value="LK">سريلانكا</option>
	<option value="SJ">سفالبارد وجان مايان</option>
	<option value="SK">سلوفاكيا</option>
	<option value="SI">سلوفينيا</option>
	<option value="SG">سنغافورة</option>
	<option value="SZ">سوازيلاند</option>
	<option value="SY">سوريا</option>
	<option value="SR">سورينام</option>
	<option value="CH">سويسرا</option>
	<option value="SL">سيراليون</option>
	<option value="SC">سيشل</option>
	<option value="CL">شيلي</option>
	<option value="RS">صربيا</option>
	<option value="CS">صربيا والجبل الأسود</option>
	<option value="TJ">طاجكستان</option>
	<option value="OM">عمان</option>
	<option value="GM">غامبيا</option>
	<option value="GH">غانا</option>
	<option value="GF">غويانا</option>
	<option value="GY">غيانا</option>
	<option value="GN">غينيا</option>
	<option value="GQ">غينيا الاستوائية</option>
	<option value="GW">غينيا بيساو</option>
	<option value="VU">فانواتو</option>
	<option value="FR">فرنسا</option>
	<option value="PS">فلسطين</option>
	<option value="VE">فنزويلا</option>
	<option value="FI">فنلندا</option>
	<option value="VN">فيتنام</option>
	<option value="FJ">فيجي</option>
	<option value="CY">قبرص</option>
	<option value="KG">قرغيزستان</option>
	<option value="QA">قطر</option>
	<option value="KZ">كازاخستان</option>
	<option value="NC">كاليدونيا الجديدة</option>
	<option value="HR">كرواتيا</option>
	<option value="KH">كمبوديا</option>
	<option value="CA">كندا</option>
	<option value="CU">كوبا</option>
	<option value="KR">كوريا الجنوبية</option>
	<option value="KP">كوريا الشمالية</option>
	<option value="CR">كوستاريكا</option>
	<option value="CO">كولومبيا</option>
	<option value="KI">كيريباتي</option>
	<option value="KE">كينيا</option>
	<option value="LV">لاتفيا</option>
	<option value="LA">لاوس</option>
	<option value="LB">لبنان</option>
	<option value="LU">لوكسمبورج</option>
	<option value="LY">ليبيا</option>
	<option value="LR">ليبيريا</option>
	<option value="LT">ليتوانيا</option>
	<option value="LI">ليختنشتاين</option>
	<option value="LS">ليسوتو</option>
	<option value="MQ">مارتينيك</option>
	<option value="MO">ماكاو الصينية</option>
	<option value="MT">مالطا</option>
	<option value="ML">مالي</option>
	<option value="MY">ماليزيا</option>
	<option value="YT">مايوت</option>
	<option value="MG">مدغشقر</option>
	<option value="EG">مصر</option>
	<option value="MK">مقدونيا</option>
	<option value="MW">ملاوي</option>
	<option value="ZZ">منطقة غير معرفة</option>
	<option value="MN">منغوليا</option>
	<option value="MR">موريتانيا</option>
	<option value="MU">موريشيوس</option>
	<option value="MZ">موزمبيق</option>
	<option value="MD">مولدافيا</option>
	<option value="MC">موناكو</option>
	<option value="MS">مونتسرات</option>
	<option value="MM">ميانمار</option>
	<option value="FM">ميكرونيزيا</option>
	<option value="NA">ناميبيا</option>
	<option value="NR">نورو</option>
	<option value="NP">نيبال</option>
	<option value="NG">نيجيريا</option>
	<option value="NI">نيكاراجوا</option>
	<option value="NZ">نيوزيلاندا</option>
	<option value="NU">نيوي</option>
	<option value="HT">هايتي</option>
	<option value="HN">هندوراس</option>
	<option value="NL">هولندا</option>
	<option value="HK">هونج كونج الصينية</option>
                                    </select>
                                </div>
                                
                                <label for="company" class="col-lg-12"> رقم الهاتف :</label>
                                <div class="form-group col-md-4 col-sm-4">
                                    
                                <select name="countryCode" class="form-control">

    <option data-countryCode="JO" value="962" Selected>Jordan (+962)</option>
    <option data-countryCode="SA" value="966">Saudi Arabia (+966)</option>
    <option data-countryCode="SD" value="249">Sudan (+249)</option>
    <option data-countryCode="LY" value="218">Libya (+218)</option>

	<optgroup label="Other countries">
        <option data-countryCode="GB" value="44">UK (+44)</option>
	    <option data-countryCode="US" value="1">USA (+1)</option>
		<option data-countryCode="DZ" value="213">Algeria (+213)</option>
		<option data-countryCode="AD" value="376">Andorra (+376)</option>
		<option data-countryCode="AO" value="244">Angola (+244)</option>
		<option data-countryCode="AI" value="1264">Anguilla (+1264)</option>
		<option data-countryCode="AG" value="1268">Antigua &amp; Barbuda (+1268)</option>
		<option data-countryCode="AR" value="54">Argentina (+54)</option>
		<option data-countryCode="AM" value="374">Armenia (+374)</option>
		<option data-countryCode="AW" value="297">Aruba (+297)</option>
		<option data-countryCode="AU" value="61">Australia (+61)</option>
		<option data-countryCode="AT" value="43">Austria (+43)</option>
		<option data-countryCode="AZ" value="994">Azerbaijan (+994)</option>
		<option data-countryCode="BS" value="1242">Bahamas (+1242)</option>
		<option data-countryCode="BH" value="973">Bahrain (+973)</option>
		<option data-countryCode="BD" value="880">Bangladesh (+880)</option>
		<option data-countryCode="BB" value="1246">Barbados (+1246)</option>
		<option data-countryCode="BY" value="375">Belarus (+375)</option>
		<option data-countryCode="BE" value="32">Belgium (+32)</option>
		<option data-countryCode="BZ" value="501">Belize (+501)</option>
		<option data-countryCode="BJ" value="229">Benin (+229)</option>
		<option data-countryCode="BM" value="1441">Bermuda (+1441)</option>
		<option data-countryCode="BT" value="975">Bhutan (+975)</option>
		<option data-countryCode="BO" value="591">Bolivia (+591)</option>
		<option data-countryCode="BA" value="387">Bosnia Herzegovina (+387)</option>
		<option data-countryCode="BW" value="267">Botswana (+267)</option>
		<option data-countryCode="BR" value="55">Brazil (+55)</option>
		<option data-countryCode="BN" value="673">Brunei (+673)</option>
		<option data-countryCode="BG" value="359">Bulgaria (+359)</option>
		<option data-countryCode="BF" value="226">Burkina Faso (+226)</option>
		<option data-countryCode="BI" value="257">Burundi (+257)</option>
		<option data-countryCode="KH" value="855">Cambodia (+855)</option>
		<option data-countryCode="CM" value="237">Cameroon (+237)</option>
		<option data-countryCode="CA" value="1">Canada (+1)</option>
		<option data-countryCode="CV" value="238">Cape Verde Islands (+238)</option>
		<option data-countryCode="KY" value="1345">Cayman Islands (+1345)</option>
		<option data-countryCode="CF" value="236">Central African Republic (+236)</option>
		<option data-countryCode="CL" value="56">Chile (+56)</option>
		<option data-countryCode="CN" value="86">China (+86)</option>
		<option data-countryCode="CO" value="57">Colombia (+57)</option>
		<option data-countryCode="KM" value="269">Comoros (+269)</option>
		<option data-countryCode="CG" value="242">Congo (+242)</option>
		<option data-countryCode="CK" value="682">Cook Islands (+682)</option>
		<option data-countryCode="CR" value="506">Costa Rica (+506)</option>
		<option data-countryCode="HR" value="385">Croatia (+385)</option>
		<option data-countryCode="CU" value="53">Cuba (+53)</option>
		<option data-countryCode="CY" value="90392">Cyprus North (+90392)</option>
		<option data-countryCode="CY" value="357">Cyprus South (+357)</option>
		<option data-countryCode="CZ" value="42">Czech Republic (+42)</option>
		<option data-countryCode="DK" value="45">Denmark (+45)</option>
		<option data-countryCode="DJ" value="253">Djibouti (+253)</option>
		<option data-countryCode="DM" value="1809">Dominica (+1809)</option>
		<option data-countryCode="DO" value="1809">Dominican Republic (+1809)</option>
		<option data-countryCode="EC" value="593">Ecuador (+593)</option>
		<option data-countryCode="EG" value="20">Egypt (+20)</option>
		<option data-countryCode="SV" value="503">El Salvador (+503)</option>
		<option data-countryCode="GQ" value="240">Equatorial Guinea (+240)</option>
		<option data-countryCode="ER" value="291">Eritrea (+291)</option>
		<option data-countryCode="EE" value="372">Estonia (+372)</option>
		<option data-countryCode="ET" value="251">Ethiopia (+251)</option>
		<option data-countryCode="FK" value="500">Falkland Islands (+500)</option>
		<option data-countryCode="FO" value="298">Faroe Islands (+298)</option>
		<option data-countryCode="FJ" value="679">Fiji (+679)</option>
		<option data-countryCode="FI" value="358">Finland (+358)</option>
		<option data-countryCode="FR" value="33">France (+33)</option>
		<option data-countryCode="GF" value="594">French Guiana (+594)</option>
		<option data-countryCode="PF" value="689">French Polynesia (+689)</option>
		<option data-countryCode="GA" value="241">Gabon (+241)</option>
		<option data-countryCode="GM" value="220">Gambia (+220)</option>
		<option data-countryCode="GE" value="7880">Georgia (+7880)</option>
		<option data-countryCode="DE" value="49">Germany (+49)</option>
		<option data-countryCode="GH" value="233">Ghana (+233)</option>
		<option data-countryCode="GI" value="350">Gibraltar (+350)</option>
		<option data-countryCode="GR" value="30">Greece (+30)</option>
		<option data-countryCode="GL" value="299">Greenland (+299)</option>
		<option data-countryCode="GD" value="1473">Grenada (+1473)</option>
		<option data-countryCode="GP" value="590">Guadeloupe (+590)</option>
		<option data-countryCode="GU" value="671">Guam (+671)</option>
		<option data-countryCode="GT" value="502">Guatemala (+502)</option>
		<option data-countryCode="GN" value="224">Guinea (+224)</option>
		<option data-countryCode="GW" value="245">Guinea - Bissau (+245)</option>
		<option data-countryCode="GY" value="592">Guyana (+592)</option>
		<option data-countryCode="HT" value="509">Haiti (+509)</option>
		<option data-countryCode="HN" value="504">Honduras (+504)</option>
		<option data-countryCode="HK" value="852">Hong Kong (+852)</option>
		<option data-countryCode="HU" value="36">Hungary (+36)</option>
		<option data-countryCode="IS" value="354">Iceland (+354)</option>
		<option data-countryCode="IN" value="91">India (+91)</option>
		<option data-countryCode="ID" value="62">Indonesia (+62)</option>
		<option data-countryCode="IR" value="98">Iran (+98)</option>
		<option data-countryCode="IQ" value="964">Iraq (+964)</option>
		<option data-countryCode="IE" value="353">Ireland (+353)</option>
		<option data-countryCode="IT" value="39">Italy (+39)</option>
		<option data-countryCode="JM" value="1876">Jamaica (+1876)</option>
		<option data-countryCode="JP" value="81">Japan (+81)</option>
		<option data-countryCode="KZ" value="7">Kazakhstan (+7)</option>
		<option data-countryCode="KE" value="254">Kenya (+254)</option>
		<option data-countryCode="KI" value="686">Kiribati (+686)</option>
		<option data-countryCode="KP" value="850">Korea North (+850)</option>
		<option data-countryCode="KR" value="82">Korea South (+82)</option>
		<option data-countryCode="KW" value="965">Kuwait (+965)</option>
		<option data-countryCode="KG" value="996">Kyrgyzstan (+996)</option>
		<option data-countryCode="LA" value="856">Laos (+856)</option>
		<option data-countryCode="LV" value="371">Latvia (+371)</option>
		<option data-countryCode="LB" value="961">Lebanon (+961)</option>
		<option data-countryCode="LS" value="266">Lesotho (+266)</option>
		<option data-countryCode="LR" value="231">Liberia (+231)</option>
		<option data-countryCode="LI" value="417">Liechtenstein (+417)</option>
		<option data-countryCode="LT" value="370">Lithuania (+370)</option>
		<option data-countryCode="LU" value="352">Luxembourg (+352)</option>
		<option data-countryCode="MO" value="853">Macao (+853)</option>
		<option data-countryCode="MK" value="389">Macedonia (+389)</option>
		<option data-countryCode="MG" value="261">Madagascar (+261)</option>
		<option data-countryCode="MW" value="265">Malawi (+265)</option>
		<option data-countryCode="MY" value="60">Malaysia (+60)</option>
		<option data-countryCode="MV" value="960">Maldives (+960)</option>
		<option data-countryCode="ML" value="223">Mali (+223)</option>
		<option data-countryCode="MT" value="356">Malta (+356)</option>
		<option data-countryCode="MH" value="692">Marshall Islands (+692)</option>
		<option data-countryCode="MQ" value="596">Martinique (+596)</option>
		<option data-countryCode="MR" value="222">Mauritania (+222)</option>
		<option data-countryCode="YT" value="269">Mayotte (+269)</option>
		<option data-countryCode="MX" value="52">Mexico (+52)</option>
		<option data-countryCode="FM" value="691">Micronesia (+691)</option>
		<option data-countryCode="MD" value="373">Moldova (+373)</option>
		<option data-countryCode="MC" value="377">Monaco (+377)</option>
		<option data-countryCode="MN" value="976">Mongolia (+976)</option>
		<option data-countryCode="MS" value="1664">Montserrat (+1664)</option>
		<option data-countryCode="MA" value="212">Morocco (+212)</option>
		<option data-countryCode="MZ" value="258">Mozambique (+258)</option>
		<option data-countryCode="MN" value="95">Myanmar (+95)</option>
		<option data-countryCode="NA" value="264">Namibia (+264)</option>
		<option data-countryCode="NR" value="674">Nauru (+674)</option>
		<option data-countryCode="NP" value="977">Nepal (+977)</option>
		<option data-countryCode="NL" value="31">Netherlands (+31)</option>
		<option data-countryCode="NC" value="687">New Caledonia (+687)</option>
		<option data-countryCode="NZ" value="64">New Zealand (+64)</option>
		<option data-countryCode="NI" value="505">Nicaragua (+505)</option>
		<option data-countryCode="NE" value="227">Niger (+227)</option>
		<option data-countryCode="NG" value="234">Nigeria (+234)</option>
		<option data-countryCode="NU" value="683">Niue (+683)</option>
		<option data-countryCode="NF" value="672">Norfolk Islands (+672)</option>
		<option data-countryCode="NP" value="670">Northern Marianas (+670)</option>
		<option data-countryCode="NO" value="47">Norway (+47)</option>
		<option data-countryCode="OM" value="968">Oman (+968)</option>
		<option data-countryCode="PW" value="680">Palau (+680)</option>
		<option data-countryCode="PA" value="507">Panama (+507)</option>
		<option data-countryCode="PG" value="675">Papua New Guinea (+675)</option>
		<option data-countryCode="PY" value="595">Paraguay (+595)</option>
		<option data-countryCode="PE" value="51">Peru (+51)</option>
		<option data-countryCode="PH" value="63">Philippines (+63)</option>
		<option data-countryCode="PL" value="48">Poland (+48)</option>
		<option data-countryCode="PT" value="351">Portugal (+351)</option>
		<option data-countryCode="PR" value="1787">Puerto Rico (+1787)</option>
		<option data-countryCode="PS" value="972">Palestine (+972)</option>
		<option data-countryCode="QA" value="974">Qatar (+974)</option>
		<option data-countryCode="RE" value="262">Reunion (+262)</option>
		<option data-countryCode="RO" value="40">Romania (+40)</option>
		<option data-countryCode="RU" value="7">Russia (+7)</option>
		<option data-countryCode="RW" value="250">Rwanda (+250)</option>
		<option data-countryCode="SM" value="378">San Marino (+378)</option>
		<option data-countryCode="ST" value="239">Sao Tome &amp; Principe (+239)</option>
		<option data-countryCode="SN" value="221">Senegal (+221)</option>
		<option data-countryCode="CS" value="381">Serbia (+381)</option>
		<option data-countryCode="SC" value="248">Seychelles (+248)</option>
		<option data-countryCode="SL" value="232">Sierra Leone (+232)</option>
		<option data-countryCode="SG" value="65">Singapore (+65)</option>
		<option data-countryCode="SK" value="421">Slovak Republic (+421)</option>
		<option data-countryCode="SI" value="386">Slovenia (+386)</option>
		<option data-countryCode="SB" value="677">Solomon Islands (+677)</option>
		<option data-countryCode="SO" value="252">Somalia (+252)</option>
		<option data-countryCode="ZA" value="27">South Africa (+27)</option>
		<option data-countryCode="ES" value="34">Spain (+34)</option>
		<option data-countryCode="LK" value="94">Sri Lanka (+94)</option>
		<option data-countryCode="SH" value="290">St. Helena (+290)</option>
		<option data-countryCode="KN" value="1869">St. Kitts (+1869)</option>
		<option data-countryCode="SC" value="1758">St. Lucia (+1758)</option>
		<option data-countryCode="SR" value="597">Suriname (+597)</option>
		<option data-countryCode="SZ" value="268">Swaziland (+268)</option>
		<option data-countryCode="SE" value="46">Sweden (+46)</option>
		<option data-countryCode="CH" value="41">Switzerland (+41)</option>
		<option data-countryCode="SI" value="963">Syria (+963)</option>
		<option data-countryCode="TW" value="886">Taiwan (+886)</option>
		<option data-countryCode="TJ" value="7">Tajikstan (+7)</option>
		<option data-countryCode="TH" value="66">Thailand (+66)</option>
		<option data-countryCode="TG" value="228">Togo (+228)</option>
		<option data-countryCode="TO" value="676">Tonga (+676)</option>
		<option data-countryCode="TT" value="1868">Trinidad &amp; Tobago (+1868)</option>
		<option data-countryCode="TN" value="216">Tunisia (+216)</option>
		<option data-countryCode="TR" value="90">Turkey (+90)</option>
		<option data-countryCode="TM" value="7">Turkmenistan (+7)</option>
		<option data-countryCode="TM" value="993">Turkmenistan (+993)</option>
		<option data-countryCode="TC" value="1649">Turks &amp; Caicos Islands (+1649)</option>
		<option data-countryCode="TV" value="688">Tuvalu (+688)</option>
		<option data-countryCode="UG" value="256">Uganda (+256)</option>
		<!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
		<option data-countryCode="UA" value="380">Ukraine (+380)</option>
		<option data-countryCode="AE" value="971">United Arab Emirates (+971)</option>
		<option data-countryCode="UY" value="598">Uruguay (+598)</option>
		<!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
		<option data-countryCode="UZ" value="7">Uzbekistan (+7)</option>
		<option data-countryCode="VU" value="678">Vanuatu (+678)</option>
		<option data-countryCode="VA" value="379">Vatican City (+379)</option>
		<option data-countryCode="VE" value="58">Venezuela (+58)</option>
		<option data-countryCode="VN" value="84">Vietnam (+84)</option>
		<option data-countryCode="VG" value="84">Virgin Islands - British (+1284)</option>
		<option data-countryCode="VI" value="84">Virgin Islands - US (+1340)</option>
		<option data-countryCode="WF" value="681">Wallis &amp; Futuna (+681)</option>
		<option data-countryCode="YE" value="969">Yemen (North)(+969)</option>
		<option data-countryCode="YE" value="967">Yemen (South)(+967)</option>
		<option data-countryCode="ZM" value="260">Zambia (+260)</option>
		<option data-countryCode="ZW" value="263">Zimbabwe (+263)</option>
	</optgroup>
</select>                                </div>
                                <div class="form-group col-md-8 col-sm-8">
                                    
                                    <input name="number" id="number" type="tel" class="form-control element-block" placeholder="رقم الهاتف"
                                           required="required">
                                </div>

 
                                <label for="company" class="col-lg-12">مكان العمل :</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="company" id="company" type="text" class="form-control element-block" placeholder="مكان العمل"
                                           required="required">
                                </div>
                                <label for="job_title" class="col-lg-12"> الوظيفة</label>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input name="job_title" id="job_title" type="text" class="form-control element-block" placeholder="المسمى الوظيفي"
                                           required="required">
                                </div>

                                <label for="job_title" class="col-lg-12"> تاريخ الميلاد</label>


<div class="form-group col-md-4 col-sm-4">
<select class="form-control" id="day" name="day">
    <option value="">day</option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
</select>
</div>
<div class="form-group col-md-4 col-sm-4">

<select  id="month" name="month" class="form-control">
    <option value="">month</option>
    <option value="01">January</option>
    <option value="02">February</option>
    <option value="03">March</option>
    <option value="04">April</option>
    <option value="05">May</option>
    <option value="06">June</option>
    <option value="07">July</option>
    <option value="08">August</option>
    <option value="09">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
    <option value="12">December</option>
</select>       
</div>

<div class="form-group col-md-4 col-sm-4">
 <select  id="year" name="year" class="form-control">
    <option value="">year</option>
    <option value="1960">1960</option>
    <option value="1961">1961</option>
    <option value="1962">1962</option>
    <option value="1963">1963</option>
    <option value="1964">1964</option>
    <option value="1965">1965</option>
    <option value="1966">1966</option>
    <option value="1967">1967</option>
    <option value="1968">1968</option>
    <option value="1969">1969</option>
    <option value="1970">1970</option>
    <option value="1971">1971</option>
    <option value="1972">1972</option>
    <option value="1973">1973</option>
    <option value="1974">1974</option>
    <option value="1975">1975</option>
    <option value="1976">1976</option>
    <option value="1977">1977</option>
    <option value="1978">1978</option>
    <option value="1979">1979</option>
    <option value="1980">1980</option>
    <option value="1981">1981</option>
    <option value="1982">1982</option>
    <option value="1983">1983</option>
    <option value="1984">1984</option>
    <option value="1985">1985</option>
    <option value="1986">1986</option>
    <option value="1987">1987</option>
    <option value="1988">1988</option>
    <option value="1989">1989</option>
    <option value="1990">1990</option>
    <option value="1991">1991</option>
    <option value="1992">1992</option>
    <option value="1993">1993</option>
    <option value="1994">1994</option>
    <option value="1995">1995</option>
    <option value="1996">1996</option>
    <option value="1997">1997</option>
    <option value="1998">1998</option>
    <option value="1999">1999</option>
    <option value="2000">2000</option>
    <option value="2001">2001</option>
    <option value="2002">2002</option>
    <option value="2003">2003</option>
    <option value="2004">2004</option>
    <option value="2005">2005</option>
    <option value="2006">2006</option>
    <option value="2007">2007</option>
    <option value="2008">2008</option>
    <option value="2009">2009</option>
    <option value="2010">2010</option>
    <option value="2011">2011</option>
    <option value="2012">2012</option>
    <option value="2013">2013</option>
    <option value="2014">2014</option>
    <option value="2015">2015</option>
    <option value="2016">2016</option>
    <option value="2017">2017</option>
    <option value="2018">2018</option>
    <option value="2019">2019</option>
    <option value="2020">2020</option>
    <option value="2021">2021</option>
    <option value="2022">2022</option>
    <option value="2023">2023</option>
</select>   
</div>

                                <label for="job_title" class="col-lg-12"> الجنس </label>
                                <div class="form-group col-md-8 col-sm-8"></div>

                                <div class="form-group col-md-2 col-sm-2 text-center" style="font-size:21px;" >
                                انثى
                                <input  name="gender"  id="gender" value="female" type="radio">
                                </div>  
                                
                                <div class="form-group col-md-2 col-sm-2 text-center" style="font-size:21px;">
                                ذكر
                                <input name="gender"  id="gender" type="radio" value="male">
                                </div>  

                                <input type="text" style="display: none" value="{{ $course[0]->id }}">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">
                                        إرسال
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="application-info" style="max-width: 75%; margin: 0 0 30px 0">
                            <div class="">
                                <h3>@php echo $apply_course_desc1->$Title @endphp </h3>
                            </div>
                            <div class="">
                                <h5> @php echo $apply_course_desc2->$Title @endphp </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <br><br>
        <div class="modal fade bd-example-modal-lg" id="applyCourseFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/aplay_course.jpg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">Check our privacy policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
    
@stop
@section('scripts')
<script>
function mySubmitFunction() {
$('#applyCourseFormModal').modal('show');

}
</script>

<script>

var daysInMonth = [31,28,31,30,31,30,31,31,30,31,30,31],
    today = new Date(),
    // default targetDate is christmas
    targetDate = new Date(today.getFullYear(), 11, 25); 

setDate(targetDate);
setYears(100) // set the next five years in dropdown

$("#select-month").change(function() {
  var monthIndex = $("#select-month").val();
  setDays(monthIndex);
});

function setDate(date) {
  setDays(date.getMonth());
  $("#select-day").val(date.getDate());
  $("#select-month").val(date.getMonth());
  $("#select-year").val(date.getFullYear()); 
}

// make sure the number of days correspond with the selected month
function setDays(monthIndex) {
  var optionCount = $('#select-day option').length,
      daysCount = daysInMonth[monthIndex];
  
  if (optionCount < daysCount) {
    for (var i = optionCount; i < daysCount; i++) {
      $('#select-day')
        .append($("<option></option>")
        .attr("value", i + 1)
        .text(i + 1)); 
    }
  }
  else {
    for (var i = daysCount; i < optionCount; i++) {
      var optionItem = '#select-day option[value=' + (i+1) + ']';
      $(optionItem).remove();
    } 
  } 
}

function setYears(val) {
  var year = today.getFullYear();
  for (var i = 0; i < val; i++) {
      $('#select-year')
        .append($("<option></option>")
        .attr("value", year + i)
        .text(year + i)); 
    }
}

   
</script>
@stop

