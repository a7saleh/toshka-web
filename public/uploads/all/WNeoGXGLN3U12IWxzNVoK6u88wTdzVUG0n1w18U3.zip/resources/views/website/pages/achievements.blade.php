<!------------------------- achievements content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.trusted_by_and_accreditation'))

@section('content')

<?php 
$banner=DB::table('page_contents')->where('ref_page','=','trusted_accreditation_banner')->first();
$tac_tac_title=DB::table('page_contents')->where('ref_page','=','tac_tac_title')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;

?>

    @if(app()->getLocale() == "en")
        <!-- heading banner -->
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav" id="partners_trusted">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">{{$tac_tac_title->$Title_Name}}</li>
                </ol>
            </div>
        </nav>

        <!-- partners block -->
        <section class="partner-block" >
            <div class="container">
                <div class="row">
                    <header class="seperator-head" style="direction:rtl!important;" >
                        <h2 class="text-center" style="direction:rtl!important;" >{{$tac_tac_title->$Title_Name}}</h2>
                    </header><br>
                </div>
                <div class="row partners-row">
                    <div class="col-xs-12">
                        <ul class="list-unstyled partner-list">
                            @foreach($accreditation as $acc)
                                <li><a href="#trusted_by_acc_{{ $acc->id }}"><img src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}"  alt="no-photo"></a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section id="accreditation" class="news-block bg-gray" >
            <div class="container">
                <div class="row">
                    @foreach($accreditation as $acc)
                        <div class="col-xs-12 col-md-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <!-- news column post -->
                            <article class="news-column-post" id="trusted_by_acc_{{ $acc->id }}" style="cursor: default !important;">
                                <div class="alignleft no-shrink">
                                    <img style="background: #eee;" src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}" alt="no-photo">
                                </div>
                                <div class="descr-wrap">
                                    <h3>{{ $acc->name }}</h3>
                                    <p>@php echo $acc->description; @endphp</p>
                                </div>
                            </article>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @else
        <!-- heading banner -->
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl" id="partners_trusted">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li class="active">{{$tac_tac_title->$Title_Name}}</li>
                </ol>
            </div>
        </nav>

        <!-- partners block -->
        <section class="partner-block" >
            <div class="container">
                <div class="row">
                    <header class="seperator-head">
                        <h2 class="text-center">{{$tac_tac_title->$Title_Name}}</h2>
                    </header><br>
                </div>
                <div class="row partners-row">
                    <div class="col-xs-12">
                        <ul class="list-unstyled partner-list">
                            @foreach($accreditation as $acc)
                                <li><a href="#trusted_by_acc_{{ $acc->id }}"><img src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}"  alt="no-photo"></a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section id="trusted_by_acc" class="news-block bg-gray rtl">
            <div class="container">
                <div class="row">
                    @foreach($accreditation as $acc)
                            <div class="col-xs-12 col-md-12" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <!-- news column post -->
                            <article class="news-column-post" id="trusted_by_acc_{{ $acc->id }}" style="cursor: default !important;">
                                <div class="alignleft no-shrink">
                                    <img style="background: #eee;" src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}" alt="no-photo">
                                </div>
                                <div class="descr-wrap">
                                    <h3>{{ $acc->name_ar }}</h3>
                                    <p>@php echo $acc->description_ar; @endphp</p>
                                </div>
                            </article>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif
@stop

