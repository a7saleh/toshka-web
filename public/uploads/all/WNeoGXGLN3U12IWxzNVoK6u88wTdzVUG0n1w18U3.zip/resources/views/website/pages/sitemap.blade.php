<!------------------------- sitemap content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.sitemap'))

@section('content')

    @if(app()->getLocale() == "en")
        <div class="container survey-form" style="margin-top:10%;margin-bottom:10%;">
            <div class="row">
                <div class="col-sm-12">
                    <h1>Sitemap</h1>
                    <br>
                    <div class="form-group">
                        <ul>
                            
                     
                                       <?php 
                                       $menu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=','0')->orderBy('element_order','asc')->get();
                                       $Name_Field="name_".app()->getLocale();
                                       ?>
                                       @foreach($menu_items as $menu_item)
                                       <?php $submenu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->get();
                                       $submenu_item_found=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->first();
                                       ?>
                                        <li><a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a></li>


                                            @if($submenu_item_found!=null)
                                             <ul>
                                            @foreach($submenu_items as $submenu_item)
                                            <li><a href="{{ url($submenu_item->url)}}">{{$submenu_item->$Name_Field}}</a></li>
                                           @endforeach
                                           </ul>
                                           
                                           @endif
                                           @endforeach 
      
                            
                            
                 </ul>
                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="container survey-form rtl" style="margin-top:10%;margin-bottom:10%;">
            <div class="row">
                <div class="col-sm-12">
                    <h1>خريطة الموقع</h1>
                    <br>
                    <div class="form-group">
                        <ul>
                            
                            
                      
                                       <?php 
                                       $menu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=','0')->orderBy('element_order','asc')->get();
                                       $Name_Field="name_".app()->getLocale();
                                       ?>
                                       @foreach($menu_items as $menu_item)
                                       <?php $submenu_items=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->get();
                                       $submenu_item_found=DB::table('menu')->where('status','=','active')->where('parent_id','=',$menu_item->id)->first();
                                       ?>
                                        <li><a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a></li>


                                            @if($submenu_item_found!=null)
                                             <ul>
                                            @foreach($submenu_items as $submenu_item)
                                            <li><a href="{{ url($submenu_item->url)}}">{{$submenu_item->$Name_Field}}</a></li>
                                           @endforeach
                                           </ul>
                                           
                                           @endif
                                           @endforeach 
      
                            

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    @endif



@stop
