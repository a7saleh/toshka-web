<!------------------------- inner gallery content -------------------------->
@extends('website.layout.master')

@section('title')
    @if(app()->getLocale() == "en")
        {{ $gallery->title_en }}
    @else
        {{ $gallery->title_ar }}
    @endif
@endsection

@section('description')
    @if(app()->getLocale() == "en")
        {{ $gallery->description_en }}
    @else
        {{ $gallery->description_ar }}
    @endif
@endsection
@section('description_og')
    @if(app()->getLocale() == "en")
        {{ $gallery->description_en }}
    @else
        {{ $gallery->description_ar }}
    @endif
@endsection
@section('description_tw')
    @if(app()->getLocale() == "en")
        {{ $gallery->description_en }}
    @else
        {{ $gallery->description_ar }}
    @endif
@endsection

@section('image_og')
    {{ asset("storage/uploads/courses") }}/{{ $gallery_images[0] }}
@endsection
@section('image_tw')
    {{ asset("storage/uploads/courses") }}/{{ $gallery_images[0] }}
@endsection

@section('content')

    @if(app()->getLocale() == "en")
        <nav class="breadcrumb-nav gall-bread margin-top-90">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><a href="{{ url('/aljhood/gallery') }}">Gallery</a></li>
                    <li class="active"> @php echo $gallery->title_en; @endphp</li>
                </ol>
            </div>
        </nav>
        <div class="gallery-slider-holder container">
            <div class="container">
                <div class="row">
                    <div class="col-lg--12">
                        <div class="text-holder">
                            <h2 style="color: #222;">  @php echo $gallery->title_en; @endphp </h2>
                            <p>@php echo $gallery->description_en; @endphp</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div id="jssor_1" style="position:relative;margin:0 auto;top:20px;left:0px;width:980px;height:480px;overflow:hidden;visibility:hidden; padding-bottom: 100px; box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px, rgb(51, 51, 51) 0px 0px 0px 3px; ">
                        <!-- Loading Screen -->
                        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
                            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="{{asset('img/spin.svg')}}" />
                        </div>
                        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">


                                    @if(!empty($gallery->video))
        <div>
        <iframe  data-u="image" src="{{ $gallery->video }}?auto=compress&cs=tinysrgb&dpr=1&w=500" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!--<iframe  data-u="thumb" src="{{ $gallery->video }}?auto=compress&cs=tinysrgb&dpr=1&w=500" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
        </div>
        @endif
 

                            @foreach($gallery_images as $gal)
                                <div>
                                    <img data-u="image" src="{{ asset('storage/uploads/gallery') }}/{{ $gal }}?auto=compress&cs=tinysrgb&dpr=1&w=500" />
                                    <img data-u="thumb" src="{{ asset('storage/uploads/gallery') }}/{{ $gal }}?auto=compress&cs=tinysrgb&dpr=1&w=500" />
                                </div>
                            @endforeach


                        </div><a data-scale="0" href="https://www.jssor.com" style="display:none;position:absolute;">web animation</a>
                        <!-- Thumbnail Navigator -->
                        <div data-u="thumbnavigator" class="jssort101" style="position:absolute;left:0px;bottom:0px;width:980px;height:100px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75">
                            <div data-u="slides">
                                <div data-u="prototype" class="p" style="width:190px;height:90px;">
                                    <div data-u="thumbnailtemplate" class="t"></div>
                                </div>
                            </div>
                        </div>
                        <!-- Arrow Navigator -->
                        <div data-u="arrowleft" class="jssora106" style="width:55px;height:55px;top:162px;left:30px;" data-scale="0.75">
                            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                                <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                                <polyline class="a" points="7930.4,5495.7 5426.1,8000 7930.4,10504.3 "></polyline>
                                <line class="a" x1="10573.9" y1="8000" x2="5426.1" y2="8000"></line>
                            </svg>
                        </div>
                        <div data-u="arrowright" class="jssora106" style="width:55px;height:55px;top:162px;right:30px;" data-scale="0.75">
                            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                                <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                                <polyline class="a" points="8069.6,5495.7 10573.9,8000 8069.6,10504.3 "></polyline>
                                <line class="a" x1="5426.1" y1="8000" x2="10573.9" y2="8000"></line>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

                <div class="row text-center" style="margin-top:150px;text-align:center!important;">

                    
                    <div class="col-lg-12 col-xs-12" >
                        <div class="gallery-share">
                            <div class="share">
                                <p>Share :</p>
                                <div id="social-links">
	<ul>
		<li><a href="https://www.facebook.com/sharer/sharer.php?u={{URL::current()}}" class="social-button " id=""><span class="fa fa-facebook"></span></a></li>
		<li><a href="https://twitter.com/intent/tweet?text=&amp;url={{URL::current()}}" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
		<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{URL::current()}}&amp;title=my share text&amp;summary=" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
		<li><a href="https://wa.me/?text={{URL::current()}}" class="social-button " id=""><span class="fa fa-whatsapp"></span></a></li>    
	</ul>
</div>  
                        </div>
                    </div>                    
                    
                </div>

        </div>
    @else
        <nav class="breadcrumb-nav gall-bread rtl margin-top-90">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li><a href="{{ url('/aljhood/gallery') }}">الصور</a></li>
                    <li class="active"> @php echo $gallery->title_ar; @endphp</li>
                </ol>
            </div>
        </nav>
        <div class="gallery-slider-holder container rtl">
            <div class="container">
                <div class="row">
                    <div class="col-lg--12">
                        <div class="text-holder">
                            <h2 style="color: #222;">  @php echo $gallery->title_ar; @endphp </h2>
                            <p>@php echo $gallery->description_ar; @endphp</p>
                        </div>
                    </div>

                </div>
            </div>
            <div id="jssor_1" style="position:relative;margin:0 auto;top:30px;left:0px;width:980px;height:480px;overflow:hidden;visibility:hidden; padding-bottom: 100px; box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px, rgb(51, 51, 51) 0px 0px 0px 3px;">
                <!-- Loading Screen -->
                <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
                    <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="{{asset('img/spin.svg')}}" />
                </div>
                <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">
       
        @if(!empty($gallery->video))
        <div>
        <iframe  data-u="image" src="{{ $gallery->video }}?auto=compress&cs=tinysrgb&dpr=1&w=500" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!--<iframe  data-u="thumb" src="{{ $gallery->video }}?auto=compress&cs=tinysrgb&dpr=1&w=500" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
        </div>
        @endif                   
                    @foreach($gallery_images as $gal)
                        <div>
                            <img data-u="image" src="{{ asset('storage/uploads/gallery') }}/{{ $gal }}?auto=compress&cs=tinysrgb&dpr=1&w=500" />
                            <img data-u="thumb" src="{{ asset('storage/uploads/gallery') }}/{{ $gal }}?auto=compress&cs=tinysrgb&dpr=1&w=500" />
                        </div>
                    @endforeach
                    




                </div><a data-scale="0" href="https://www.jssor.com" style="display:none;position:absolute;">web animation</a>
                <!-- Thumbnail Navigator -->
                <div data-u="thumbnavigator" class="jssort101" style="position:absolute;left:0px;bottom:0px;width:980px;height:100px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75">
                    <div data-u="slides">
                        <div data-u="prototype" class="p" style="width:190px;height:90px;">
                            <div data-u="thumbnailtemplate" class="t"></div>
                        </div>
                    </div>
                </div>
                <!-- Arrow Navigator -->
                <div data-u="arrowleft" class="jssora106" style="width:55px;height:55px;top:162px;left:30px;" data-scale="0.75">
                    <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                        <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                        <polyline class="a" points="7930.4,5495.7 5426.1,8000 7930.4,10504.3 "></polyline>
                        <line class="a" x1="10573.9" y1="8000" x2="5426.1" y2="8000"></line>
                    </svg>
                </div>
                <div data-u="arrowright" class="jssora106" style="width:55px;height:55px;top:162px;right:30px;" data-scale="0.75">
                    <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                        <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                        <polyline class="a" points="8069.6,5495.7 10573.9,8000 8069.6,10504.3 "></polyline>
                        <line class="a" x1="5426.1" y1="8000" x2="10573.9" y2="8000"></line>
                    </svg>
                </div>
            </div>
        
                        <div class="row text-center" style="margin-top:150px;text-align:center!important;">
                    
                    <div class="col-lg-12 col-xs-12">
                        <div class="gallery-share" style="float:right;">
                            <div class="share">
                                <p> مشاركة :</p>

                                <div id="social-links">
	<ul>
		<li><a href="https://www.facebook.com/sharer/sharer.php?u={{URL::current()}}" class="social-button " id=""><span class="fa fa-facebook"></span></a></li>
		<li><a href="https://twitter.com/intent/tweet?text=&amp;url={{URL::current()}}" class="social-button " id=""><span class="fa fa-twitter"></span></a></li>
		<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{URL::current()}}&amp;title=my share text&amp;summary=" class="social-button " id=""><span class="fa fa-linkedin"></span></a></li>
		<li><a href="https://wa.me/?text={{URL::current()}}" class="social-button " id=""><span class="fa fa-whatsapp"></span></a></li>    
	</ul>
</div>   



                            </div>
                        </div>
                    </div>                    
                    
                </div>
        
        </div>
    @endif

@stop

@section('scripts')

<!-- #region Jssor Slider Begin -->
<!-- Generator: Jssor Slider Composer -->
<!-- Source: https://www.jssor.com/demos/image-gallery.slider/=edit -->
<script type="text/javascript" src="{{ asset("frontend/js/jssor.js") }}"></script>
<script type="text/javascript">
    window.jssor_1_slider_init = function() {

        var jssor_1_SlideshowTransitions = [
          {$Duration:800,x:0.3,$During:{$Left:[0.3,0.7]},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:-0.3,$SlideOut:true,$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:-0.3,$During:{$Left:[0.3,0.7]},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,$SlideOut:true,$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:0.3,$During:{$Top:[0.3,0.7]},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:-0.3,$SlideOut:true,$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:-0.3,$During:{$Top:[0.3,0.7]},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:0.3,$SlideOut:true,$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,$Cols:2,$During:{$Left:[0.3,0.7]},$ChessMode:{$Column:3},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,$Cols:2,$SlideOut:true,$ChessMode:{$Column:3},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:0.3,$Rows:2,$During:{$Top:[0.3,0.7]},$ChessMode:{$Row:12},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:0.3,$Rows:2,$SlideOut:true,$ChessMode:{$Row:12},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:0.3,$Cols:2,$During:{$Top:[0.3,0.7]},$ChessMode:{$Column:12},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,y:-0.3,$Cols:2,$SlideOut:true,$ChessMode:{$Column:12},$Easing:{$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,$Rows:2,$During:{$Left:[0.3,0.7]},$ChessMode:{$Row:3},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:-0.3,$Rows:2,$SlideOut:true,$ChessMode:{$Row:3},$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,y:0.3,$Cols:2,$Rows:2,$During:{$Left:[0.3,0.7],$Top:[0.3,0.7]},$ChessMode:{$Column:3,$Row:12},$Easing:{$Left:$Jease$.$InCubic,$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,x:0.3,y:0.3,$Cols:2,$Rows:2,$During:{$Left:[0.3,0.7],$Top:[0.3,0.7]},$SlideOut:true,$ChessMode:{$Column:3,$Row:12},$Easing:{$Left:$Jease$.$InCubic,$Top:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,$Delay:20,$Clip:3,$Assembly:260,$Easing:{$Clip:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,$Delay:20,$Clip:3,$SlideOut:true,$Assembly:260,$Easing:{$Clip:$Jease$.$OutCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,$Delay:20,$Clip:12,$Assembly:260,$Easing:{$Clip:$Jease$.$InCubic,$Opacity:$Jease$.$Linear},$Opacity:2},
          {$Duration:800,$Delay:20,$Clip:12,$SlideOut:true,$Assembly:260,$Easing:{$Clip:$Jease$.$OutCubic,$Opacity:$Jease$.$Linear},$Opacity:2}
        ];

        var jssor_1_options = {
          $AutoPlay: 1,
          $SlideshowOptions: {
            $Class: $JssorSlideshowRunner$,
            $Transitions: jssor_1_SlideshowTransitions,
            $TransitionsOrder: 1
          },
          $ArrowNavigatorOptions: {
            $Class: $JssorArrowNavigator$
          },
          $ThumbnailNavigatorOptions: {
            $Class: $JssorThumbnailNavigator$,
            $SpacingX: 5,
            $SpacingY: 5
          }
        };

        var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

        /*#region responsive code begin*/

        var MAX_WIDTH = 1400;

        function ScaleSlider() {
            var containerElement = jssor_1_slider.$Elmt.parentNode;
            var containerWidth = containerElement.clientWidth;

            if (containerWidth) {

                var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                jssor_1_slider.$ScaleWidth(expectedWidth);
            }
            else {
                window.setTimeout(ScaleSlider, 30);
            }
        }

        ScaleSlider();

        $Jssor$.$AddEvent(window, "load", ScaleSlider);
        $Jssor$.$AddEvent(window, "resize", ScaleSlider);
        $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
        /*#endregion responsive code end*/
    };
</script>

<script type="text/javascript">jssor_1_slider_init();</script>
@stop
