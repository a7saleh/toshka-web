<!------------------------- leadership content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.leadership'))

@section('content')

<? $banner=DB::table('page_contents')->where('ref_page','=','Leadership_banner')->first();
$Title_Name='title_'.app()->getLocale();
$Description_Name='description_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
?>

        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">Leadership</li>
                </ol>
            </div>
        </nav>
        <!-- text info block -->
    
    <section id="values" class="values mb-5 mt-5">
      <div class="container" data-aos="fade-up">
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
                  
                 <div class="col-lg-10" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
        <img  src="{{ asset('storage/uploads/page-contents') }}/{{$content[0]->image}}" class="element-block image"  alt="no-photo" style="width:100%;">
              <h1 class="gold-color">@php echo $content[0]->$Title_Name; @endphp</h1>
              <p><strong>@php echo $content[0]->$Description_Name; @endphp</strong></p>
            </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
          </div>
      </div>
    </section><br><br>
        

@stop
