<!------------------------- become instructor form  content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.become_instructor'))

@section('content')

<?php
$languages = DB::table('page_contents')->where('ref_page' , 'join_us_languages')->orderBy('id' , 'desc')->get();
$categories = DB::table('page_contents')->where('ref_page' , 'join_us_categories')->orderBy('id' , 'desc')->get();
$choose_language = DB::table('page_contents')->where('ref_page' , 'choose_language')->orderBy('id' , 'desc')->first();
$choose_category = DB::table('page_contents')->where('ref_page' , 'choose_category')->first();
$instructor_form_title=DB::table('page_contents')->where('ref_page','=','instructor_form_title')->first();
$Title='title_'.app()->getLocale();
?>

    @if(app()->getLocale() == "en")
        <section class="contact-block" style="margin-top:10%; margin-bottom: 10%;">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2>{{$instructor_form_title->$Title}}</h2>
                </header>
                <!-- contact form -->
                <div class="row" style="display: flex; flex-direction: row; justify-content: center; align-items: center    ">
                    <div class="col-lg-8">
                                                    @if(Session::has('success'))
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="margin-top:30vh">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
    
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <img src="{{ url('frontend/images/progArtboard 3.jpg') }}">
      </div>
      
    </div>
  </div>
</div>

<script type="text/javascript">
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
</script>
                            @endif

                        <div style="box-shadow:5px 5px 10px grey;padding: 20px;">
                            <form id="teachForm" action="{{ url('teachForm') }}" method="post" class="contact-form" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="first_name"  name="first_name" type="text" class="form-control element-block" placeholder="First Name*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="last_name" name="last_name" type="text" class="form-control element-block" placeholder="Last Name*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="number" name="number" type="text" class="form-control element-block" placeholder="Phone Number*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="email" name="email" type="email" class="form-control element-block" placeholder="Email*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <select id="country" class="arrow_down" name="country" style="width: 100%">
                                        <option value="" selected="selected">Choose Country</option>
                                        <option value="Afghanistan">Afghanistan</option>
                                        <option value="Aland Islands">Aland Islands</option>
                                        <option value="Albania">Albania</option>
                                        <option value="Algeria">Algeria</option>
                                        <option value="American Samoa">American Samoa</option>
                                        <option value="Andorra">Andorra</option>
                                        <option value="Angola">Angola</option>
                                        <option value="Anguilla">Anguilla</option>
                                        <option value="Antarctica">Antarctica</option>
                                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                        <option value="Argentina">Argentina</option>
                                        <option value="Armenia">Armenia</option>
                                        <option value="Aruba">Aruba</option>
                                        <option value="Australia">Australia</option>
                                        <option value="Austria">Austria</option>
                                        <option value="Azerbaijan">Azerbaijan</option>
                                        <option value="Bahamas">Bahamas</option>
                                        <option value="Bahrain">Bahrain</option>
                                        <option value="Bangladesh">Bangladesh</option>
                                        <option value="Barbados">Barbados</option>
                                        <option value="Belarus">Belarus</option>
                                        <option value="Belgium">Belgium</option>
                                        <option value="Belize">Belize</option>
                                        <option value="Benin">Benin</option>
                                        <option value="Bermuda">Bermuda</option>
                                        <option value="Bhutan">Bhutan</option>
                                        <option value="Bolivia">Bolivia</option>
                                        <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                        <option value="Botswana">Botswana</option>
                                        <option value="Bouvet Island">Bouvet Island</option>
                                        <option value="Brazil">Brazil</option>
                                        <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                        <option value="Brunei Darussalam">Brunei Darussalam</option>
                                        <option value="Bulgaria">Bulgaria</option>
                                        <option value="Burkina Faso">Burkina Faso</option>
                                        <option value="Burundi">Burundi</option>
                                        <option value="Cambodia">Cambodia</option>
                                        <option value="Cameroon">Cameroon</option>
                                        <option value="Canada">Canada</option>
                                        <option value="Cape Verde">Cape Verde</option>
                                        <option value="Cayman Islands">Cayman Islands</option>
                                        <option value="Central African Republic">Central African Republic</option>
                                        <option value="Chad">Chad</option>
                                        <option value="Chile">Chile</option>
                                        <option value="China">China</option>
                                        <option value="Christmas Island">Christmas Island</option>
                                        <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                        <option value="Colombia">Colombia</option>
                                        <option value="Comoros">Comoros</option>
                                        <option value="Congo">Congo</option>
                                        <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                                        <option value="Cook Islands">Cook Islands</option>
                                        <option value="Costa Rica">Costa Rica</option>
                                        <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                                        <option value="Croatia">Croatia</option>
                                        <option value="Cuba">Cuba</option>
                                        <option value="Curacao">Curacao</option>
                                        <option value="Cyprus">Cyprus</option>
                                        <option value="Czech Republic">Czech Republic</option>
                                        <option value="Denmark">Denmark</option>
                                        <option value="Djibouti">Djibouti</option>
                                        <option value="Dominica">Dominica</option>
                                        <option value="Dominican Republic">Dominican Republic</option>
                                        <option value="Ecuador">Ecuador</option>
                                        <option value="Egypt">Egypt</option>
                                        <option value="El Salvador">El Salvador</option>
                                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                                        <option value="Eritrea">Eritrea</option>
                                        <option value="Estonia">Estonia</option>
                                        <option value="Ethiopia">Ethiopia</option>
                                        <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                        <option value="Faroe Islands">Faroe Islands</option>
                                        <option value="Fiji">Fiji</option>
                                        <option value="Finland">Finland</option>
                                        <option value="France">France</option>
                                        <option value="French Guiana">French Guiana</option>
                                        <option value="French Polynesia">French Polynesia</option>
                                        <option value="French Southern Territories">French Southern Territories</option>
                                        <option value="Gabon">Gabon</option>
                                        <option value="Gambia">Gambia</option>
                                        <option value="Georgia">Georgia</option>
                                        <option value="Germany">Germany</option>
                                        <option value="Ghana">Ghana</option>
                                        <option value="Gibraltar">Gibraltar</option>
                                        <option value="Greece">Greece</option>
                                        <option value="Greenland">Greenland</option>
                                        <option value="Grenada">Grenada</option>
                                        <option value="Guadeloupe">Guadeloupe</option>
                                        <option value="Guam">Guam</option>
                                        <option value="Guatemala">Guatemala</option>
                                        <option value="Guernsey">Guernsey</option>
                                        <option value="Guinea">Guinea</option>
                                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                                        <option value="Guyana">Guyana</option>
                                        <option value="Haiti">Haiti</option>
                                        <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                        <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                        <option value="Honduras">Honduras</option>
                                        <option value="Hong Kong">Hong Kong</option>
                                        <option value="Hungary">Hungary</option>
                                        <option value="Iceland">Iceland</option>
                                        <option value="India">India</option>
                                        <option value="Indonesia">Indonesia</option>
                                        <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                        <option value="Iraq">Iraq</option>
                                        <option value="Ireland">Ireland</option>
                                        <option value="Isle of Man">Isle of Man</option>
                                        <option value="Israel">Israel</option>
                                        <option value="Italy">Italy</option>
                                        <option value="Jamaica">Jamaica</option>
                                        <option value="Japan">Japan</option>
                                        <option value="Jersey">Jersey</option>
                                        <option value="Jordan">Jordan</option>
                                        <option value="Kazakhstan">Kazakhstan</option>
                                        <option value="Kenya">Kenya</option>
                                        <option value="Kiribati">Kiribati</option>
                                        <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                        <option value="Korea, Republic of">Korea, Republic of</option>
                                        <option value="Kosovo">Kosovo</option>
                                        <option value="Kuwait">Kuwait</option>
                                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                                        <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                        <option value="Latvia">Latvia</option>
                                        <option value="Lebanon">Lebanon</option>
                                        <option value="Lesotho">Lesotho</option>
                                        <option value="Liberia">Liberia</option>
                                        <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                        <option value="Liechtenstein">Liechtenstein</option>
                                        <option value="Lithuania">Lithuania</option>
                                        <option value="Luxembourg">Luxembourg</option>
                                        <option value="Macao">Macao</option>
                                        <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                                        <option value="Madagascar">Madagascar</option>
                                        <option value="Malawi">Malawi</option>
                                        <option value="Malaysia">Malaysia</option>
                                        <option value="Maldives">Maldives</option>
                                        <option value="Mali">Mali</option>
                                        <option value="Malta">Malta</option>
                                        <option value="Marshall Islands">Marshall Islands</option>
                                        <option value="Martinique">Martinique</option>
                                        <option value="Mauritania">Mauritania</option>
                                        <option value="Mauritius">Mauritius</option>
                                        <option value="Mayotte">Mayotte</option>
                                        <option value="Mexico">Mexico</option>
                                        <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                        <option value="Moldova, Republic of">Moldova, Republic of</option>
                                        <option value="Monaco">Monaco</option>
                                        <option value="Mongolia">Mongolia</option>
                                        <option value="Montenegro">Montenegro</option>
                                        <option value="Montserrat">Montserrat</option>
                                        <option value="Morocco">Morocco</option>
                                        <option value="Mozambique">Mozambique</option>
                                        <option value="Myanmar">Myanmar</option>
                                        <option value="Namibia">Namibia</option>
                                        <option value="Nauru">Nauru</option>
                                        <option value="Nepal">Nepal</option>
                                        <option value="Netherlands">Netherlands</option>
                                        <option value="Netherlands Antilles">Netherlands Antilles</option>
                                        <option value="New Caledonia">New Caledonia</option>
                                        <option value="New Zealand">New Zealand</option>
                                        <option value="Nicaragua">Nicaragua</option>
                                        <option value="Niger">Niger</option>
                                        <option value="Nigeria">Nigeria</option>
                                        <option value="Niue">Niue</option>
                                        <option value="Norfolk Island">Norfolk Island</option>
                                        <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                        <option value="Norway">Norway</option>
                                        <option value="Oman">Oman</option>
                                        <option value="Pakistan">Pakistan</option>
                                        <option value="Palau">Palau</option>
                                        <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                        <option value="Panama">Panama</option>
                                        <option value="Papua New Guinea">Papua New Guinea</option>
                                        <option value="Paraguay">Paraguay</option>
                                        <option value="Peru">Peru</option>
                                        <option value="Philippines">Philippines</option>
                                        <option value="Pitcairn">Pitcairn</option>
                                        <option value="Poland">Poland</option>
                                        <option value="Portugal">Portugal</option>
                                        <option value="Puerto Rico">Puerto Rico</option>
                                        <option value="Qatar">Qatar</option>
                                        <option value="Reunion">Reunion</option>
                                        <option value="Romania">Romania</option>
                                        <option value="Russian Federation">Russian Federation</option>
                                        <option value="Rwanda">Rwanda</option>
                                        <option value="Saint Barthelemy">Saint Barthelemy</option>
                                        <option value="Saint Helena">Saint Helena</option>
                                        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                        <option value="Saint Lucia">Saint Lucia</option>
                                        <option value="Saint Martin">Saint Martin</option>
                                        <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                        <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                        <option value="Samoa">Samoa</option>
                                        <option value="San Marino">San Marino</option>
                                        <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                        <option value="Saudi Arabia">Saudi Arabia</option>
                                        <option value="Senegal">Senegal</option>
                                        <option value="Serbia">Serbia</option>
                                        <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                                        <option value="Seychelles">Seychelles</option>
                                        <option value="Sierra Leone">Sierra Leone</option>
                                        <option value="Singapore">Singapore</option>
                                        <option value="Sint Maarten">Sint Maarten</option>
                                        <option value="Slovakia">Slovakia</option>
                                        <option value="Slovenia">Slovenia</option>
                                        <option value="Solomon Islands">Solomon Islands</option>
                                        <option value="Somalia">Somalia</option>
                                        <option value="South Africa">South Africa</option>
                                        <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                        <option value="South Sudan">South Sudan</option>
                                        <option value="Spain">Spain</option>
                                        <option value="Sri Lanka">Sri Lanka</option>
                                        <option value="Sudan">Sudan</option>
                                        <option value="Suriname">Suriname</option>
                                        <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                        <option value="Swaziland">Swaziland</option>
                                        <option value="Sweden">Sweden</option>
                                        <option value="Switzerland">Switzerland</option>
                                        <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                        <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                        <option value="Tajikistan">Tajikistan</option>
                                        <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                        <option value="Thailand">Thailand</option>
                                        <option value="Timor-Leste">Timor-Leste</option>
                                        <option value="Togo">Togo</option>
                                        <option value="Tokelau">Tokelau</option>
                                        <option value="Tonga">Tonga</option>
                                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                        <option value="Tunisia">Tunisia</option>
                                        <option value="Turkey">Turkey</option>
                                        <option value="Turkmenistan">Turkmenistan</option>
                                        <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                        <option value="Tuvalu">Tuvalu</option>
                                        <option value="Uganda">Uganda</option>
                                        <option value="Ukraine">Ukraine</option>
                                        <option value="United Arab Emirates">United Arab Emirates</option>
                                        <option value="United Kingdom">United Kingdom</option>
                                        <option value="United States">United States</option>
                                        <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                        <option value="Uruguay">Uruguay</option>
                                        <option value="Uzbekistan">Uzbekistan</option>
                                        <option value="Vanuatu">Vanuatu</option>
                                        <option value="Venezuela">Venezuela</option>
                                        <option value="Viet Nam">Viet Nam</option>
                                        <option value="Virgin Islands, British">Virgin Islands, British</option>
                                        <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                                        <option value="Wallis and Futuna">Wallis and Futuna</option>
                                        <option value="Western Sahara">Western Sahara</option>
                                        <option value="Yemen">Yemen</option>
                                        <option value="Zambia">Zambia</option>
                                        <option value="Zimbabwe">Zimbabwe</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="nationality" name="nationality" type="text" class="form-control element-block" placeholder="Nationality*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <select id="categories" class="arrow_down" name="categories" style="width: 100%">
                                        <option value="" selected="selected"><?php echo $choose_category->$Title?></option>
                                        @foreach($categories as $category)
                                        <option value="country">{{$category->$Title}}</option>
                                        @endforeach 
                                    </select>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <label for="" style="margin-right: 5px"><?php echo $choose_language->$Title?> :</label>
                                    @foreach($languages as $language)
                                    <label class="checkbox-inline">
                                        <input type="checkbox" id="{{$language->title_en}}" value="{{$language->$Title}}">{{$language->$Title}}
                                    </label>
                                   @endforeach 
                                </div>
                                <div class="form-group col-md-12 col-sm-12" style="display: flex; flex-direction: row; justify-content: flex-start; align-items: center">
                                    <label for="resume" class="col-lg-3" style="text-align: left !important;">Upload Resume :</label>
                                    <div class="file-input-1 col-md-9 col-sm-9">
                                        <input id="resume" name="resume" type="file"
                                               class="form-control element-block">
                                    </div>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <textarea id="message" name="message" class="form-control element-block" placeholder="Your Message"></textarea>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade bd-example-modal-lg" id="teachFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/join-us-en.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">Check our privacy policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
        <section class="contact-block rtl" style="margin-top:10%; margin-bottom: 10%;">
            <div class="container">
                <header class="seperator-head text-center">
                    <h2>  {{$instructor_form_title->$Title}}  </h2>
                </header>
                <!-- contact form -->
                <div class="row" style="display: flex; flex-direction: row; justify-content: center; align-items: center">
                    <div class="col-lg-8">

                        @if(Session::has('success'))


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="margin-top:30vh">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
    
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <img src="{{ url('frontend/images/progArtboard 3.jpg') }}">
      </div>
      
    </div>
  </div>
</div>

<script type="text/javascript">
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
</script>
                            @endif
                        <div style="box-shadow:5px 5px 10px grey;padding: 20px;">
                            <form id="teachForm" action="{{ url('teachForm') }}" method="post" class="contact-form" enctype="multipart/form-data">
                               @csrf
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="first_name"  name="first_name" type="text" class="form-control element-block" placeholder="الإسم الاول*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="last_name" name="last_name" type="text" class="form-control element-block" placeholder="الإسم الأخير*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="number" name="number" type="text" class="form-control element-block" placeholder="رقم الهاتف*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="email" name="email" type="email" class="form-control element-block" placeholder="البريد الإلكتروني*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <select id="country" class="arrow_down" name="country" style="width: 100%">
                                        <option value="" selected="selected">اختر البلد</option>
                                        <option value="Afghanistan">أفغانستان</option>
                                        <option value="Aland Islands">جزر آلاند</option>
                                        <option value="Albania">ألبانيا</option>
                                        <option value="Algeria">الجزائر</option>
                                        <option value="American Samoa">ساموا الأمريكية</option>
                                        <option value="Andorra">أندورا</option>
                                        <option value="Angola">أنغولا</option>
                                        <option value="Anguilla">أنغيلا</option>
                                        <option value="Antarctica">أنتاركتيكا</option>
                                        <option value="Antigua and Barbuda">أنتيغوا وبربودا</option>
                                        <option value="Argentina">الأرجنتين</option>
                                        <option value="Armenia">أرمينيا</option>
                                        <option value="Aruba">أروبا</option>
                                        <option value="Australia">أستراليا</option>
                                        <option value="Austria">النمسا</option>
                                        <option value="Azerbaijan">أذربيجان</option>
                                        <option value="Bahamas">جزر البهاما</option>
                                        <option value="Bahrain">البحرين</option>
                                        <option value="Bangladesh">بنغلاديش</option>
                                        <option value="Barbados">بربادوس</option>
                                        <option value="Belarus">بيلاروسيا</option>
                                        <option value="Belgium">بلجيكا</option>
                                        <option value="Belize">بليز</option>
                                        <option value="Benin">بنين</option>
                                        <option value="Bermuda">برمودا</option>
                                        <option value="Bhutan">بوتان</option>
                                        <option value="Bolivia">بوليفيا</option>
                                        <option value="Bonaire, Sint Eustatius and Saba">بونير وسانت يوستاتيوس وسابا</option>
                                        <option value="Bosnia and Herzegovina">البوسنة والهرسك</option>
                                        <option value="Botswana">بوتسوانا</option>
                                        <option value="Bouvet Island">جزيرة بوفيت</option>
                                        <option value="Brazil">البرازيل</option>
                                        <option value="British Indian Ocean Territory">إقليم المحيط البريطاني الهندي</option>
                                        <option value="Brunei Darussalam">بروناي دار السلام</option>
                                        <option value="Bulgaria">بلغاريا</option>
                                        <option value="Burkina Faso">بوركينا فاسو</option>
                                        <option value="Burundi">بوروندي</option>
                                        <option value="Cambodia">كمبوديا</option>
                                        <option value="Cameroon">الكاميرون</option>
                                        <option value="Canada">كندا</option>
                                        <option value="Cape Verde">الرأس الأخضر</option>
                                        <option value="Cayman Islands">جزر كايمان</option>
                                        <option value="Central African Republic">جمهورية افريقيا الوسطى</option>
                                        <option value="Chad">تشاد</option>
                                        <option value="Chile">تشيلي</option>
                                        <option value="China">الصين</option>
                                        <option value="Christmas Island">جزيرة الكريسماس</option>
                                        <option value="Cocos (Keeling) Islands">جزر كوكوس (كيلينغ)</option>
                                        <option value="Colombia">كولومبيا</option>
                                        <option value="Comoros">جزر القمر</option>
                                        <option value="Congo">الكونغو</option>
                                        <option value="Congo, Democratic Republic of the Congo">الكونغو ، جمهورية الكونغو الديمقراطية</option>
                                        <option value="Cook Islands">جزر كوك</option>
                                        <option value="Costa Rica">كوستا ريكا</option>
                                        <option value="Cote D'Ivoire">ساحل العاج</option>
                                        <option value="Croatia">كرواتيا</option>
                                        <option value="Cuba">كوبا</option>
                                        <option value="Curacao">كوراكاو</option>
                                        <option value="Cyprus">قبرص</option>
                                        <option value="Czech Republic">الجمهورية التشيكية</option>
                                        <option value="Denmark">الدنمارك</option>
                                        <option value="Djibouti">جيبوتي</option>
                                        <option value="Dominica">دومينيكا</option>
                                        <option value="Dominican Republic">جمهورية الدومنيكان</option>
                                        <option value="Ecuador">الاكوادور</option>
                                        <option value="Egypt">مصر</option>
                                        <option value="El Salvador">السلفادور</option>
                                        <option value="Equatorial Guinea">غينيا الإستوائية</option>
                                        <option value="Eritrea">إريتريا</option>
                                        <option value="Estonia">إستونيا</option>
                                        <option value="Ethiopia">أثيوبيا</option>
                                        <option value="Falkland Islands (Malvinas)">جزر فوكلاند (مالفيناس)</option>
                                        <option value="Faroe Islands">جزر فاروس</option>
                                        <option value="Fiji">فيجي</option>
                                        <option value="Finland">فنلندا</option>
                                        <option value="France">فرنسا</option>
                                        <option value="French Guiana">غيانا الفرنسية</option>
                                        <option value="French Polynesia">بولينيزيا الفرنسية</option>
                                        <option value="French Southern Territories">المناطق الجنوبية لفرنسا</option>
                                        <option value="Gabon">الجابون</option>
                                        <option value="Gambia">غامبيا</option>
                                        <option value="Georgia">جورجيا</option>
                                        <option value="Germany">ألمانيا</option>
                                        <option value="Ghana">غانا</option>
                                        <option value="Gibraltar">جبل طارق</option>
                                        <option value="Greece">اليونان</option>
                                        <option value="Greenland">الأرض الخضراء</option>
                                        <option value="Grenada">غرينادا</option>
                                        <option value="Guadeloupe">جوادلوب</option>
                                        <option value="Guam">غوام</option>
                                        <option value="Guatemala">غواتيمالا</option>
                                        <option value="Guernsey">غيرنسي</option>
                                        <option value="Guinea">غينيا</option>
                                        <option value="Guinea-Bissau">غينيا بيساو</option>
                                        <option value="Guyana">غيانا</option>
                                        <option value="Haiti">هايتي</option>
                                        <option value="Heard Island and Mcdonald Islands">قلب الجزيرة وجزر ماكدونالز</option>
                                        <option value="Holy See (Vatican City State)">الكرسي الرسولي (دولة الفاتيكان)</option>
                                        <option value="Honduras">هندوراس</option>
                                        <option value="Hong Kong">هونج كونج</option>
                                        <option value="Hungary">هنغاريا</option>
                                        <option value="Iceland">أيسلندا</option>
                                        <option value="India">الهند</option>
                                        <option value="Indonesia">إندونيسيا</option>
                                        <option value="Iran, Islamic Republic of">جمهورية إيران الإسلامية</option>
                                        <option value="Iraq">العراق</option>
                                        <option value="Ireland">أيرلندا</option>
                                        <option value="Isle of Man">جزيرة آيل أوف مان</option>
                                        <option value="Israel">إسرائيل</option>
                                        <option value="Italy">إيطاليا</option>
                                        <option value="Jamaica">جامايكا</option>
                                        <option value="Japan">اليابان</option>
                                        <option value="Jersey">جيرسي</option>
                                        <option value="Jordan">الأردن</option>
                                        <option value="Kazakhstan">كازاخستان</option>
                                        <option value="Kenya">كينيا</option>
                                        <option value="Kiribati">كيريباتي</option>
                                        <option value="Korea, Democratic People's Republic of">كوريا، الجمهورية الشعبية الديمقراطية</option>
                                        <option value="Korea, Republic of">جمهورية كوريا</option>
                                        <option value="Kosovo">كوسوفو</option>
                                        <option value="Kuwait">الكويت</option>
                                        <option value="Kyrgyzstan">قيرغيزستان</option>
                                        <option value="Lao People's Democratic Republic">جمهورية لاو الديمقراطية الشعبية</option>
                                        <option value="Latvia">لاتفيا</option>
                                        <option value="Lebanon">لبنان</option>
                                        <option value="Lesotho">ليسوتو</option>
                                        <option value="Liberia">ليبيريا</option>
                                        <option value="Libyan Arab Jamahiriya">الجماهيرية العربية الليبية</option>
                                        <option value="Liechtenstein">ليختنشتاين</option>
                                        <option value="Lithuania">ليتوانيا</option>
                                        <option value="Luxembourg">لوكسمبورغ</option>
                                        <option value="Macao">ماكاو</option>
                                        <option value="Macedonia, the Former Yugoslav Republic of">مقدونيا ، جمهورية يوغوسلافيا السابقة</option>
                                        <option value="Madagascar">مدغشقر</option>
                                        <option value="Malawi">ملاوي</option>
                                        <option value="Malaysia">ماليزيا</option>
                                        <option value="Maldives">جزر المالديف</option>
                                        <option value="Mali">مالي</option>
                                        <option value="Malta">مالطا</option>
                                        <option value="Marshall Islands">جزر مارشال</option>
                                        <option value="Martinique">مارتينيك</option>
                                        <option value="Mauritania">موريتانيا</option>
                                        <option value="Mauritius">موريشيوس</option>
                                        <option value="Mayotte">مايوت</option>
                                        <option value="Mexico">المكسيك</option>
                                        <option value="Micronesia, Federated States of">ولايات ميكرونيزيا الموحدة</option>
                                        <option value="Moldova, Republic of">جمهورية مولدوفا</option>
                                        <option value="Monaco">موناكو</option>
                                        <option value="Mongolia">منغوليا</option>
                                        <option value="Montenegro">الجبل الأسود</option>
                                        <option value="Montserrat">مونتسيرات</option>
                                        <option value="Morocco">المغرب</option>
                                        <option value="Mozambique">موزمبيق</option>
                                        <option value="Myanmar">ميانمار</option>
                                        <option value="Namibia">ناميبيا</option>
                                        <option value="Nauru">ناورو</option>
                                        <option value="Nepal">نيبال</option>
                                        <option value="Netherlands">هولندا</option>
                                        <option value="Netherlands Antilles">جزر الأنتيل الهولندية</option>
                                        <option value="New Caledonia">كاليدونيا الجديدة</option>
                                        <option value="New Zealand">نيوزيلاندا</option>
                                        <option value="Nicaragua">نيكاراغوا</option>
                                        <option value="Niger">النيجر</option>
                                        <option value="Nigeria">نيجيريا</option>
                                        <option value="Niue">نيوي</option>
                                        <option value="Norfolk Island">جزيرة نورفولك</option>
                                        <option value="Northern Mariana Islands">جزر مريانا الشمالية</option>
                                        <option value="Norway">النرويج</option>
                                        <option value="Oman">سلطنة عمان</option>
                                        <option value="Pakistan">باكستان</option>
                                        <option value="Palau">بالاو</option>
                                        <option value="Palestinian Territory, Occupied">الأراضي الفلسطينية المحتلة</option>
                                        <option value="Panama">بنما</option>
                                        <option value="Papua New Guinea">بابوا غينيا الجديدة</option>
                                        <option value="Paraguay">باراغواي</option>
                                        <option value="Peru">بيرو</option>
                                        <option value="Philippines">فيلبيني</option>
                                        <option value="Pitcairn">بيتكيرن</option>
                                        <option value="Poland">بولندا</option>
                                        <option value="Portugal">البرتغال</option>
                                        <option value="Puerto Rico">بورتوريكو</option>
                                        <option value="Qatar">دولة قطر</option>
                                        <option value="Reunion">جمع شمل</option>
                                        <option value="Romania">رومانيا</option>
                                        <option value="Russian Federation">الاتحاد الروسي</option>
                                        <option value="Rwanda">رواندا</option>
                                        <option value="Saint Barthelemy">سانت بارتيليمي</option>
                                        <option value="Saint Helena">سانت هيلانة</option>
                                        <option value="Saint Kitts and Nevis">سانت كيتس ونيفيس</option>
                                        <option value="Saint Lucia">القديسة لوسيا</option>
                                        <option value="Saint Martin">القديس مارتن</option>
                                        <option value="Saint Pierre and Miquelon">سانت بيير وميكلون</option>
                                        <option value="Saint Vincent and the Grenadines">سانت فنسنت وجزر غرينادين</option>
                                        <option value="Samoa">ساموا</option>
                                        <option value="San Marino">سان مارينو</option>
                                        <option value="Sao Tome and Principe">ساو تومي وبرينسيبي</option>
                                        <option value="Saudi Arabia">المملكة العربية السعودية</option>
                                        <option value="Senegal">السنغال</option>
                                        <option value="Serbia">صربيا</option>
                                        <option value="Serbia and Montenegro">صربيا والجبل الأسود</option>
                                        <option value="Seychelles">سيشيل</option>
                                        <option value="Sierra Leone">سيرا ليون</option>
                                        <option value="Singapore">سنغافورة</option>
                                        <option value="Sint Maarten">سينت مارتن</option>
                                        <option value="Slovakia">سلوفاكيا</option>
                                        <option value="Slovenia">سلوفينيا</option>
                                        <option value="Solomon Islands">جزر سليمان</option>
                                        <option value="Somalia">الصومال</option>
                                        <option value="South Africa">جنوب أفريقيا</option>
                                        <option value="South Georgia and the South Sandwich Islands">جورجيا الجنوبية وجزر ساندويتش الجنوبية</option>
                                        <option value="South Sudan">جنوب السودان</option>
                                        <option value="Spain">إسبانيا</option>
                                        <option value="Sri Lanka">سيريلانكا</option>
                                        <option value="Sudan">السودان</option>
                                        <option value="Suriname">سورينام</option>
                                        <option value="Svalbard and Jan Mayen">سفالبارد وجان ماين</option>
                                        <option value="Swaziland">سوازيلاند</option>
                                        <option value="Sweden">السويد</option>
                                        <option value="Switzerland">سويسرا</option>
                                        <option value="Syrian Arab Republic">الجمهورية العربية السورية</option>
                                        <option value="Taiwan, Province of China">مقاطعة تايوان الصينية</option>
                                        <option value="Tajikistan">طاجيكستان</option>
                                        <option value="Tanzania, United Republic of">جمهورية تنزانيا المتحدة</option>
                                        <option value="Thailand">تايلاند</option>
                                        <option value="Timor-Leste">تيمور ليشتي</option>
                                        <option value="Togo">توجو</option>
                                        <option value="Tokelau">توكيلاو</option>
                                        <option value="Tonga">تونغا</option>
                                        <option value="Trinidad and Tobago">ترينداد وتوباغو</option>
                                        <option value="Tunisia">تونس</option>
                                        <option value="Turkey">ديك رومى</option>
                                        <option value="Turkmenistan">تركمانستان</option>
                                        <option value="Turks and Caicos Islands">جزر تركس وكايكوس</option>
                                        <option value="Tuvalu">توفالو</option>
                                        <option value="Uganda">أوغندا</option>
                                        <option value="Ukraine">أوكرانيا</option>
                                        <option value="United Arab Emirates">الإمارات العربية المتحدة</option>
                                        <option value="United Kingdom">المملكة المتحدة</option>
                                        <option value="United States">الولايات المتحدة</option>
                                        <option value="United States Minor Outlying Islands">جزر الولايات المتحدة البعيدة الصغرى</option>
                                        <option value="Uruguay">أوروغواي</option>
                                        <option value="Uzbekistan">أوزبكستان</option>
                                        <option value="Vanuatu">فانواتو</option>
                                        <option value="Venezuela">فنزويلا</option>
                                        <option value="Viet Nam">فييت نام</option>
                                        <option value="Virgin Islands, British">جزر العذراء البريطانية</option>
                                        <option value="Virgin Islands, U.s.">جزر فيرجن ، الولايات المتحدة</option>
                                        <option value="Wallis and Futuna">واليس وفوتونا</option>
                                        <option value="Western Sahara">الصحراء الغربية</option>
                                        <option value="Yemen">اليمن</option>
                                        <option value="Zambia">زامبيا</option>
                                        <option value="Zimbabwe">زيمبابوي</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <input id="nationality" name="nationality" type="text" class="form-control element-block" placeholder="الجنسية*" required="required">
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <select id="categories" class="arrow_down" name="categories" style="width: 100%">
                                        <option value="" selected="selected"><?php echo $choose_category->$Title?> </option>
                                        @foreach($categories as $category)
                                        <option value="country">{{$category->$Title}}</option>
                                        @endforeach 

                                    </select>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <label for="" style="margin-right: 5px"><?php echo $choose_language->$Title?>  :</label>
                                    @foreach($languages as $language)
                                    <label class="checkbox-inline" >
                                        <input type="checkbox" id="{{$language->title_en}}" value="{{$language->$Title}}" style="position: static; margin-left: 10px">{{$language->$Title}}
                                    </label>
                                   @endforeach                                     
                                </div>
                                <div class="form-group col-md-12 col-sm-12" style="display: flex; flex-direction: row; justify-content: flex-start; align-items: center">
                                    <label for="resume" class="col-lg-2" style="text-align: right !important;">السيرة الذاتية :</label>
                                    <div class="file-input-1 col-md-10 col-sm-10">
                                        <input id="resume" name="resume" type="file"
                                               class="form-control element-block">
                                    </div>
                                </div>
                                <div class="form-group col-md-12 col-sm-12">
                                    <textarea id="message" name="message" class="form-control element-block" placeholder="رسالتك"></textarea>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">ارسال</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade bd-example-modal-lg" id="teachFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="{{ url('frontend/images/reports/join-us-ar.jpeg') }}">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <a class="btn btn-theme btn-warning text-uppercase fw-bold" href="{{ url('/aljhood/privacy-policy') }}" target="_blank">تحقق من سياسة الخصوصية</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif


@stop

@section('scripts')
    <script>

        $('#teachForm').submit(function (){

            var english = document.getElementById("english");
            if(english.checked == true){
                english = $('#english').val();
            }else{
                english = '';
            }

            var arabic = document.getElementById("arabic");
            if(arabic.checked == true){
                arabic = $('#arabic').val();
            }else{
                arabic = '';
            }

            var french = document.getElementById("french");
            if(french.checked == true){
                french = $('#french').val();
            }else{
                french = '';
            }

            var languages = english + ',' + arabic + ',' + french;

            var resume = $('input[type=file]')[0].files[0];

            var formData = new FormData();
            var url = $('meta[name=base_url]').attr("content");
            var csrf_token = $('meta[name=csrf_token]').attr("content");
            formData.append("report_type", "teach");
            formData.append("first_name", $('#first_name').val());
            formData.append("last_name", $('#last_name').val());
            formData.append("number", $('#number').val());
            formData.append("email", $('#email').val());
            formData.append("resume", resume);
            formData.append("country", $('#country').val());
            formData.append("nationality", $('#nationality').val());
            formData.append("categories", $('#categories').val());
            formData.append("languages", languages);
            formData.append("message", $('#message').val());
            formData.append("_token", csrf_token);
            // console.log(formData);

            $.ajax({
                url: url+'/teachForm',
                type: 'post',
                data: formData,
                cache : false,
                processData: false,
                contentType: false,
                success: function(){
                    console.log('Yes');
                    $('#teachFormModal').modal('show');
                    $("#teachForm")[0].reset();
                },
                error: function (){
                    console.log('error');
                }
            });
        })
    </script>
@stop
