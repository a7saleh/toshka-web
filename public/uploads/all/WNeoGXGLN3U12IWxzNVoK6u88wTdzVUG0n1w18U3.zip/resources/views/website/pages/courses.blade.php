<!------------------------- about us content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.courses'))

@section('content')

    @if($checkLang == 1)
        @php
            $lang = 1;
        @endphp
    @endif
<?php
$Title="title_".app()->getLocale();
$Home_page_aljhood_search_button_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_search_button_title')->first();
$Home_page_aljhood_reset_button_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_reset_button_title')->first();
$training_search_course_title=DB::table('page_contents')->where('ref_page','training_search_course_title')->first();
$training_all_course_button=DB::table('page_contents')->where('ref_page','training_all_course_button')->first();

$search_course_form_subject=DB::table('page_contents')->where('ref_page','search_course_form_subject')->first();
$search_course_form_time=DB::table('page_contents')->where('ref_page','search_course_form_time')->first();
$search_course_form_activity_type=DB::table('page_contents')->where('ref_page','search_course_form_activity_type')->first();
$search_course_form_activity_place=DB::table('page_contents')->where('ref_page','search_course_form_activity_place')->first();
$search_course_form_activity_accreditation=DB::table('page_contents')->where('ref_page','search_course_form_activity_accreditation')->first();
$Home_page_aljhood_find_course_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_find_course_title')->first();


?>

    @if(app()->getLocale() == "en")

        <div class="gallery holder"
             style="background-color: #2B2B2B; background-repeat: no-repeat; background-size: cover;">

            <div class="container-fluid filter-gallery">
                <div class="row" style="margin-top:3% ; background-color: #2b2b2b">
                    <!-- course search aside -->
                                <form action="{{ url('filterCourse') }}" method="GET" class="container-fluid course-search-form" autocomplete="off">
                <header class="popular-posts-head">
                    <div class="container">
                    <h2 class="popular-head-heading hr_head text-left" style="text-transform: none"><?php echo $Home_page_aljhood_find_course_title->title_en;?> </h2>
                </div></header>
                <div class="form-holder">
                    <div class="form-row">
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en searchable-select" name="subject_area">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_subject->title_en}}</option>
                                @foreach($subject_area as $sub)
                                    <option value="{{ $sub->subject_area }}">{{ $sub->subject_area }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="input-date" style="height: 46px">
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato ul-height" style="width: 100%">
                                    <li class="dropdown li-height select-arrow select-arrow-en" style="margin: 0 !important; padding: 0 !important; width: 100%">
                                        <a href="javascript:void(0)" class="a-height" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false" style="color: #888 ;  font-size: 14px; font-weight: normal; text-transform: none; text-align: left; padding: 10px 2px ; background: #fff ; width: 100%"><span> {{$search_course_form_time->title_en}}</span></a>
                                        <ul class="dropdown-menu" id="dropdownCustom">
                                            <input type="checkbox" id="available1" value="now" name="available[]">
                                            <label for="available1"> Available now</label>
                                            <br>
                                            <input type="checkbox" id="available2" value="next_week" name="available[]">
                                            <label for="available2"> Within next week</label>
                                            <br>
                                            <input type="checkbox" id="available3" value="next_month" name="available[]">
                                            <label for="available3"> Within next month</label>
                                            <br>
                                            <input type="checkbox" id="available4" value="three_months" name="available[]">
                                            <label for="available4"> Within 3 months</label>
                                            <br>
                                            <input type="checkbox" id="available5" value="sixth_months" name="available[]">
                                            <label for="available5"> Within 6 months</label>
                                            <input type="text" name="available_date" style="height: 45px" placeholder="Start Date" min="{{ \Carbon\Carbon::now()->toDateString() }}" onfocus="(this.type='date')">
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en none-searchable-select" name="venue">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_place->title_en}}</option>
                                @foreach($venue as $ven)
                                    <option value="{{ $ven->venue }}">{{ $ven->venue }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="direction:rtl!important;" >
                            <select style="direction:rtl!important;"  class="arrow_down select-arrow select-arrow-en none-searchable-select" name="activity_type">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_type->title_en}}</option>
                                @foreach($activity_type as $act)
                                    <option style="direction:rtl!important;" value="{{ $act->activity_type }}">{{ $act->activity_type }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en none-searchable-select" name="accreditation">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_accreditation->title_en}}</option>
                                @foreach($accreditation as $acc)
                                    <option value="{{ $acc->name }}">{{ $acc->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="display: flex; flex-direction: row;">
                            <button type="submit" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-6 col-sm-6 col-xs-6">{{$Home_page_aljhood_search_button_title->title_en}}</button>
                            <button type="reset" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-6 col-sm-6 col-xs-6">{{$Home_page_aljhood_reset_button_title->title_en}}</button>
                        </div>
                    </div>
                </div>
            </form>

                </div>
            </div>
        </div>
        <!-- Courses -->
        <?php
        function calDate($date){
            $current    = \Carbon\Carbon::now();
            $start_date = $date;
            $earlier    = new DateTime($current);
            $later      = new DateTime($start_date);
            $abs_diff  = $later->diff($earlier)->format("%a");
            $abs_diff2 = $later->diff($earlier)->format("%m");
            $abs_diff3 = $later->diff($earlier)->format("%y");
            if(\Carbon\Carbon::now() > \Carbon\Carbon::parse($start_date)){
                echo '';
            }elseif ($abs_diff3 == 0) {
                if ($abs_diff2 == 0) {
                    if ($abs_diff == 0) {
                        echo 'Available now';
                    }else{
                        if($abs_diff <= 7){
                            if ($abs_diff > 1) {
                                echo 'Available Now';
                            }else{
                                if ($abs_diff == 1) {
                                    echo 'Available Now';
                                }
                            }
                        }elseif ($abs_diff > 7 && $abs_diff <= 8) {
                            echo 'Within Next Week';
                        }elseif ($abs_diff > 8 && $abs_diff <= 31){
                            echo 'Within Next Month';
                        }else{
                            echo 'Within Next Month';
                        }
                    }
                }elseif ($abs_diff >= 8 && $abs_diff <= 30){
                    echo 'Within Next Month';
                }elseif ($abs_diff2 == 1 || $abs_diff2 == 2 || $abs_diff2 == 3){
                    echo 'Within Three Months';
                }elseif ($abs_diff >= 3 && $abs_diff <= 6){
                    echo 'Within Six Months';
                }elseif ($abs_diff2 > 6 ){
                    echo 'Within Six Months';
                }else{
                    echo 'Within Six Months';
                }
            }else{
                echo 'Within Six Months';
            }
        }
        ?>
        @if(count($courses) !=0 )
            <div id="two-columns" class="container">
                <div class="row">
                    <!-- content -->
                    <article id="content" class="col-xs-12 col-md-12 courses-pages">
                        <!-- show head -->
                        <div class="row flex-wrap">
                            @php
                                $courseDuration = 1000;
                                $counter = 0 ;
                            @endphp
                            @foreach($courses as $course)
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-duration="{{ $courseDuration + $counter }}" data-aos-easing="ease-in-out">
                                    <div class="alignright contentRightImage">
                                        <button onclick="compare({{ $course->id }}, '{{ $course->subject_area }}')" class="add-to-compare"
                                                id="addCompare_{{ $course->id }}">
                                            <strong class="text-white font-lato text-uppercase price-tag">Compare <i
                                                    class="fas fa-square"></i></strong>
                                        </button>
                                        <button onclick="removeCompare({{ $course->id }})"
                                                class="remove-from-compare display-none"
                                                id="removeCompare_{{ $course->id }}">
                                            <strong class="text-white font-lato text-uppercase price-tag">Compare <i
                                                    class="fas fa-check-square"></i></strong>
                                        </button>
                                        <a href="{{ url('course') }}/{{$course->id}}">
                                            <img src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}"
                                                 alt="image description">
                                            <div class="imageCaption" onclick="courseFunction({{ $course->id }})">
                                                <h3 class="post-heading"  style="direction:rtl!important;"><a
                                                        href="{{ url('course') }}/{{$course->id}}">
                                                        {{ $course->title_en }}</a></h3>

                                            </div>
                                        </a>
                                    </div>
                                </div>
                                @php
                                    $counter = 200;
                                    if ($courseDuration > 2000){
                                        $courseDuration = 2000;
                                    }else{
                                        $courseDuration = $courseDuration + $counter;
                                    }
                                @endphp
                            @endforeach
                        </div>
                        @if($links == 1)
                            <div style="display: flex; flex-direction: row; justify-content: center;">
                                <div style="text-align: center;">{{ $courses->links() }}</div>
                            </div>
                        @endif
                        @if($links == 1)
                            <div class="pt-15" style="display: flex; flex-direction: row; justify-content: center;">
                                <div style="text-align: center;"> {{ $courses->lastItem() }}
                                    of {{ $courses->total() }} Courses.
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="{{ url('aljhood/coursesAll') }}"
                                       class="btn btn-theme btn-warning no-shrink text-uppercase">{{$training_all_course_button->$Title}}</a>
                                </div>
                            </div>
                        @endif
                    </article>
                    <!-- sidebar -->
                </div>
            </div>
        @else
            <div id="two-columns" class="container">
                <div class="row">
                    <!-- content -->
                    <article id="content" class="col-xs-12 col-md-12">
                        <!-- show head -->
                        <div class="row">
                            @if($subject_area_request == 'faked' && $venue_request == 'faked' && $date_request == 'faked' && $activity_type_request == 'faked' && $accreditation_request == 'faked' && empty($available))
                                <div class="alert alert-dark text-center" role="alert">
                                    Please select at least one search option
                                </div>
                            @else
                                <div class="alert alert-dark text-center" role="alert">
                                    No courses found Related to your search, Try selecting another option
                                </div>
                            @endif
                        </div>
                    </article>
                    <!-- sidebar -->
                </div>
            </div>
        @endif


        <div class="gallery holder compare-courses-section display-none"
             style="background-color: rgba(43 ,43 ,43 ,0.7); background-repeat: no-repeat; background-size: cover; position: fixed; bottom: 0; width: 100%; z-index: 999">

            <div class="filter-gallery" style="padding: 0 50px">
                <div class="row" style="padding: 10px 0">

                    <form id="h22" action="{{ url('compare') }}" method="GET" class="compare-form">
                        @csrf
                        <div class="form-header"
                             style="display: flex; flex-direction: row; align-items: center; justify-content: space-between">
                            <h2 style="color: white; font-size: 30px; margin-top: 0; margin-bottom: 10px ; padding: 0 15px">
                                Compare up to three
                                programs
                            </h2>
                            <div class="form-group" style="margin-right: 15px">
                                <button class="btn btn-block btn-primary filter_courses filter_gallery_btn compare-btn"
                                        type="submit" style="color: #222222 ; font-weight: bolder ;">COMPARE
                                </button>
                            </div>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_1">x</span>
                            <span class="sub-after display-none" id="course_s_1"></span>
                            <select class="arrow_down course-dropdown" id="course_select_1" name="course-select-1"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course1" style="display: none"><span>Course 1</span>
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}">
                                        {{ $course->title_en }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_2">x</span>
                            <span class="sub-after2 display-none" id="course_s_2"></span>
                            <select class="arrow_down course-dropdown" id="course_select_2" name="course-select-2"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course2" style="display: none">
                                    Course 2
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}"
                                            style="display: none"> {{ $course->title_en }}  </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_3">x</span>
                            <span class="sub-after3 display-none" id="course_s_3"></span>
                            <select class="arrow_down course-dropdown" id="course_select_3" name="course-select-3"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course3" style="display: none">
                                    Course 3
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}"
                                            style="display: none"> {{ $course->title_en }} </option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @else
        <div class="gallery holder rtl"
             style="background-color: #2B2B2B; background-repeat: no-repeat; background-size: cover;">

            <div class="container-fluid filter-gallery">
                <div class="row" style="margin-top:13% ; background-color: #2b2b2b">
                    <!-- course search aside -->
            <form action="{{ url('filterCourse') }}" method="GET" class="container-fluid course-search-form" autocomplete="off">
                <header class="popular-posts-head">
                    <div class="container">
                    <h2 class="popular-head-heading hr_head text-right" style="text-transform: none"><?php echo $Home_page_aljhood_find_course_title->title_ar;?> </h2>
                </div>
                </header>
                <div class="form-holder">
                    <div class="form-row">
                        <div class="form-group">
                            <select class="arrow_down select-arrow searchable-select" name="subject_area">
                                <option value="" selected="selected">{{$search_course_form_subject->title_ar}}</option>
                                @foreach($subject_area as $sub)
                                    <option value="{{ $sub->subject_area_ar }}">{{ $sub->subject_area_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="input-date" style="height: 46px">
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato ul-height" style="width: 100% ; text-align: right ;padding: 0 10px 0 0;">
                                    <li class="dropdown li-height select-arrow" style="margin: 0 !important; padding: 0 !important; width: 100%">
                                        <a href="javascript:void(0)" class="a-height" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false" style="color: #888 ;  font-size: 14px; font-weight: normal; text-transform: none; text-align: right; background: #fff ; width: 100%"><span> {{$search_course_form_time->title_ar}} </span></a>
                                        <ul class="dropdown-menu" style="text-align: right ; left: 0;" id="dropdownCustom">
                                            <input type="checkbox" id="available1" value="now" name="available[]">
                                            <label for="available1"> متوفر الآن</label><br>
                                            <input type="checkbox" id="available2" value="next_week" name="available[]">
                                            <label for="available2">خلال الأسبوع المقبل</label><br>
                                            <input type="checkbox" id="available3" value="next_month" name="available[]">
                                            <label for="available3"> خلال الشهر القادم</label><br>
                                            <input type="checkbox" id="available4" value="three_months" name="available[]">
                                            <label for="available4"> خلال 3 أشهر القادمة</label><br>
                                            <input type="checkbox" id="available5" value="sixth_months" name="available[]">
                                            <label for="available5"> خلال 6 أشهر القادمة</label>
{{--                                            <br>--}}
{{--                                            <input type="checkbox" id="available6" value="next_year" name="available[]">--}}
{{--                                            <label for="available6"> خلال العام المقبل</label><br>--}}
                                            <input type="text" name="available_date" style="height: 45px"
                                                   placeholder="وقت الدورة" min="{{ \Carbon\Carbon::now()->toDateString() }}" onfocus="(this.type='date')">
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow none-searchable-select" name="venue">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_place->title_ar}}</option>
                                @foreach($venue as $ven)
                                    <option value="{{ $ven->venue_ar }}">{{ $ven->venue_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="direction:rtl!important;" >
                            <select style="direction:rtl!important;"  class="arrow_down select-arrow none-searchable-select" name="activity_type">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_type->title_ar}} </option>
                                @foreach($activity_type as $act)
                                    <option style="direction:rtl!important;" value="{{ $act->activity_type_ar }}">{{ $act->activity_type_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow none-searchable-select ltr" name="accreditation">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_accreditation->title_ar}}</option>
                                @foreach($accreditation as $acc)
                                    <option value="{{ $acc->name_ar }}">{{ $acc->name_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="display: flex; flex-direction: row;">
                            <button type="submit" class="btn btn-theme btn-warning no-shrink text-uppercase">{{$Home_page_aljhood_search_button_title->title_ar}}</button>
                            <button type="reset" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-12 col-sm-8 col-xs-8">{{$Home_page_aljhood_reset_button_title->title_ar}}</button>
                        </div>
                    </div>
                </div>
            </form>
                </div>
            </div>
        </div>
        <!-- Courses -->
        <?php
            function calDateAr($date){
                $current    = \Carbon\Carbon::now();
                $start_date = $date;
                $earlier    = new DateTime($current);
                $later      = new DateTime($start_date);
                $abs_diff  = $later->diff($earlier)->format("%a");
                $abs_diff2 = $later->diff($earlier)->format("%m");
                $abs_diff3 = $later->diff($earlier)->format("%y");
                if(\Carbon\Carbon::now() > \Carbon\Carbon::parse($start_date)){
                    echo '';
                }elseif ($abs_diff3 == 0) {
                    if ($abs_diff2 == 0) {
                        if ($abs_diff == 0) {
                            echo 'متاح الآن';
                        }else{
                            if($abs_diff <= 7){
                                if ($abs_diff > 1) {
                                    echo 'متاح الآن';
                                }else{
                                    if ($abs_diff == 1) {
                                        echo 'متاح الآن';
                                    }
                                }
                            }elseif ($abs_diff > 7 && $abs_diff <= 8) {
                                echo 'خلال الأسبوع المقبل';
                            }elseif ($abs_diff > 8 && $abs_diff <= 31){
                                echo 'خلال الشهر القادم';
                            }else{
                                echo 'خلال الشهر القادم';
                            }
                        }
                    }elseif ($abs_diff >= 8 && $abs_diff <= 30){
                        echo 'خلال الشهر القادم';
                    }elseif ($abs_diff2 == 1 || $abs_diff2 == 2 || $abs_diff2 == 3){
                        echo 'خلال 3 أشهر القادمة';
                    }elseif ($abs_diff2 >= 3 && $abs_diff2 <= 6){
                        echo 'خلال 6 أشهر القادمة';
                    }elseif ($abs_diff2 > 6 ){
                        echo 'خلال 6 أشهر القادمة ';
                    }else{
                        echo 'خلال 6 أشهر القادمة';
                    }
                }else{
                    echo 'خلال 6 أشهر القادمة ';
                }
            }
        ?>

        @if(count($courses) !=0)
            <div id="two-columns" class="container rtl">
                <div class="row">
                    <!-- content -->
                    <article id="content" class="col-xs-12 col-md-12 courses-pages">
                        <!-- show head -->
                        <div class="row flex-wrap">
                            @php
                                $courseDuration = 1000;
                                $counter = 0 ;
                            @endphp
                            @foreach($courses as $course)
                                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-duration="{{ $courseDuration + $counter }}" data-aos-easing="ease-in-out">
                                    <div class="alignright contentRightImage">
                                        <button onclick="compare({{ $course->id }} , '{{ $course->subject_area_ar }}')" class="add-to-compare"
                                                id="addCompare_{{ $course->id }}">
                                            <strong class="text-white font-lato text-uppercase price-tag"> مقارنة <i
                                                    class="fas fa-square"></i></strong>
                                        </button>
                                        <button onclick="removeCompare({{ $course->id }})"
                                                class="remove-from-compare display-none"
                                                id="removeCompare_{{ $course->id }}">
                                            <strong class="text-white font-lato text-uppercase price-tag"> مقارنة <i
                                                    class="fas fa-check-square"></i></strong>
                                        </button>
                                        <a href="{{ url('course') }}/{{$course->id}}">

                                        <img src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}"
                                             alt="image description">
                                        <div class="imageCaption" onclick="courseFunction({{ $course->id }})">
                                                <h3 class="post-heading"  style="direction:rtl!important;"><a
                                                    href="{{ url('course') }}/{{$course->id}}">
                                                    {{$course->title_ar}}</a></h3>

                                        </div></a>
                                    </div>
                                </div>
                                @php
                                    $counter = 200;
                                     if ($courseDuration > 2000){
                                         $courseDuration = 2000;
                                     }else{
                                         $courseDuration = $courseDuration + $counter;
                                     }
                                @endphp
                            @endforeach
                        </div>
                        @if($links == 1)
                            <div style="display: flex; flex-direction: row; justify-content: center;">
                                <div style="text-align: center;">{{ $courses->links() }}</div>
                            </div>
                        @endif
                        @if($links == 1)
                            <div class="pt-15" style="display: flex; flex-direction: row; justify-content: center;">
                                <div style="text-align: center;"> {{ $courses->lastItem() }} من {{ $courses->total() }}
                                    دورة .
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="{{ url('aljhood/coursesAll') }}"
                                       class="btn btn-theme btn-warning no-shrink text-uppercase">{{$training_all_course_button->$Title}}</a>
                                </div>
                            </div>
                        @endif
                    </article>
                    <!-- sidebar -->
                </div>
            </div>
        @else
            <div id="two-columns" class="container rtl">
                <div class="row">
                    <!-- content -->
                    <article id="content" class="col-xs-12 col-md-12">
                        <!-- show head -->
                        <div class="row">
                            @if($subject_area_request == 'faked' && $venue_request == 'faked' && $date_request == 'faked' && $activity_type_request == 'faked' && $accreditation_request == 'faked'  && empty($available))
                                <div class="alert alert-dark text-center" role="alert">
                                    يرجى تحديد خيار بحث واحد على الأقل
                                </div>
                            @else
                                <div class="alert alert-dark text-center" role="alert">
                                    لم يتم العثور على دورات ذات صلة ببحثك ، حاول تحديد خيار آخر
                                </div>
                            @endif
                        </div>
                    </article>
                    <!-- sidebar -->
                </div>
            </div>
        @endif

        <div class="gallery holder compare-courses-section display-none"
             style="background-color: rgba(43 ,43 ,43 ,0.7); background-repeat: no-repeat; background-size: cover; position: fixed; bottom: 0; width: 100%; z-index: 999">

            <div class="filter-gallery rtl" style="padding: 0 50px">
                <div class="row" style="padding: 10px 0">

                    <form id="h22" action="{{ url('compare') }}" method="GET" class="compare-form">
                        @csrf
                        <div class="form-header"
                             style="display: flex; flex-direction: row; align-items: center; justify-content: space-between">
                            <h2 style="color: white; font-size: 30px; margin-top: 0; margin-bottom: 10px ; padding: 0 15px">
                                قارن
                            </h2>
                            <div class="form-group" style="margin-left: 15px">
                                <button class="btn btn-block btn-primary filter_courses filter_gallery_btn compare-btn" type="submit" style="color: #222222; font-weight: bolder">قارن
                                </button>
                            </div>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_3">x</span>
                            <span class="sub-after3 display-none" id="course_s_3">تصميم فني</span>
                            <select class="arrow_down course-dropdown" id="course_select_3" name="course-select-3"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course3" style="display: none">
                                    Course 3
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}"
                                            style="display: none"> {{ $course->title_ar }} </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_2">x</span>
                            <span class="sub-after2 display-none" id="course_s_2">أعمال</span>
                            <select class="arrow_down course-dropdown" id="course_select_2" name="course-select-2"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course2" style="display: none">
                                    Course 2
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}"
                                            style="display: none"> {{ $course->title_ar }}  </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <span class="compare-after" id="course_x_1">x</span>
                            <span class="sub-after display-none" id="course_s_1">علم الحاسوب</span>
                            <select class="arrow_down course-dropdown" id="course_select_1" name="course-select-1"
                                    style="pointer-events: none;touch-action: none" tabindex="-1">
                                <option value="0" selected="selected" name="course1" style="display: none"><span>Course 1</span>
                                </option>
                                @foreach($coursesDropDown as $course)
                                    <option value="{{ $course->id }}">
                                        {{ $course->title_ar }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif


@stop



@section('scripts')

    <script>
        var url = $('meta[name=base_url]').attr("content");
        @if(app()->getLocale() == "en")

            window.onload = function () {

            if (localStorage.getItem('course_select_1') !== null) {

                var course_1 = localStorage.getItem('course_select_1');
                var courseSub_1 = localStorage.getItem('course_sub_1');
                compare(course_1 , courseSub_1)

            }
            if (localStorage.getItem('course_select_2') !== null) {

                var course_2 = localStorage.getItem('course_select_2');
                var courseSub_2 = localStorage.getItem('course_sub_2');
                compare(course_2 , courseSub_2)

            }
            if (localStorage.getItem('course_select_3') !== null) {

                var course_3 = localStorage.getItem('course_select_3');
                var courseSub_3 = localStorage.getItem('course_sub_3');
                compare(course_3 , courseSub_3)

            }

        }

        function compare(id , sub) {

            var course_select_1 = $('#course_select_1').find(":selected").val();
            var course_select_2 = $('#course_select_2').find(":selected").val();
            var course_select_3 = $('#course_select_3').find(":selected").val();


            if (course_select_1 == 0) {

                $('#course_s_1').text(sub);



                var element = $('#course_select_1');
                $('#course_x_1').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_1');
                    localStorage.removeItem('course_sub_1');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_1').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_1').removeClass('display-none');

                localStorage.setItem('course_select_1', id);
                localStorage.setItem('course_sub_1', sub);

            } else if (course_select_2 == 0) {
                $('#course_s_2').text(sub);


                var element = $('#course_select_2');
                $('#course_x_2').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_2');
                    localStorage.removeItem('course_sub_2');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_2').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_2').removeClass('display-none');

                localStorage.setItem('course_select_2', id);
                localStorage.setItem('course_sub_2', sub);


            } else if (course_select_3 == 0) {
                $('#course_s_3').text(sub);


                var element = $('#course_select_3');
                $('#course_x_3').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_3');
                    localStorage.removeItem('course_sub_3');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_3').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_3').removeClass('display-none');

                localStorage.setItem('course_select_3', id);
                localStorage.setItem('course_sub_3', sub);


            } else {
                alert('You already have the maximum number of courses to compare , please remove a course to add this one.');
            }

        }


        function removeCompare(id) {

            var course_select_1 = $('#course_select_1').find(":selected").val();
            var course_select_2 = $('#course_select_2').find(":selected").val();
            var course_select_3 = $('#course_select_3').find(":selected").val();
            if (course_select_1 == 0 && course_select_2 == 0) {
                $('.compare-courses-section').addClass('display-none')
            } else if (course_select_2 == 0 && course_select_3 == 0) {
                $('.compare-courses-section').addClass('display-none')
            } else if (course_select_1 == 0 && course_select_3 == 0) {
                $('.compare-courses-section').addClass('display-none')
            }


            if (course_select_1 == id) {

                localStorage.removeItem('course_select_1');
                localStorage.removeItem('course_sub_1');


                var element = $('#course_select_1');

                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_1').addClass('display-none');


            } else if (course_select_2 == id) {
                localStorage.removeItem('course_select_2');
                localStorage.removeItem('course_sub_2');


                var element = $('#course_select_2');
                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_2').addClass('display-none');

            } else if (course_select_3 == id) {
                localStorage.removeItem('course_select_3');
                localStorage.removeItem('course_sub_3');


                var element = $('#course_select_3');
                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_3').addClass('display-none');

            } else {
                alert('You already have the maximum number of courses to compare , please remove a course to add this one.');
            }

        }

        @else

            window.onload = function () {

            if (localStorage.getItem('course_select_1') !== null) {

                var course_1 = localStorage.getItem('course_select_1');
                var courseSub_1 = localStorage.getItem('course_sub_1');
                compare(course_1 , courseSub_1)

            }
            if (localStorage.getItem('course_select_2') !== null) {

                var course_2 = localStorage.getItem('course_select_2');
                var courseSub_2 = localStorage.getItem('course_sub_2');
                compare(course_2 , courseSub_2)

            }
            if (localStorage.getItem('course_select_3') !== null) {

                var course_3 = localStorage.getItem('course_select_3');
                var courseSub_3 = localStorage.getItem('course_sub_3');
                compare(course_3 , courseSub_3)

            }
        }


        function compare(id , sub) {


            var course_select_1 = $('#course_select_1').find(":selected").val();
            var course_select_2 = $('#course_select_2').find(":selected").val();
            var course_select_3 = $('#course_select_3').find(":selected").val();


            if (course_select_1 == 0) {

                $('#course_s_1').text(sub);


                var element = $('#course_select_1');
                $('#course_x_1').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_1');
                    localStorage.removeItem('course_sub_1');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_1').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_1').removeClass('display-none');
                localStorage.setItem('course_select_1', id);
                localStorage.setItem('course_sub_1', sub);


            } else if (course_select_2 == 0) {

                $('#course_s_2').text(sub);

                var element = $('#course_select_2');
                $('#course_x_2').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_2');
                    localStorage.removeItem('course_sub_2');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_2').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_2').removeClass('display-none');


                localStorage.setItem('course_select_2', id);
                localStorage.setItem('course_sub_2', sub);

            } else if (course_select_3 == 0) {
                $('#course_s_3').text(sub);


                var element = $('#course_select_3');
                $('#course_x_3').click(function () {
                    var course_select_1 = $('#course_select_1').find(":selected").val();
                    var course_select_2 = $('#course_select_2').find(":selected").val();
                    var course_select_3 = $('#course_select_3').find(":selected").val();
                    localStorage.removeItem('course_select_3');
                    localStorage.removeItem('course_sub_3');
                    if (course_select_1 == 0 && course_select_2 == 0 && course_select_3 == 0) {
                        $('.compare-courses-section').addClass('display-none')
                    }
                    if (localStorage.getItem('course_select_1') === null && localStorage.getItem('course_select_2') === null && localStorage.getItem('course_select_3') === null) {
                        $('.compare-courses-section').addClass('display-none');
                    }
                    element.val(0);
                    $('#addCompare_' + id).removeClass('display-none');
                    $('#removeCompare_' + id).addClass('display-none');
                    $('#course_s_3').addClass('display-none');
                });
                element.val(id);
                $('#addCompare_' + id).addClass('display-none');
                $('#removeCompare_' + id).removeClass('display-none');
                $('.compare-courses-section').removeClass('display-none');
                $('#course_s_3').removeClass('display-none');

                localStorage.setItem('course_select_3', id);
                localStorage.setItem('course_sub_3', sub);


            } else {
                alert('لديك بالفعل الحد الأقصى لعدد الدورات للمقارنة ، يرجى إزالة دورة لإضافة هذه الدورة.');
            }

        }


        function removeCompare(id) {

            var course_select_1 = $('#course_select_1').find(":selected").val();
            var course_select_2 = $('#course_select_2').find(":selected").val();
            var course_select_3 = $('#course_select_3').find(":selected").val();

            if (course_select_1 == 0 && course_select_2 == 0) {
                $('.compare-courses-section').addClass('display-none')
            } else if (course_select_2 == 0 && course_select_3 == 0) {
                $('.compare-courses-section').addClass('display-none')
            } else if (course_select_1 == 0 && course_select_3 == 0) {
                $('.compare-courses-section').addClass('display-none')
            }
            if (course_select_1 == id) {

                localStorage.removeItem('course_select_1');
                localStorage.removeItem('course_sub_1');


                var element = $('#course_select_1');

                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_1').addClass('display-none');


            } else if (course_select_2 == id) {
                localStorage.removeItem('course_select_2');
                localStorage.removeItem('course_sub_2');


                var element = $('#course_select_2');
                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_2').addClass('display-none');

            } else if (course_select_3 == id) {
                localStorage.removeItem('course_select_3');
                localStorage.removeItem('course_sub_3');


                var element = $('#course_select_3');
                element.val(0);
                $('#addCompare_' + id).removeClass('display-none');
                $('#removeCompare_' + id).addClass('display-none');
                $('#course_s_3').addClass('display-none');

            } else {
                alert('لديك بالفعل الحد الأقصى لعدد الدورات للمقارنة ، يرجى إزالة دورة لإضافة هذه الدورة.');
            }

        }
        @endif

    </script>

@stop
