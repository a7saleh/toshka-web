<!------------------------- consultancy page  content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.consultancy'))

@section('content')

    <?php  
    if(app()->getLocale() == "en"){
        $dir="ltr";
        $order="asc";
    }else{
        $dir="rtl";  
        $order="desc";
    }
$banner=DB::table('page_contents')->where('ref_page','=','consultancy_banner')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
$Title="title_".app()->getLocale();
$Description="description_".app()->getLocale();
$consultation_types_title=DB::table('page_contents')->where('ref_page','consultation_types_title')->first();
$consultation_partners_title=DB::table('page_contents')->where('ref_page','consultation_partners_title')->first();
$consultation_contact_us_title=DB::table('page_contents')->where('ref_page','consultation_contact_us_title')->first();

?>


        <!-- heading banner -->
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        
     @if(app()->getLocale()=="ar")
     <div class="container section_about text-right rtl">

                <nav class="breadcrumb-nav gall-bread">
                    <div class="container">
                        <!-- breadcrumb -->
                        <ol class="breadcrumb">
                            <li><a href="{{ url('/') }}">الرئيسية</a></li>
                            <li class="active"> الاستشارات</li>
                        </ol>
                    </div>
                </nav>
@else
<div class="container section_about text-center">

        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">@lang('Home')</a></li>
                    <li class="active">Consultancy</li>
                </ol>
            </div>
        </nav>
@endif   



      <section id="values" class="values mb-5 mt-5">
      <div class="container" data-aos="fade-up">
          
                    
        <?php $consultation_types=DB::table('page_contents')->where('ref_page','=','consultancy')->get()?>
        @foreach($consultation_types as $content)
          
          <br><div class="row mb-5">
              <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
                  
            <div class="col-lg-10" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <h1 class="gold-color">@php echo $content->$Title; @endphp</h1>
              <p><strong>@php echo $content->$Description; @endphp</strong></p>
    @if(!empty($content->image) || !empty($content->video))
                
    @if(!empty($content->image))
        <img  src="{{ asset('frontend/images/consultant') }}/{{ $content->image }}" class="element-block image"  alt="no-photo">
    @else
        <iframe  src="{{ $content->video }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    @endif 
    @endif
            </div>
          </div>
          <div class="col-lg-1" data-aos="fade-up" data-aos-delay="200"></div>
          </div>

@endforeach        
          
      </div>
    </section><br><br>


        <section class="container-fluid consultant-types text-center {{$dir}}">
            <div class="row">
                <header class="seperator-head">
                    <h2 class="text-center">{{$consultation_types_title->$Title}}</h2>
                </header>
                <br><br><br><div class="steps-guide-holder">
                    
                    <?php 
                    
                    $consultation_types=DB::table('page_contents')->where('ref_page','consultancy_type')->orderBy('id','desc')->get(); 
                 
                    ?>
                    
                    @foreach($consultation_types as $consultation_type)
                    <div class=" div-consultaion-type col-xs-12  col-sm-12 col-md-3" style="padding:0px!important; margin:0px!important;">
                        <!-- guide column -->
                        <div class=" div-consultaion-type guide-column" data-toggle="modal" data-target="#consultantModal{{$consultation_type->id}}" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <img class="images-consultaion-type" src="{{ asset('frontend/images/consultant') }}/{{$consultation_type->image}}">
                            <h5>@php echo $consultation_type->$Title; @endphp</h5>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- partners block -->
        <section class="partner-block" style="margin-top:50px;">
            <div class="container-fluid">
                <div class="row">
                <header class="seperator-head">
                    <h2 class="text-center">{{$consultation_partners_title->$Title}}</h2>
                </header>
                </div>
                <br><br><div class="row partners-row">
                    <div class="col-12 text-center">
                        <ul class="list-unstyled partner-list text-center">
                            <?php $consultancy_partners=DB::table('page_contents')->where('ref_page','=','consultancy_partner')->get();?>
                            @foreach($consultancy_partners as $consultancy_partner)
                         
                            
                                <li class="text-center images-consultaion-type">
                                <div class="guide-column div-consultaion-type" data-toggle="modal" data-target="#PartnerModal{{$consultancy_partner->id}}" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">    
                                <img  class="images-consultaion-type"src="{{ asset('frontend/images/consultant') }}/{{$consultancy_partner->image}}" alt="no-photo" style="height:150px; width:100%;">
                                </div></li>
                         
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </section>


        <!-- course search aside -->
        <aside class="course-search-aside bg-gray" id="contact_consultant">
            <!-- course search form -->
            <form action="javascript:void(0)" class="container course-search-form">
                <div class="form-group" style="display: flex; flex-direction: row; justify-content: center">
                    <button class="btn btn-theme btn-warning no-shrink text-uppercase" style="width: auto; font-size: 18px">
                        <!-- Calendly link widget begin -->
                        <link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
                        <script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>
                        <a href="" onclick="Calendly.initPopupWidget({url: '{{$banner->url}}'});return false;" style="color: #fff !important;">{{$consultation_contact_us_title->$Title}}</a>
                        <!-- Calendly link widget end -->
                    </button>
                </div>
            </form>
        </aside>


        <!-- Modal -->
                             
       
        @foreach($consultancy_partners as $consultancy_partner)
        <div {{$dir}} class="text-center modal fade consultantModal modal-scroll" id="PartnerModal{{$consultancy_partner->id}}" tabindex="-1" role="dialog" aria-labelledby="consultantModalTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="consultantModalTitle"> @php echo $consultancy_partner->$Title; @endphp</h5>
                    </div>
                    <div class="modal-body">
                        <p>
                             @php echo $consultancy_partner->$Description; @endphp
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-block" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
       @endforeach 
       
        @foreach($consultation_types as $consultation_type)
        <div class="modal fade consultantModal modal-scroll" id="consultantModal{{$consultation_type->id}}" tabindex="-1" role="dialog" aria-labelledby="consultantModalTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="consultantModalTitle"> @php echo $consultation_type->$Title; @endphp</h5>
                    </div>
                    <div class="modal-body">
                        <p>
                             @php echo $consultation_type->$Description; @endphp
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-block" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
       @endforeach 
        

@stop
