<!------------------------- fqs content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.faq'))

@section('content')

	<!-- heading banner -->
<?php $banner=DB::table('page_contents')->where('ref_page','=','faq_banner')->first();
$Title_Name='title_'.app()->getLocale();
$banner_title=$banner->$Title_Name;
$Title="title_".app()->getLocale();
$faq_main_title=DB::table('page_contents')->where('ref_page','faq_main_title')->first();
$faq_main_desc=DB::table('page_contents')->where('ref_page','faq_main_desc')->first();

?>

    @if(app()->getLocale() == "en")
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
	<!-- breadcrumb nav -->
	<nav class="breadcrumb-nav">
		<div class="container">
			<!-- breadcrumb -->
			<ol class="breadcrumb">
				<li><a href="{{ url('/') }}">Home</a></li>
				<li class="active">FAQ</li>
			</ol>
		</div>
	</nav>

	<div class="container faq-container">
	    <div class="panel-group" id="accordion">
                <div data-aos="zoom-in" data-aos-duration="1000" data-aos-easing="ease-in-out" class="faqHeader"> <b>{{$faq_main_title->$Title}}</b> </div>
                <p data-aos="zoom-in" data-aos-duration="1500" data-aos-easing="ease-in-out" style="margin-bottom:40px;">{{$faq_main_desc->$Title}} </p>
                @foreach($contents as $key => $content)
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                            <h4  type="button" data-toggle="collapse" data-target="#output{{$key}}" aria-expanded="false" aria-controls="output{{$key}}">
                            <a>@php echo $content->title_en; @endphp</a>
                            </h4>
      
                            <div class="collapse {{ $key !=0 ? '' : 'in' }}" id="output{{$key}}">
                                @php echo $content->description_en; @endphp
                            </div></div></div>
            @endforeach
	    </div>
	</div>
    @else
        <header class="heading-banner text-white bgCover"
                style="background-image: url(/frontend/images/banners/{{$banner->image}});">
            <div class="container holder">
                <div class="align">
                    <h1>{{$banner_title}}</h1>
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li class="active">الاسئلة الاكثر شيوعاً</li>
                </ol>
            </div>
        </nav>

        <div class="container faq-container rtl">
            <div class="panel-group" id="accordion">
                <div data-aos="zoom-in" data-aos-duration="1000" data-aos-easing="ease-in-out" class="faqHeader"> <b>{{$faq_main_title->$Title}}</b> </div>
                <p data-aos="zoom-in" data-aos-duration="1500" data-aos-easing="ease-in-out" style="margin-bottom:40px;">{{$faq_main_desc->$Title}} </p>
                @foreach($contents as $key => $content)
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                            <h4  type="button" data-toggle="collapse" data-target="#output{{$key}}" aria-expanded="false" aria-controls="output{{$key}}">
                            <a>@php echo $content->title_ar; @endphp</a>
                            </h4>
      
                            <div class="collapse {{ $key !=0 ? '' : 'in' }}" id="output{{$key}}">
                                @php echo $content->description_ar; @endphp
                            </div></div></div>
                          
                @endforeach
            </div>
        </div>
    @endif
@stop
