<!------------------------- privacy policy content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.privacy-policy'))

@section('content')
    @if(app()->getLocale() == "en")
        <!-- heading banner -->
        <header class="heading-banner text-white bgCover legal-background"
                style="background-image: url(../frontend/images/legal/Privacy_policy.png);">
            <div class="container holder">
                <div class="align">
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li class="active">Privacy Policy</li>
                </ol>
            </div>
        </nav>
        <!-- text info block -->
        <article class="container legal-points text-info-block">
            <div class="row">
                <div class="col-xs-12 col-sm-12">
                    <p> @php echo $main_description[0]->description_en ; @endphp </p>
                    @foreach($contents as $key => $content)
                        <h1>{{ $content->title_en }}</h1>
                        <p> @php echo $content->description_en ; @endphp<p>
                    @endforeach
                </div>
            </div>
        </article>
        <!-- counter aside -->
    @else
        <!-- heading banner -->
        <header class="heading-banner text-white bgCover legal-background rtl"
                style="background-image: url(../frontend/images/legal/Privacy_policy_ar.png);">
            <div class="container holder">
                <div class="align">
                </div>
            </div>
        </header>
        <!-- breadcrumb nav -->
        <nav class="breadcrumb-nav rtl">
            <div class="container">
                <!-- breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="{{ url('/') }}">الصفحة الرئيسية</a></li>
                    <li class="active">سياسة الخصوصية</li>
                </ol>
            </div>
        </nav>
        <!-- text info block -->
        <article class="container legal-points text-info-block rtl">
            <div class="row">
                <div class="col-xs-12 col-sm-12">
                    <p> @php echo $main_description[0]->description_ar ; @endphp </p>
                    @foreach($contents as $key => $content)
                        <h1>{{ $content->title_en }}</h1>
                        <p> @php echo $content->description_ar ; @endphp<p>
                    @endforeach
                </div>
            </div>
        </article>
        <!-- counter aside -->
    @endif
@stop
