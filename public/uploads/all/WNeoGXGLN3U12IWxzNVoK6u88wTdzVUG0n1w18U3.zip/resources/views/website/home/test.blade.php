
<!------------------------- home page content -------------------------->
@extends('website.layout.master')

@section('title', trans('messages.home'))

@section('content')

    <?php

    $home_page_train_title=DB::table('page_contents')->where('ref_page','home_page_train_title')->first();
    $Home_page_aljhood_course_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_course_title')->first();
    $Home_page_aljhood_more_courses_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_more_courses_title')->first();
    $Home_page_aljhood_find_course_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_find_course_title')->first();
    $Home_page_aljhood_counter_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_counter_title')->first();
    $Home_page_aljhood_customer_say_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_customer_say_title')->first();
    $Home_page_aljhood_search_button_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_search_button_title')->first();
    $Home_page_aljhood_reset_button_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_reset_button_title')->first();
    $Home_page_aljhood_trust_acc_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_trust_acc_title')->first();
    $Home_page_aljhood_newsletter_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_newsletter_title')->first();
    $Home_page_aljhood_newsletter_desc_title=DB::table('page_contents')->where('ref_page','Home_page_aljhood_newsletter_desc_title')->first();
    $cookies_section=DB::table('page_contents')->where('ref_page','cookies_section')->first();
    $search_course_form_subject=DB::table('page_contents')->where('ref_page','search_course_form_subject')->first();
    $search_course_form_time=DB::table('page_contents')->where('ref_page','search_course_form_time')->first();
    $search_course_form_activity_type=DB::table('page_contents')->where('ref_page','search_course_form_activity_type')->first();
    $search_course_form_activity_place=DB::table('page_contents')->where('ref_page','search_course_form_activity_place')->first();
    $search_course_form_activity_accreditation=DB::table('page_contents')->where('ref_page','search_course_form_activity_accreditation')->first();
    $courses = DB::table('courses')->where('is_hidden' , 0)->get();
    ?>
    @if(app()->getLocale() == "en")
        <!-- intro block -->

        @if(!Session::has('session'))
            <div class='popup row'>
                <div class="col-lg-3 hidden-md hidden-sm hidden-xs x" style="padding: 0 !important;">
                    <div style="width: 100%; height: 650px"></div>
                </div>
                <div class="col-lg-6" style="padding: 0 !important;">
                    <div class="img">
                        <i class="fas fa-times x" id="x" style="visibility: hidden"></i>
                        <div class="sub-form-pop">
                            <div class="form-pop">
                                <div class="head">
                                    <h2> {{$Home_page_aljhood_newsletter_title->title_en}}</h2>
                                    <h4 style="text-transform: lowercase">
                                        {{$Home_page_aljhood_newsletter_desc_title->title_en}}</h4>

                                </div>
                                <div class="form-control-pop">
                                    <form action="javascript:void(0)" id="popNewsLetterForm">
                                        <label for="email" style="display: none"></label>
                                        <input name="email" id="email" type="email" placeholder="Enter Your Email">
                                        <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold"> Subscribe</button>
                                    </form>
                                </div>
                                <div class="no-thanks">
                                    <p class="exit" style="cursor: pointer">No, Thanks</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-3 hidden-md hidden-sm hidden-xs x" style="padding: 0 !important;">
                    <div style="width: 100%; height: 650px;"></div>
                </div>
            </div>
        @endif
        <section class="intro-block" style=" min-height: 180px;">
            <div class="slider fade-slider">
                @foreach($banners as $banner)
                    @if(!$banner->video)
                        <div class="test" style=" min-height: 180px; ">
                            <!-- intro block slide -->
                            <article class="intro-block-slide overlay bg-cover"
                                     style="background-image: url({{ asset("storage/uploads/sliders") }}/{{ $banner->image }})">
                                <div class="align-wrap container">
                                    <div class="align">
                                        <div class="box" style="">
                                            <div class="anim">
                                                <h2 class="intro-block-heading" style="color: #ffffff; font-size: xxx-large; background: #012939; padding: 15px;">@php echo $banner->title_en; @endphp</h2>
                                            </div>
                                            <div class="anim delay1">
                                                <p class="test-font"><strong>  @php echo $banner->description_en; @endphp </strong></p>
                                            </div></div>

                                        <div class="anim delay2">
                                            <div class="btns-wrap">
                                                @if(!empty($banner->link))
                                                    <a href="{{ $banner->link }}"
                                                       class="btn btn-warning btn-theme text-uppercase" target="_blank" style="color: black; background: #ffffff; border: none; border-radius: 30px;">{{$banner->button_label_en}}</a>
                                                @endif
                                                @if(!empty($banner->pdf))
                                                    <a href="{{ asset("/storage/uploads/banners/files/") }}/{{ $banner->pdf }}"
                                                       class="btn btn-warning btn-theme text-uppercase" target="_blank" style="color: black; background: #ffffff; border: none; border-radius: 30px;">{{$banner->button_file_en}}</a>
                                                @endif
                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </article>
                        </div>
                    @else

                        <div class="test">
                            <!-- intro block slide -->
                            <article class="intro-block-slide overlay bg-cover"
                                     style="background-image: url({{ asset("storage/uploads/sliders") }}/{{ $banner->image }});box-shadow:inset 0 0 0 2000px rgba(0, 0, 0, 0.5);">
                                <div class="align-wrap container" style="display: flex; flex-direction: row; justify-content: center; align-items: center;">
                                    <div class="align">
                                        <div class="anim delay2">
                                            <div class="btns-wrap">
                                                <a href="javascript:void(0)" class="round-button" data-toggle="modal" data-target="#videoPopupModal{{$banner->id}}"><i class="fas fa-play"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </div>

                    @endif
                @endforeach
            </div>
        </section>
        <section class="why-block container" style="margin-top: 30px">

            <div class="row">
                <div class="col-md-12">
                    <h2 class="popular-head-heading hr_head" style="color:#be9f56; font-size:28px; padding-top:30px !important;"> @php echo $content->title_en; @endphp</h2>

                    <div class="about-us-description animate__animated animate__backInLeft text-left">
                        <p>
                            @php echo $content->description_en; @endphp
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- about us block -->
        <section class="about-us-block bg-gray">
            <div class="container">
                <header class="popular-posts-head">

                    <h2 class="popular-head-heading hr_head"><?php echo $home_page_train_title->title_en?></h2>
                </header>
                <div class="row slider extra2-slider text-center" style="display: flex;flex-direction: row;justify-content: center;align-items: center;flex-wrap: wrap;">
                    <div class="col-lg-3 col-md-3 col-xs-6" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="50" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block1->image }}"  alt="aljhood">
                                    </div>
                                    <figcaption class="text-center">
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;">
                                            <h4>
                                                <img src="{{ asset("frontend/images/icon01.svg") }}"  alt="aljhood" style="width: 44px;"> &nbsp;@php echo $block1->title_en @endphp
                                            </h4></div>
                                        <div class="details">
                                            <p class="details__content">@php echo $block1->description_en @endphp
                                                <button id="show-back"><a href="{{$block1->url}}">Read More</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                    <div class="col-lg-3 col-md-3 col-xs-6" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="50" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block2->image }}"  alt="aljhood">
                                    </div>
                                    <figcaption id="detailsId1">
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;">
                                            <h4>
                                                <img src="{{ asset("frontend/images/icon02.svg") }}"  alt="aljhood" style="width: 50px ; margin: 0 10px">@php echo $block2->title_en @endphp
                                            </h4>
                                        </div>
                                        <div class="details">
                                            <p class="details__content1">@php echo $block2->description_en @endphp
                                                <button id="show-back"><a href="{{$block2->url}}">Read More</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                    <div class="col-lg-3 col-md-3 col-xs-6" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="2000" data-aos-delay="50" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block3->image }}" alt="no-photo">
                                    </div>
                                    <figcaption id="detailsId2">
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;">
                                            <h4>
                                                <i class="fa fa-image" style="font-size: 43px; width: 50px ; margin: 0 10px"></i>@php echo $block3->title_en @endphp
                                            </h4></div>
                                        <div class="details">
                                            <p class="details__content2">@php echo $block3->description_en @endphp
                                                <button id="show-back"><a href="{{$block3->url}}">Read More</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- why us block -->

        <!-- popular courses block -->

        <section class="popular-posts-block container">
            <header class="popular-posts-head" >
                <h2 class="popular-head-heading hr_head"><?php echo $Home_page_aljhood_course_title->title_en;?></h2>
            </header>
            <div class="row">
                <!-- popular posts slider -->
                <div id="popular_post" class="slider related-course-slider popular-courses">
                    @foreach($courses as $course)
                        <div onclick="courseFunction({{ $course->id }})">
                            <div class="col-xs-12 ">
                                <!-- popular post -->
                                <a href="{{ url('course') }}/{{$course->id}}">
                                    <article class="popular-post" style="pointer-events:none;">
                                        <div class="aligncenter">
                                            <img src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}"
                                                 alt="aljhood">
                                        </div>
                                        <div>
                                        </div>

                                        <div style="height:55px; text-align:left;"><b>{{$course->title_en}}</b></div>

                                    </article>
                                </a>

                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="btns-wrap text-center">
                <a href="{{ url('aljhood/courses') }}" class="btn btn-warning btn-theme text-uppercase"> <?php echo $Home_page_aljhood_more_courses_title->title_en;?> <i class="fa fa-chevron-right"></i> </a>
            </div>
        </section>

        <!-- course search aside -->
        <aside class="course-search-aside bg-gray">
            <!-- course search form -->

            <form action="{{ url('filterCourse') }}" method="GET" class="container-fluid course-search-form" autocomplete="off">
                <header class="popular-posts-head">
                    <div class="container">
                        <h2 class="popular-head-heading hr_head text-left" style="text-transform: none"><?php echo $Home_page_aljhood_find_course_title->title_en;?> </h2>
                    </div></header>
                <div class="form-holder">
                    <div class="form-row">
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en searchable-select" name="subject_area">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_subject->title_en}}</option>
                                @foreach($subject_area as $sub)
                                    <option value="{{ $sub->subject_area }}">{{ $sub->subject_area }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="input-date" style="height: 52px">
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato ul-height" style="width: 100%">
                                    <li class="dropdown li-height select-arrow select-arrow-en" style="margin: 0 !important; padding: 0 !important; width: 100%">
                                        <a href="javascript:void(0)" class="a-height" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false"
                                           style="color: #5e5e5e ;  font-size: 14px !important; font-weight: normal; text-transform: none; text-align: right; padding: 10px 2px ; background: #fff ; width: 95%"><span> وقت الدورة</span></a>


                                        <ul class="dropdown-menu" id="dropdownCustom">
                                            <input type="checkbox" id="available1" value="now" name="available[]">
                                            <label for="available1"> Available now</label>
                                            <br>
                                            <input type="checkbox" id="available2" value="next_week" name="available[]">
                                            <label for="available2"> Within next week</label>
                                            <br>
                                            <input type="checkbox" id="available3" value="next_month" name="available[]">
                                            <label for="available3"> Within next month</label>
                                            <br>
                                            <input type="checkbox" id="available4" value="three_months" name="available[]">
                                            <label for="available4"> Within 3 months</label>
                                            <br>
                                            <input type="checkbox" id="available5" value="sixth_months" name="available[]">
                                            <label for="available5"> Within 6 months</label>
                                            <input type="text" name="available_date" style="height: 45px" placeholder="Start Date" min="{{ \Carbon\Carbon::now()->toDateString() }}" onfocus="(this.type='date')">
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en none-searchable-select" name="venue">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_place->title_en}}</option>
                                @foreach($venue as $ven)
                                    <option value="{{ $ven->venue }}">{{ $ven->venue }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en none-searchable-select" name="activity_type">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_type->title_en}}</option>
                                @foreach($activity_type as $act)
                                    <option value="{{ $act->activity_type }}">{{ $act->activity_type }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow select-arrow-en none-searchable-select" name="accreditation">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_accreditation->title_en}}</option>
                                @foreach($accreditation as $acc)
                                    <option value="{{ $acc->name }}">{{ $acc->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="display: flex; flex-direction: row;">
                            <button type="submit" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-6 col-sm-6 col-xs-6">{{$Home_page_aljhood_search_button_title->title_en}}</button>
                            <button type="reset" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-6 col-sm-6 col-xs-6">{{$Home_page_aljhood_reset_button_title->title_en}}</button>
                        </div>
                    </div>
                </div>
            </form>

        </aside>
            <?
            $counters=DB::table('counters')->orderBy('priority','desc')->get();

            ?>
            <!-- counter aside -->
        <aside id="counters" class="bg-cover counter-aside" onscroll="startCount">
            <div class="container align-wrap">
                <header class="popular-posts-head">
                    <h2 class="popular-head-heading hr_head text-left">{{$Home_page_aljhood_counter_title->title_en}}</h2>
                </header>
                <div class="align">
                    <div class="row slider extra-slider">

                        @foreach($counters as $counter)

                            <div class="col-xs-12 col-sm-4 col" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                                <img src="{{ asset("frontend/images/circle.png") }}" alt="no-photo">
                                <h2 class="counter-aside-heading">
                                    <strong class="countdown element-block" id="countdown_ani{{$counter->id}}">@php echo $counter->counter; @endphp</strong>
                                    <strong class="text element-block"> @php echo $counter->title_en; @endphp</strong>
                                </h2>
                            </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </aside>

        <!-- news block -->
        <section class="news-block container-fluid bg-gray">
            <header class="popular-posts-head">
                <div class="container">
                    <h2 class="popular-head-heading hr_head col-xs-10 col-sm-10">{{$Home_page_aljhood_customer_say_title->title_en}}</h2>
                </div></header>
            <div class="row slider videos-slider" style="margin:15px;">
                {{ $videoDuration = 1000 }}
                {{ $counter = 0 }}
                @foreach($videos as $key => $video)
                    <div class="col-xs-12 col-sm-12 col-md-12" id="youtube_video">
                        <!-- news post -->
                        <article class="news-post" data-aos="fade-up" data-aos-duration="{{ $videoDuration + $counter }}" data-aos-easing="ease-in-out">
                            <div class="aligncenter">
                                <iframe class="youtube-video" width="560" height="315" src="{{ $video->video }}"
                                        title="YouTube video player" frameborder="0"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen>
                                </iframe>
                            </div>
                        </article>
                    </div>
                    {{ $counter = 300 }}
                    {{ $videoDuration = $videoDuration + $counter }}
                @endforeach
            </div>
        </section>

        <section class="testimonials-block text-center" style="padding-top: 10px !important;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <!-- testimonail slider -->
                        <div class="slider testimonail-slider">
                            @foreach($testimonials as $testimonial)
                                <div>
                                    <!-- testimonial quote -->
                                    <blockquote class="testimonial-quote font-roboto">
                                        <p style="text-align: justify"> @php echo $testimonial->description_en; @endphp </p>
                                        <h3 style="text-align: left; color: #B4975A; font-size: 14px"> @php echo $testimonial->title_en; @endphp </h3>
                                    </blockquote>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <br><br>

        <!-- partners block -->
        <section class="partner-block" style="padding: 30px 15px">
            <div class="container-fluid">
                <div class="row">
                    <div class="container" style="padding-top:30px;">
                        <header class="popular-posts-head col-lg-12 col-md-12 col-sm-12 col-xs-8">
                            <h2 class="popular-head-heading hr_head">{{$Home_page_aljhood_trust_acc_title->title_en}}</h2>
                        </header></div>
                </div>
                <div class="row partners-row" style="margin:15px;">
                    <div class="col-xs-12">
                        <ul class="list-unstyled partner-list">
                            @foreach($accreditation as $acc)
                                <li><a href="{{ url('aljhood/trusted-accreditation#trusted_by_acc_') }}{{ $acc->id }}"><img src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}" alt="no-photo" style=""></a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- subscription aside block -->
        <aside class="subscription-aside-block bg-theme text-white">
            <!-- newsletter sub form -->
            <form action="javascript:void(0)" class="container newsletter-sub-form" id="newsLetterForm">
                <div class="row form-holder">
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="text-wrap">
                        <span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span
                                    class="sr-only">icn</span></i></span>
                            <div class="inner-wrap">
                                <label for="email">{{$Home_page_aljhood_newsletter_title->title_en}}</label>
                                <p>{{$Home_page_aljhood_newsletter_desc_title->title_en}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email&hellip;">
                            <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">Subscribe</button>
						</span>
                        </div>
                    </div>
                </div>
            </form>
        </aside>
        <div class="gallery holder cookies-section" style="background-color: transparent; background-repeat: no-repeat; background-size: cover; position: fixed; bottom: 0; width: 100%; z-index: 999 ; display: none">

            <div class="filter-gallery" style="width: 34%;">
                <div class="row" style="background-color: rgba(230, 230, 230 , 0.6); padding: 20px 0; display: flex; flex-direction: row; justify-content: space-around; align-items: center">
                    <div class="img-section">
                        <img src="{{ asset('frontend/images/cookies.png') }}"  alt="aljhood" width="120">
                    </div>
                    <div class="body-section" style="display: flex; flex-direction: column; justify-content: space-between; align-items: end ; width: 50%">
                        <h4 style="color: black; font-size: 16px; margin-top: 0; margin-bottom: 10px">{{$cookies_section->title_en}}</h4>
                        <div class="buttons-cook" style="display: flex;flex-direction: row">
                            <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold exit-cookie" style="background-color: #313139; font-size: 15px"> Accept </button>
                            <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold exit-cookie" style="font-size: 15px"> X </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    @else
        <!-- intro block -->

        @if(!Session::has('session'))
            <div class='popup row' style="direction: rtl">
                <div class="col-lg-3 hidden-md hidden-sm hidden-xs x" style="padding: 0 !important;">
                    <div style="width: 100%; height: 650px"></div>
                </div>
                <div class="col-lg-6" style="padding: 0 !important;">
                    <div class="img">
                        <i class="fas fa-times x" id="x" style="visibility: hidden"></i>
                        <div class="sub-form-pop">
                            <div class="form-pop">
                                <div class="head">
                                    <h2> {{$Home_page_aljhood_newsletter_title->title_ar}}</h2>
                                    <h4 style="text-transform: lowercase">
                                        {{$Home_page_aljhood_newsletter_desc_title->title_ar}}</h4>

                                </div>
                                <div class="form-control-pop">
                                    <form action="javascript:void(0)" id="popNewsLetterForm">
                                        <label for="email" style="display: none"></label>
                                        <input name="email" id="email" type="email" placeholder="ادخل البريد الالكتروني">
                                        <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold"> الاشتراك</button>
                                    </form>
                                </div>
                                <div class="no-thanks">
                                    <p class="exit" style="cursor: pointer">لا, شكراً</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-3 hidden-md hidden-sm hidden-xs x" style="padding: 0 !important;">
                    <div style="width: 100%; height: 650px;"></div>
                </div>
            </div>
        @endif
        <section class="intro-block" style=" min-height: 180px; ">
            <div class="slider fade-slider">
                @foreach($banners as $banner)
                    @if(!$banner->video)
                        <div class="test" style=" min-height: 180px; ">
                            <!-- intro block slide -->
                            <article class="intro-block-slide overlay bg-cover"
                                     style="background-image: url({{ asset("storage/uploads/sliders") }}/{{ $banner->image }})">
                                <div class="align-wrap container">
                                    <div class="align text-right">
                                        <div  class="box" style="">

                                            <div class="anim">
                                                <h2 class="intro-block-heading" style="color: #ffffff; font-size: xxx-large; background: #012939; padding: 15px;">@php echo $banner->title_ar; @endphp</h2>
                                            </div>
                                            <div class="anim delay1">
                                                <p>  @php echo $banner->description_ar; @endphp </p>
                                            </div></div>

                                        <div class="anim delay2" style="direction: rtl">
                                            <div class="btns-wrap">
                                                @if(!empty($banner->link))
                                                    <a href="{{ $banner->link }}"
                                                       class="btn btn-warning btn-theme text-uppercase" target="_blank" style="color: black; background: #ffffff; border: none; border-radius: 30px;">{{$banner->button_label_ar}}</a>
                                                @endif
                                                @if(!empty($banner->pdf))
                                                    <a href="{{ asset("/storage/uploads/banners/files/") }}/{{ $banner->pdf }}"
                                                       class="btn btn-warning btn-theme text-uppercase" target="_blank" style="color: black; background: #ffffff; border: none; border-radius: 30px;">{{$banner->button_file_ar}}</a>
                                                @endif
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </article>
                        </div>
                    @else
                        <div class="test">
                            <!-- intro block slide -->
                            <article class="intro-block-slide overlay bg-cover"
                                     style="background-image: url({{ asset("storage/uploads/sliders") }}/{{ $banner->image }});box-shadow:inset 0 0 0 2000px rgba(0, 0, 0, 0.5);">
                                <div class="align-wrap container" style="display: flex; flex-direction: row; justify-content: center; align-items: center;">
                                    <div class="align">
                                        <div class="anim delay2">
                                            <div class="btns-wrap">
                                                <a href="javascript:void(0)" class="round-button" data-toggle="modal" data-target="#videoPopupModal{{$banner->id}}"><i class="fas fa-play"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </div>
                    @endif
                @endforeach
            </div>
        </section>
        <section class="why-block container text-right">
            <div class="row">
                <div class="col-md-12">
                    <div class="about-us-description animate__animated animate__backInLeft rtl">
                        <h1 class="popular-head-heading hr_head" style="color: #33332c;font-size: 28px; padding-top: 30px !important;"> @php echo $content->title_ar; @endphp</h1>
                        <p>
                            @php echo $content->description_ar; @endphp
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- about us block -->
        <section class="about-us-block bg-gray rtl">
            <div class="container">
                <header class="popular-posts-head">
                    <h2 class="popular-head-heading hr_head col-xs-12 "><?php echo $home_page_train_title->title_ar?></h2>
                </header>
                <div class="row slider extra2-slider" style="display: flex;flex-direction: row;justify-content: center;align-items: center;flex-wrap: wrap; direction: ltr">
                    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 rtl" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="2000" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block1->image }}" alt="no-photo">
                                    </div>
                                    <figcaption>
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;">
                                            <h4>
                                                <img src="{{ asset("frontend/images/icon01.svg") }}" alt="no-photo" style="width: 50px ; margin: 0 10px">&nbsp; @php echo $block1->title_ar @endphp
                                            </h4></div>
                                        <div class="details">
                                            <p class="details__content">@php echo $block1->description_ar @endphp
                                                <button id="show-back"><a href="{{$block1->url}}">المزيد</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 rtl" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="1500" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block2->image }}" alt="no-photo">
                                    </div>
                                    <figcaption id="detailsId1">
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;"><h4>
                                                <img src="{{ asset("frontend/images/icon02.svg") }}" alt="no-photo" style="width: 50px ; margin: 0 10px">@php echo $block2->title_ar @endphp
                                            </h4></div>
                                        <div class="details">
                                            <p class="details__content1">@php echo $block2->description_ar @endphp
                                                <button id="show-back"><a href="{{$block2->url}}">المزيد</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                    <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 rtl" style="display: flex; flex-direction: row; justify-content: center">
                        <!-- news column post -->
                        <article class="about-us-column" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <figure>
                                <div class="front">
                                    <div class="image">
                                        <img src="{{ url('storage/uploads/page-contents') }}/{{ $block3->image }}" alt="no-photo">
                                    </div>
                                    <figcaption id="detailsId2">
                                        <div style="text-align:center;padding-left:60px;padding-right:60px;"><h4>
                                                <i class="fa fa-image" style="font-size: 43px; width: 50px ; margin: 0 10px"></i>@php echo $block3->title_ar @endphp
                                            </h4></div>
                                        <div class="details">
                                            <p class="details__content2">@php echo $block3->description_ar @endphp
                                                <button id="show-back"><a href="{{$block3->url}}">المزيد</a>
                                                </button>
                                            </p>
                                        </div>
                                    </figcaption>
                                </div>
                            </figure>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- why us block -->

        <!-- popular courses block -->
        <section class="popular-posts-block container">
            <header class="popular-posts-head rtl">
                <h2 class="popular-head-heading hr_head"><?php echo $Home_page_aljhood_course_title->title_ar;?></h2>
            </header>

            <div class="row">
                <!-- popular posts slider -->
                <div id="popular_post" class="slider related-course-slider popular-courses">
                    @foreach($courses as $course)
                        <div onclick="courseFunction({{ $course->id }})">
                            <div class="col-xs-12 ">
                                <!-- popular post -->
                                <a href="{{ url('course') }}/{{$course->id}}">
                                    <article class="popular-post" style="pointer-events:none;">
                                        <div class="aligncenter">
                                            <img src="{{ asset("storage/uploads/courses") }}/{{ $course->image }}"
                                                 alt="no-photo">
                                        </div>
                                        <div>
                                        </div>

                                        <div style="height:55px; direction:rtl;"><b>{{$course->title_ar}}</b></div>

                                    </article>
                                </a>

                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="btns-wrap text-center">
                <a href="{{ url('aljhood/courses') }}" class="btn btn-warning btn-theme text-uppercase"> <?php echo $Home_page_aljhood_more_courses_title->title_ar;?>  <i
                        class="fa fa-chevron-right"></i> </a>
            </div>


        </section>


        <!-- course search aside -->
        <aside class="course-search-aside bg-gray rtl">
            <!-- course search form -->
            <form action="{{ url('filterCourse') }}" method="GET" class="container-fluid course-search-form" autocomplete="off">
                <header class="popular-posts-head">
                    <div class="container">
                        <h2 class="popular-head-heading hr_head text-right" style="text-transform: none"><?php echo $Home_page_aljhood_find_course_title->title_ar;?> </h2>
                    </div>
                </header>
                <div class="form-holder">
                    <div class="form-row">
                        <div class="form-group">
                            <select class="arrow_down select-arrow searchable-select" name="subject_area">
                                <option value="" selected="selected">{{$search_course_form_subject->title_ar}}</option>
                                @foreach($subject_area as $sub)
                                    <option value="{{ $sub->subject_area_ar }}">{{ $sub->subject_area_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="input-date" style="height: 52px">
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato ul-height" style="width: 100% ; text-align: right ;padding: 0 10px 0 0;">
                                    <li class="dropdown li-height select-arrow" style="margin: 0 !important; padding: 0 !important; width: 100%">
                                        <a href="javascript:void(0)" class="a-height" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false" style="color: #888 ;  font-size: 14px; font-weight: normal; text-transform: none; text-align: right; padding: 10px 0 ; background: #fff ; width: 100%"><span> {{$search_course_form_time->title_ar}} </span></a>
                                        <ul class="dropdown-menu" style="text-align: right ; left: 0;" id="dropdownCustom">
                                            <input type="checkbox" id="available1" value="now" name="available[]">
                                            <label for="available1"> متوفر الآن</label><br>
                                            <input type="checkbox" id="available2" value="next_week" name="available[]">
                                            <label for="available2">خلال الأسبوع المقبل</label><br>
                                            <input type="checkbox" id="available3" value="next_month" name="available[]">
                                            <label for="available3"> خلال الشهر القادم</label><br>
                                            <input type="checkbox" id="available4" value="three_months" name="available[]">
                                            <label for="available4"> خلال 3 أشهر القادمة</label><br>
                                            <input type="checkbox" id="available5" value="sixth_months" name="available[]">
                                            <label for="available5"> خلال 6 أشهر القادمة</label>
                                            {{--                                            <br>--}}
                                            {{--                                            <input type="checkbox" id="available6" value="next_year" name="available[]">--}}
                                            {{--                                            <label for="available6"> خلال العام المقبل</label><br>--}}
                                            <input type="text" name="available_date" style="height: 45px"
                                                   placeholder="وقت الدورة" min="{{ \Carbon\Carbon::now()->toDateString() }}" onfocus="(this.type='date')">
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow none-searchable-select" name="venue">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_place->title_ar}}</option>
                                @foreach($venue as $ven)
                                    <option value="{{ $ven->venue_ar }}">{{ $ven->venue_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow none-searchable-select" name="activity_type">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_type->title_ar}} </option>
                                @foreach($activity_type as $act)
                                    <option value="{{ $act->activity_type_ar }}">{{ $act->activity_type_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <select class="arrow_down select-arrow none-searchable-select ltr" name="accreditation">
                                <option value="" selected="selected" disabled style="display: none">{{$search_course_form_activity_accreditation->title_ar}}</option>
                                @foreach($accreditation as $acc)
                                    <option value="{{ $acc->name_ar }}">{{ $acc->name_ar }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" style="display: flex; flex-direction: row;">
                            <button type="submit" class="btn btn-theme btn-warning no-shrink text-uppercase">{{$Home_page_aljhood_search_button_title->title_ar}}</button>
                            <button type="reset" class="btn btn-theme btn-warning no-shrink text-uppercase col-lg-12 col-md-12 col-sm-8 col-xs-8">{{$Home_page_aljhood_reset_button_title->title_ar}}</button>
                        </div>
                    </div>
                </div>
            </form>
        </aside>

        <!-- counter aside -->
        <aside id="counters" class="bg-cover counter-aside ">
            <div class="container align-wrap">
                <header class="popular-posts-head rtl">
                    <h2 class="popular-head-heading hr_head text-right">{{$Home_page_aljhood_counter_title->title_ar}}</h2>
                </header>
                <div class="align">
                    <div class="row slider extra-slider">

                        @foreach($counters as $key=>$counter)

                            <div class="col-xs-12 col-sm-4 col text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
                                <img src="{{ asset("frontend/images/circle.png") }}" alt="no-photo">
                                <h2 class="counter-aside-heading text-center" style="text-align:center!important;{{ $key ==0 ? '' : 'padding-left:11%;' }}">
                                    <strong class="countdown element-block text-center" id="countdown_ani{{$counter->id}}">@php echo $counter->counter; @endphp</strong>
                                    <strong class="text element-block text-center"> @php echo $counter->title_ar; @endphp</strong>
                                </h2>
                            </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </aside>
        <!-- news block -->
        <section class="news-block container-fluid bg-gray">
            <header class="popular-posts-head rtl text-right">
                <div class="container">
                    <h2 class="popular-head-heading hr_head"> {{$Home_page_aljhood_customer_say_title->title_ar}} </h2>
                </div></header>
            <div class="row slider videos-slider" style="margin:15px;">
                {{ $videoDuration = 1000 }}
                {{ $counter = 0 }}
                @foreach($videos as $video)
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <!-- news post -->
                        <article class="news-post" data-aos="fade-up" data-aos-duration="{{ $videoDuration + $counter }}" data-aos-easing="ease-in-out">
                            <div class="aligncenter">
                                <iframe src="{{ $video->video }}"
                                        title="YouTube video player" frameborder="0"
                                        allow="accelerometer; autoplay;  encrypted-media;  picture-in-picture"
                                        allowfullscreen="">
                                </iframe>
                            </div>
                        </article>
                    </div>
                    {{ $counter = 300 }}
                    {{ $videoDuration = $videoDuration + $counter }}
                @endforeach
            </div>
        </section>
        </aside>
        <section class="testimonials-block text-center" style="padding-top: 10px !important;">
            <div class="container-fluid">
                <div class="row" style="margin:15px;">
                    <div class="col-xs-12 col-sm-12">
                        <!-- testimonail slider -->
                        <div class="slider testimonail-slider">
                            @foreach($testimonials as $testimonial)
                                <div>
                                    <!-- testimonial quote -->
                                    <blockquote class="testimonial-quote font-roboto">
                                        <p style="text-align: right">@php echo $testimonial->description_ar; @endphp</p>
                                        <h3 style="text-align: right; color: #B4975A; font-size: 14px">@php echo $testimonial->title_ar; @endphp</h3>
                                    </blockquote>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <br><br>

        <!-- partners block -->
        <section class="partner-block" style="padding: 1px 15px">
            <div class="container-fluid">
                <div class="row">
                    <header class="popular-posts-head rtl text-right">
                        <div class="container" style="padding-top:30px;">
                            <h2 class="popular-head-heading hr_head">{{$Home_page_aljhood_trust_acc_title->title_ar}} </h2>
                    </header></div>
            </div>
            <div class="row partners-row" style="margin:15px;">
                <div class="col-xs-12">
                    <ul class="list-unstyled partner-list">
                            <?php $accreditation = DB::table('trusted_accreditations')->where('image','!=',null)->get();?>
                        @foreach($accreditation as $acc)
                            <li><a href="{{ url('aljhood/trusted-accreditation#trusted_by_acc_') }}{{ $acc->id }}"><img src="{{ asset("storage/uploads/trusted_accreditations") }}/{{ $acc->image }}" alt="no-photo"></a></li>
                        @endforeach
                    </ul>
                </div>
            </div>
            </div>
        </section>

        <!-- subscription aside block -->
        <aside class="subscription-aside-block bg-theme text-white rtl">
            <!-- newsletter sub form -->
            <form action="javascript:void(0)" id="newsLetterForm" class="container-fluid newsletter-sub-form" >
                <div class="row form-holder">
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="text-wrap">
                        <span class="element-block icn no-shrink rounded-circle"><i class="far fa-envelope-open"><span
                                    class="sr-only">icn</span></i></span>
                            <div class="inner-wrap">
                                <label for="email">{{$Home_page_aljhood_newsletter_title->title_ar}}</label>
                                <p>{{$Home_page_aljhood_newsletter_desc_title->title_ar}}</p>

                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col">
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-control" placeholder="أدخل البريد الالكتروني">
                            <span class="input-group-btn">
							<button class="btn btn-dark text-uppercase" type="submit">الاشتراك</button>
						</span>
                        </div>
                    </div>
                </div>
            </form>
        </aside>
        <div class="gallery holder cookies-section" style="background-color: transparent; background-repeat: no-repeat; background-size: cover; position: fixed; bottom: 0; width: 100%; z-index: 999 ; display: none ; direction: rtl">

            <div class="filter-gallery" style="width: 34%;">
                <div class="row" style="background-color: rgba(230, 230, 230 , 0.6); padding: 20px 0; display: flex; flex-direction: row; justify-content: space-around; align-items: center">
                    <div class="img-section">
                        <img src="{{ asset('frontend/images/cookies.png') }}"  alt="aljhood" width="120">
                    </div>
                    <div class="body-section" style="display: flex; flex-direction: column; justify-content: space-between; align-items: end ; width: 50%">
                        <h4 style="color: black; font-size: 16px; margin-top: 0; margin-bottom: 10px">{{$cookies_section->title_ar}}</h4>
                        <div class="buttons-cook" style="display: flex;flex-direction: row">
                            <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold exit-cookie" style="background-color: #313139 ; font-size: 15px"> أوافق </button>
                            <button type="submit" class="btn btn-theme btn-warning text-uppercase fw-bold exit-cookie" style="font-size: 15px"> X </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    @endif
    @foreach($banners as $banner)
        <div class="modal fade" id="videoPopupModal{{$banner->id}}" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width: 92%">
                <div class="modal-content">
                    <iframe id="videoIfram" src="{{$banner->video}}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    @endforeach
@stop


@section('scripts')

    <script>

        $(window).load(function (){
            $(window).on('scroll',function() {
                var scroll = $(this).scrollTop();
                if (scroll >= 2500) {
                    document.getElementById("counters").addEventListener("wheel", animateValue);


                    function kFormatter(num) {
                        return Math.abs(num) > 999 ? Math.sign(num)*((Math.abs(num)/1000).toFixed(1)) + 'k' : Math.sign(num)*Math.abs(num)
                    }
                    function animateValue(obj, start, end, duration) {
                        let startTimestamp = null;
                        const step = (timestamp) => {
                            if (!startTimestamp) startTimestamp = timestamp;
                            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                            if (end == 6) {
                                obj.innerHTML = '+' + kFormatter(Math.floor(progress * (end - start) + start));
                            } else {
                                obj.innerHTML = '+' + kFormatter(Math.floor(progress * (end - start) + start));
                            }
                            if (progress < 1) {
                                window.requestAnimationFrame(step);
                            }
                        };
                        window.requestAnimationFrame(step);
                    }


                    var x1 = {{ $counters[0]->counter }};
                    var x2 = {{ $counters[1]->counter }};
                    var x3 = {{ $counters[2]->counter }};
                    var obj = document.getElementById("countdown_ani1");
                    animateValue(obj, 0, x1, 10000);

                    var obj = document.getElementById("countdown_ani2");
                    animateValue(obj, 0, x2, 10000);

                    var obj = document.getElementById("countdown_ani3");
                    animateValue(obj, 0, x3, 10000);
                    $(window).off('scroll');
                }
            });
        })
    </script>

    <script>
        var url = $('meta[name=base_url]').attr("content");
        var csrf_token = $('meta[name=csrf_token]').attr("content");
        $(window).load(function() {
            if($(window).width() > 767){
                setTimeout( function() {
                    $(function () {
                        var overlay = $('<div></div>');
                        overlay.show();
                        overlay.appendTo(document.body);
                        $('.popup').show();
                        $('.close').click(function () {
                            $.ajax(
                                {
                                    url: url+'/setSession',
                                    type: 'get',
                                    success: function(){
                                        $('.popup').hide();
                                        overlay.appendTo(document.body).remove();
                                        return false;
                                    }});

                        });
                        $('.x').click(function () {
                            $.ajax(
                                {
                                    url: url+'/setSession',
                                    type: 'get',
                                    success: function(){
                                        $('.popup').hide();
                                        overlay.appendTo(document.body).remove();
                                        setTimeout( function() {
                                            $(".cookies-section").css('display', 'block')
                                        } , 1000)
                                        return false;
                                    }});
                        });
                        $('.exit').click(function () {
                            $.ajax(
                                {
                                    url: url+'/setSession',
                                    type: 'get',
                                    success: function(){
                                        $('.popup').hide();
                                        overlay.appendTo(document.body).remove();
                                        setTimeout( function() {
                                            $(".cookies-section").css('display', 'block');
                                        } , 1000)
                                        return false;
                                    }});
                        });
                        $('.exit-cookie').click(function (){
                            // alert(url);
                            $.ajax({
                                url: url+'/setSession',
                                type: 'get',
                                success: function(){
                                    console.log('Yes');
                                    $(".cookies-section").css('display', 'none');
                                }});
                        });
                    });
                },2000)
            }else{
                $(".cookies-section").css('display', 'none')
                $('.popup').css('display' , 'none');
            }
        })

    </script>

<style>
.intro-block-slide p {
    margin: 0;
    background: #ffffff;
    box-shadow: 9px 9px 1px 1px #012939;
    padding: 10px;
}
    @media only screen and (max-width: 600px) {
        .intro-block-heading {
            font-size: 19px !important;
            float: left;
            margin-left: -129px !important;
        }
            .intro-block .slider .test .intro-block-slide .align-wrap .align .anim p {
        font-size: 12px;
        display: none;
    }
    .anim.delay2 {
    position: absolute;
    top: 76px;
}
    }
</style>

@stop
