<!DOCTYPE html>
<html lang="ar">
<head>
    <link rel="preconnect" href="https://www.google-analytics.com" crossorigin="">
    <link rel="preconnect" href="https://www.googletagmanager.com" crossorigin="">
    <link rel="preconnect" href="https://www.gstatic.com" crossorigin="">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin="">
    <link rel="preconnect" href="https://www.google.com" crossorigin="">
    <link rel="preconnect" href="https://www.youtube.com" crossorigin="">
    <link rel="preconnect" href="https://cdnjs.cloudflare/" crossorigin="">
    <meta name="google-site-verification" content="y_3ez5wbHp4kZrUjZCeoYbNcS4JaGAfT8w1Xz07DU_M" />
    <!-- set the encoding of your site -->
    <meta charset="utf-8">
    <!-- set the viewport width and initial-scale on mobile devices -->
    <!-- set the HandheldFriendly -->
    <meta name="HandheldFriendly" content="True">
    <!-- set the description -->
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"/>
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name='description' content='@yield('description')'>
    <meta property='og:description' content='@yield('description_og')'>
    <meta name='twitter:description' content='@yield('description_tw')'>
    <meta property="og:image" content="@yield('image_og')">
    <meta name="twitter:image" content="@yield('image_tw')">
    <meta name="keywords" content='@yield('description')'>
    <meta name="author" content="مجموعة الجهود المشتركة">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'/>
    <!-- base url -->
    <meta name="base_url" content="{{url('/')}}">
    <link rel="canonical" href="{{ request()->url() }}">
    <!-- csrf token -->
    <meta name="csrf_token" content="{{ csrf_token() }}">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-BJHQG3246J"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());


        gtag('config', 'G-BJHQG3246J');
    </script>

    <!-- set the page title -->
    @if(app()->getLocale() == "en")
        <title>
            AL JHOOD - @yield('title')
        </title>
    @else
        <title class="rtl">
            الجهود - @yield('title')
        </title>
    @endif

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
    
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "مجموعة الجهود المشتركة",
  "url": "https://www.aljhood.com",
  "logo": "https://www.aljhood.com/public/frontend/images/logos/logo.png",
  "description": "مركز الجهود للتدريب هو مركز تدريبي معتمد يقدم برامج تدريبية متخصصة ومعتمدة في الأردن، السعودية، ليبيا، وتركيا. هدفنا تطوير المهارات المهنية والفنية لعملائنا.",
  "address": [
    {
      "@type": "PostalAddress",
      "addressCountry": "الأردن"
    },
    {
      "@type": "PostalAddress",
      "addressCountry": "السعودية"
    },
    {
      "@type": "PostalAddress",
      "addressCountry": "ليبيا"
    },
    {
      "@type": "PostalAddress",
      "addressCountry": "تركيا"
    }
  ],
  "keywords": "مركز تدريب, برامج تدريبية, تدريب معتمد, الأردن, السعودية, ليبيا, تركيا, تطوير المهارات, تدريب مهني, تدريب فني",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+962776708788",
    "contactType": "customer service",
    "availableLanguage": ["Arabic", "English"]
  }
}
</script>

    <!-- include google roboto font cdn link -->
    <link rel="preload"
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i"
        rel="stylesheet">
    <!-- include the site bootstrap stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
    <!-- include the plugins stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
    <!-- include the colors stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/colors.css") }}">
    <!-- include the custom stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/custom.css") }}">
    <!-- include the site responsive stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
    <!-- jquery ui -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
    <!-- include pannellum 360 image viewer -->
    {{-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/> --}}
    <!-- include animate css -->
    <link rel="preload" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
    <!-- air date picker -->
    <link href="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{ asset('frontend/amsifyselect/css/amsify.select.css') }}"/>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.pulse.is/livechat/loader.js" data-live-chat-id="670237d9e56f7eb62c0d5e62" async='async'></script>
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=67286397f1a61800125d516c&product=sop' async='async'></script>

    @if(app()->getLocale() == "ar")
        <style>


            @media only screen and (max-width: 600px) {
                .box {
                    margin: 0 auto !important;
                    padding: 15px !important;
                    min-height: 170px !important;
                    font-size: 9px !important;
                }

                .slick-arrow {
                    visibility: hidden;
                }

                .intro-block-heading {
                    font-size: 12px !important;
                }

            }

            .button7 {
                display: inline-block;
                border-radius: 4px;
                background-color: #be9f56;
                border: none;
                color: #000;
                text-align: center;
                padding: 20px;
                transition: all 0.5s;
                cursor: pointer;
                margin: 25px;
            }

            .button7 span {
                cursor: pointer;
                display: inline-block;
                position: relative;
                transition: 0.5s;
            }

            .button7 span:after {
                content: '\00bb';
                position: absolute;
                opacity: 0;
                top: 0;
                right: -20px;
                transition: 0.5s;
            }

            .button7:hover span {
                padding-right: 25px;
            }

            .button7:hover span:after {
                opacity: 1;
                right: 0;
            }

            .flip-card {
                background-color: transparent;
                perspective: 1000px;
            }

            .flip-card-inner {
                position: relative;
                width: 100%;
                text-align: center;
                transition: transform 0.6s;
                transform-style: preserve-3d;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                backface-visibility: hidden;
                -moz-backface-visibility: hidden;
            }

            .flip-card:focus {
                outline: 0;
            }

            .flip-card:hover .flip-card-inner,
            .flip-card:focus .flip-card-inner {
                transform: rotateY(180deg);
            }

            .flip-card-front,
            .flip-card-back {
                position: absolute;
                width: 100%;
            }

            .flip-card-front {
                color: black;
                z-index: 2;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .flip-card-back {
                transform: rotateY(180deg);
                z-index: 1;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            h3 {
                font-size: 20px;
                font-family: Verdana, sans-serif;
                font-weight: bold;
                color: #000;
            }


            .link-hover {
                background: linear-gradient(rgba(218, 165, 32, 0.2), rgba(218, 165, 32, 0.6));
                color: white;
                font-size: 21px !important;
            }

            .images-consultaion-type:hover {
                box-shadow: 0 0 100px gold;
            }


            @media (min-width: 768px) {
                .panel-heading1 {
                    display: none;
                }

                .panel {
                    border: none;
                    box-shadow: none;
                }

                .panel-collapse {
                    height: auto;

                    &.collapse {
                        display: block;
                    }
                }
            }

            @media (max-width: 767px) {
                .bookmarkCol {
                    margin-top: 0px !important;
                }

                .tab-content {
                    .tab-pane {
                        display: block;
                    }
                }

                .panel-title {
                    display: none;
                }

                .panel-title a {
                    display: block;
                }

                .panel {
                    margin: 0;
                    box-shadow: none;
                    border-radius: 0;
                    margin-top: -2px;
                }

                .tab-pane {
                    &:first-child {
                        .panel {
                            border-radius: 5px 5px 0 0;
                        }
                    }

                    &:last-child {
                        .panel {
                            border-radius: 0 0 5px 5px;
                        }
                    }
                }
            }

            .section_about .row {
                margin-top: 2%;
            }

            .section_about .row .col-md-6 {
                background: #f5f5f5;
                margin-right: -2%;
                padding: 5%;
            }

            .section_about p {
                margin-top: 2%;
                color: #545b62;
            }

            .section_about img {
                width: 100%;
            }

            :root {
                scroll-behavior: smooth;
            }

            .values .box {
                padding: 10px;
                box-shadow: 0px 0 5px rgba(1, 41, 112, 0.08);
                text-align: center;
                transition: 0.3s;
            }

            .values .box img {
                padding: 30px 50px;
                transition: 0.5s;
                transform: scale(1.1);
            }

            .values .box h1 {
                margin-bottom: 18px;
            }

            .values .box:hover {
                box-shadow: 0px 0 30px rgba(1, 41, 112, 0.08);
            }

            .values .box:hover img {
                transform: scale(1);
            }

            @media (min-width: 992px) {
                iframe {
                    min-height: 400px;
                }

            }

            @media (min-width: 1200px) {

                iframe {
                    min-height: 400px;
                }
            }

            @font-face {
                font-family: 'URWGeometric';
                src: url('{{ url('/') }}/frontend/css/fonts/URWG.ttf') format('truetype');
            }

            a, p, span, li, h1, h2, h3, h4, h6, input, label, textarea, datalist, dd, div, font, blockquote, strong {
                font-family: URWGeometric;
            }

            blockquote {
                font-family: URWGeometric !important;
            }

            li a {

            }

            strong {
                font-family: URWGeometric !important;
            }

            h3 a {
                font-family: URWGeometric !important;

            }

            .URWGeometric {
                font-family: URWGeometric !important;
            }

            .amsify-selection-area .amsify-selection-list ul.amsify-list li.amsify-list-item {
                text-align: right !important;
            }

            input[type="date"]:focus::before,
            input[type="date"]:valid::before {
                display: none
            }

            .training-block .nav-tabs {
                padding-right: 0 !important;
            }

            .file-input-1 input:before {
                padding: 1px 15px !important;
            }

            .apply-course-form label {
                text-align: right !important;
            }

            .application-info .app-title:after {
                left: unset !important;
            }

            .application-info .app-body:after {
                left: unset !important;
            }

            @media (min-width: 1200px) {
                .course-counter {
                    margin-top: 450px !important;
                }
            }

            .newsletter-sub-form .icn {
                margin-left: 19px;
            }

            .fooer-navigation > li:before {
                left: 105% !important;
            }

            .popular-posts-slider .slick-arrow {
                right: 86%;
            }

            @media (min-width: 767px) {
                .related-course-slider .slick-arrow {
                    right: 90% !important;
                }
            }


            @media (max-width: 992px) {
                .videos-slider .slick-arrow.slick-next {
                    left: 11% !important;
                }
            }

            @media (min-width: 993px) {
                .videos-slider .slick-arrow.slick-next {
                    left: 4% !important;
                }

                .news-slider .slick-arrow.slick-next {
                    right: unset;
                    left: 2%;
                }

                .news-slider .slick-arrow.slick-prev {
                    left: 0 !important;
                    right: unset !important;
                }
            }


            .videos-slider .slick-arrow.slick-prev {
                left: 0 !important;
            }

            .extra-slider .slick-arrow.slick-next {
                left: 11% !important;
            }

            .extra-slider .slick-arrow.slick-prev {
                left: 0 !important;
            }

            .extra2-slider .slick-arrow.slick-next {
                left: 11% !important;
            }

            .extra3-slider .slick-arrow.slick-prev {
                left: 0 !important;
            }

            .extra3-slider .slick-arrow.slick-next {
                left: 11% !important;
            }

            .extra2-slider .slick-arrow.slick-prev {
                left: 0 !important;
            }

            .partner-block .partner-list .fa-chevron-right {
                display: none !important;
            }

            .partner-block .partner-list .slick-prev {
                left: 4% !important;
            }

            .news-column-post .alignleft {
                margin: 0 0 0 -20px;
            }

            @media only screen and (max-width: 767px) {
                .popular-posts-slider .slick-arrow {
                    left: 14% !important;
                }

                .related-course-slider .slick-arrow {
                    left: 14% !important;
                }

                .flexing p {
                    font-size: 13px !important;
                }
            }


            .panel-heading [data-toggle="collapse"]:after {
                float: left;
            }

            .more-more {
                top: 63.5%;
            }

            .ft-address dt {
                float: right;
                margin: 2px 8px 0 20px;
            }

            .file-input-1 input:before {
                content: 'Choose File';
                left: unset !important;
            }

            #back-top {
                left: 20px;
            }

            #whats-app {
                left: 20px;
            }

            .compare-after {
                right: unset;
                left: 25px;
            }


            @media (min-width: 1025px) {
                .more-more {
                    position: absolute;
                    right: 88% !important;
                    top: 59.6%;
                }
            }

            @media (min-width: 1200px) {
                .more-more {
                    position: absolute;
                    right: 84% !important;
                    top: 58%;
                }
            }

            @media (min-width: 1400px) {
                .more-more {
                    position: absolute;
                    right: 80% !important;
                    top: 58.5%;
                }
            }

            @media (max-width: 767px) {
                .dropdown:after {
                    left: 4%;
                    right: unset !important;
                }
            }

            @media (max-width: 575px) {
                .dropdown:after {
                    left: 7%;
                    right: unset !important;
                }
            }

            .popular-course .fas, .popular-course .far, .popular-course .fa {
                transform: scaleX(-1);
            }

            .partner-block .partner-list .slick-next {
                display: none !important;
            }

            @media (max-width: 575px) {
                .testimonail-slider .slick-arrow {
                    bottom: unset;
                    top: -35px;
                }

                .testimonail-slider .fa-chevron-left {
                    left: 15% !important;
                }

                .testimonail-slider .fa-chevron-right {
                    left: 20% !important;
                }
            }

            @media (max-width: 767px) {

                .slick-arrow {
                    visibility: hidden;
                }
            }

        </style>

    @else
        <style>
            @media (max-width: 767px) {

                .slick-arrow {
                    visibility: hidden;
                }
            }

            @media only screen and (max-width: 600px) {
                .box {
                    margin: 0 auto !important;
                    padding: 2px !important;
                    font-size: 8px !important;
                }

                .intro-block-heading {
                    font-size: 12px !important;
                }
            }

            .read-more-show {
                cursor: pointer;
                color: #ed8323;
            }

            .read-more-hide {
                cursor: pointer;
                color: #ed8323;
            }

            .hide_content {
                display: none;
            }

            .button7 {
                display: inline-block;
                border-radius: 4px;
                background-color: #be9f56;
                border: none;
                color: #000;
                text-align: center;
                padding: 20px;
                transition: all 0.5s;
                cursor: pointer;
                margin: 25px;
            }

            .button7 span {
                cursor: pointer;
                display: inline-block;
                position: relative;
                transition: 0.5s;
            }

            .button7 span:after {
                content: '\00bb';
                position: absolute;
                opacity: 0;
                top: 0;
                right: -20px;
                transition: 0.5s;
            }

            .button7:hover span {
                padding-right: 25px;
            }

            .button7:hover span:after {
                opacity: 1;
                right: 0;
            }

            .flip-card {
                background-color: transparent;
                perspective: 1000px;
            }

            .flip-card-inner {
                position: relative;
                width: 100%;
                text-align: center;
                transition: transform 0.6s;
                transform-style: preserve-3d;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                backface-visibility: hidden;
                -moz-backface-visibility: hidden;
            }

            .flip-card:focus {
                outline: 0;
            }

            .flip-card:hover .flip-card-inner,
            .flip-card:focus .flip-card-inner {
                transform: rotateY(180deg);
            }

            .flip-card-front,
            .flip-card-back {
                position: absolute;
                width: 100%;
            }

            .flip-card-front {
                color: black;
                z-index: 2;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .flip-card-back {
                transform: rotateY(180deg);
                z-index: 1;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            h3 {
                font-size: 20px;
                font-family: Verdana, sans-serif;
                font-weight: bold;
                color: #000;
            }

            .flip-card-inner {
                position: relative;
                width: 100%;
                text-align: center;
                transition: transform 0.6s;
                transform-style: preserve-3d;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                backface-visibility: hidden;
                -moz-backface-visibility: hidden;
            }

            .flip-card:focus {
                outline: 0;
            }

            .flip-card:hover .flip-card-inner,
            .flip-card:focus .flip-card-inner {
                transform: rotateY(180deg);
            }

            .flip-card-front,
            .flip-card-back {
                position: absolute;
                width: 100%;
            }

            .flip-card-front {
                color: black;
                z-index: 2;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .flip-card-back {
                transform: rotateY(180deg);
                z-index: 1;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .link-hover {
                background: linear-gradient(rgba(218, 165, 32, 0.2), rgba(218, 165, 32, 0.6));
                color: white;
                font-size: 21px !important;
            }

            .images-consultaion-type:hover {
                box-shadow: 0 0 100px gold;
            }

            @media (min-width: 768px) {
                .panel-heading1 {
                    display: none;
                }

                .panel {
                    border: none;
                    box-shadow: none;
                }

                .panel-collapse {
                    height: auto;

                    &.collapse {
                        display: block;
                    }
                }
            }

            @media (max-width: 767px) {
                .bookmarkCol {
                    margin-top: 0px !important;
                }

                .tab-content {
                    .tab-pane {
                        display: block;
                    }
                }

                .panel-title {
                    display: none;
                }

                .panel-title a {
                    display: block;
                }

                .panel {
                    margin: 0;
                    box-shadow: none;
                    border-radius: 0;
                    margin-top: -2px;
                }

                .tab-pane {
                    &:first-child {
                        .panel {
                            border-radius: 5px 5px 0 0;
                        }
                    }

                    &:last-child {
                        .panel {
                            border-radius: 0 0 5px 5px;
                        }
                    }
                }
            }

            .section_about .row {
                margin-top: 2%;
                margin-bottom: 5%;
            }

            .section_about .row .col-md-6 {
                background: #f5f5f5;
                margin-right: -2%;
                padding: 2%;
            }

            .section_about p {
                margin-top: 2%;
                color: #545b62;
            }

            .section_about img {
                width: 100%;
            }

            :root {
                scroll-behavior: smooth;
            }

            .values .box {
                padding: 10px;
                box-shadow: 0px 0 5px rgba(1, 41, 112, 0.08);
                text-align: center;
                transition: 0.3s;
            }

            .values .box img {
                padding: 30px 50px;
                transition: 0.5s;
                transform: scale(1.1);
            }

            .values .box h1 {
                margin-bottom: 18px;
            }

            .values .box:hover {
                box-shadow: 0px 0 30px rgba(1, 41, 112, 0.08);
            }

            .values .box:hover img {
                transform: scale(1);
            }

            @media (min-width: 992px) {
                iframe {
                    min-height: 400px;
                }

            }

            @media (min-width: 1200px) {

                iframe {
                    min-height: 400px;
                }
            }

            @media (max-width: 575px) {
                .testimonail-slider .slick-arrow {
                    bottom: unset;
                    top: -35px;
                }

                .testimonail-slider .fa-chevron-left {
                    left: 83% !important;
                }

                .testimonail-slider .fa-chevron-right {
                    left: 85% !important;
                }
            }

            .partner-block .partner-list .slick-prev {
                display: none !important;
            }
        </style>

    @endif
</head>
<body>

@php
    $end_of_url = explode('.', \Request::route()->getName());
    $end_of_url = end($end_of_url);
      $content = App\Models\PageContent::where('ref_page','copyright')->get();
@endphp
<?php
$useragent = $_SERVER['HTTP_USER_AGENT'];
if (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i', $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i', substr($useragent, 0, 4))) {
    $devic = 1;

} else {
    $devic = 0;
}
?>
    <!-- main container of all the page elements -->
<div id="wrapper">
    <!-- header of the page -->

    @if(app()->getLocale() == "en")
            <?php $dir = "ltr";
            $order = "asc";
            $text_align = "text-align:left;";
            ?>
    @else
            <?php $dir = "rtl";
            $order = "desc";
            $text_align = "text-align:right;";
            ?>
    @endif
    @if($devic)
            <? $order = "asc"; ?>
    @endif
    <header id="page-header" class="page-header-stick"
            style="{{ ($end_of_url) != 'home' ? 'background: #222;' : '' }} direction: {{$dir}}">
        <!-- top bar -->
        <div class="top-bar bg-dark text-gray">
            <div class="container">
                <div class="row top-bar-holder">

                </div>
            </div>
        </div>
        <!-- header holder -->
        <div class="header-holder">
            <div class="col-lg-11" style="float:none !important;margin :auto">
                <div class="row">
                    <div class="col-xs-6 col-sm-3">
                        <!-- logo -->
                        <div class="logo">
                            <a href="{{ url('/') }}">
                                <img class="hidden-xs" src="{{ asset("frontend/images/logos/logo.png") }}"
                                     alt="aljhood">
                                <img class="hidden-sm hidden-md hidden-lg"
                                     src="{{ asset("frontend/images/logos/logo-dark.png") }}"
                                     alt="aljhood">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-6 col-sm-12 static-block">
                        <!-- nav -->
                        <nav id="nav" class="navbar navbar-default">
                            <!-- navbar collapse -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <!-- main navigation -->
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato">


                                    <?php
                                    $menu_items = DB::table('menu')->where('status', '=', 'active')->where('parent_id', '=', '0')->orderBy('element_order', $order)->get();
                                    $Name_Field = "name_" . app()->getLocale();
                                    ?>
                                    @foreach($menu_items as $menu_item)
                                            <?php $submenu_items = DB::table('menu')->where('status', '=', 'active')->where('parent_id', '=', $menu_item->id)->get();
                                            $submenu_item_found = DB::table('menu')->where('status', '=', 'active')->where('parent_id', '=', $menu_item->id)->first();
                                            ?>

                                        @if($submenu_item_found!=null)
                                            <li class="dropdown">
                                                <a href="{{ url($menu_item->url)}}" class="dropdown-toggle"
                                                   data-toggle="dropdown" role="button" aria-haspopup="true"
                                                   aria-expanded="false">{{$menu_item->$Name_Field}}</a>
                                                <ul class="dropdown-menu" style="{{$text_align}}">
                                                    @foreach($submenu_items as $submenu_item)
                                                        <li>
                                                            <a href="{{ url($submenu_item->url)}}">{{$submenu_item->$Name_Field}}</a>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            </li>
                                        @else
                                            @if($menu_item->name_en == 'Training Plan')


                                                <li>
                                                    @php

                                                        $useragent=$_SERVER['HTTP_USER_AGENT'];
                                                    @endphp
                                                    @if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4)))


                                                        <small
                                                            style="float: @if(app()->getLocale() == "en")  right  @else left  @endif;margin-top: -10px;background: red;padding: 0 4px;border-radius: 2px;color: #ffffff !important;position:absolute;right: 80px"> @if(app()->getLocale() == "en")
                                                                New
                                                            @else
                                                                جديد
                                                            @endif</small>
                                                        <a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a>




                                                    @else

                                                        <a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a>
                                                        <small
                                                            style="float: @if(app()->getLocale() == "en")  left @else right @endif;margin-top: -10px;background: red;padding: 0 4px;border-radius: 2px"> @if(app()->getLocale() == "en")
                                                                New
                                                            @else
                                                                جديد
                                                            @endif</small>

                                                    @endif


                                                </li>
                                            @else

                                                <li><a href="{{url($menu_item->url)}}">{{$menu_item->$Name_Field}}</a>
                                                </li>
                                            @endif

                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                            <!-- navbar form -->
                            <form action="{{ url('search') }}" method="GET"
                                  class="navbar-form navbar-search-form navbar-right">
                                <a class="fas fa-search search-opener" role="button" data-toggle="collapse"
                                   href="#searchCollapse" aria-expanded="false" aria-controls="searchCollapse">
                                    <span class="sr-only">search opener</span>
                                </a>
                                <!-- search collapse -->
                                <div class="collapse search-collapse" id="searchCollapse">
                                    <div class="form-group" DIR="LTR">
                                        <input type="text" name="search_word" pattern=".*\S+.*"
                                               title="This field is required" class="form-control"
                                               placeholder="Search for courses, news &hellip;" required="required">
                                        <button type="submit" class="fas fa-search btn"><span
                                                class="sr-only">search</span></button>
                                    </div>
                                </div>
                            </form>
                            <span class="lang_switcher" >
                                    @if(isset($lang))
                                    @if(str_contains(url()->current() , 'filterCourse'))
                                        <a id="changeLang" href="javascript:void(0)"
                                           class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                <span
                                                    class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                            @else
                                                EN
                                            @endif
                                            </a>
                                    @else
                                        <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '&lang=ar':request()->getRequestUri() . '&lang=en'}}"
                                           class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                <span
                                                    class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                            @else
                                                EN
                                            @endif
                                            </a>

                                    @endif
                                @else
                                    @if(str_contains(url()->current() , 'filterCourse'))
                                        <a id="changeLang" href="javascript:void(0)"
                                           class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                <span
                                                    class="{{ app()->getLocale() == "en" ? 'URWGeometric' : 'MotivaSans' }}">AR</span>
                                            @else
                                                EN
                                            @endif
                                            </a>
                                    @else
                                        <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}"
                                           class="lang-text">
                                            <i class="fa fa-globe"></i>
                                             @if(app()->getLocale() == "en")
                                                <span class="URWGeometric"
                                                      style="font-family: URWGeometric !important;">AR</span>
                                            @else
                                                EN
                                            @endif
                                            </a>
                                    @endif
                                @endif
                            </span>
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>


    <!-- contain main informative part of the site -->
    <main id="main">
        @yield('content')
    </main>


    <?php $logo = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'logo')->first();

    $header_all = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'header_ql')->OrWhere('type', '=', 'header_cu')->OrWhere('type', '=', 'header_lp')->orderBy('element_order', $order)->get();
    $header_ql = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'header_ql')->orderBy('element_order', 'asc')->first();
    $header_lp = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'header_lp')->orderBy('element_order', 'asc')->first();
    $header_cu = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'header_cu')->orderBy('element_order', 'asc')->first();
    $Name_Field = "name_" . app()->getLocale();

    $cantact_text = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'contact_text')->orderBy('element_order', 'asc')->first();
    $contact_location = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'contact_location')->orderBy('element_order', 'asc')->first();
    $contact_mobile = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'contact_mobile')->orderBy('element_order', 'asc')->first();
    $contact_email = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'contact_email')->orderBy('element_order', 'asc')->first();
    $copy_right_left = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'copy_right_left')->orderBy('element_order', 'asc')->first();
    $copy_right_center = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'copy_right_center')->orderBy('element_order', 'asc')->first();
    $copy_right_center = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'copy_right_center')->orderBy('element_order', 'asc')->first();
    $facebook = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'facebook')->orderBy('element_order', 'asc')->first();
    $twitter = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'twitter')->orderBy('element_order', 'asc')->first();
    $instagram = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'instagram')->orderBy('element_order', 'asc')->first();
    $linkedin = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'linkedin')->orderBy('element_order', 'asc')->first();
    $whatsapp = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'whatsapp')->orderBy('element_order', 'asc')->first();
    $youtube = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'youtube')->orderBy('element_order', 'asc')->first();
    $legals = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'legal')->orderBy('element_order', 'asc')->get();
    $Name_Field = "name_" . app()->getLocale();

    ?>


        <!-- footer area container -->
    <div class="footer-area bg-dark text-gray none-at-991 {{$dir}}" style="direction:{{$dir}}">
        <!-- aside -->
        <aside class="aside container">
            <div class="row">

                @foreach($header_all as $header)
                    @if($header->type=="header_cu")

                        <div class="col-xs-12 col-sm-12 col-md-4 col">
                            <h3>{{$header_cu->$Name_Field}}</h3>
                            <p>{{$cantact_text->$Name_Field}}</p>
                            <!-- ft address -->
                            <address class="ft-address">
                                <dl>
                                    <dt><span class="fas fa-map-marker"><span class="sr-only">marker</span></span></dt>
                                    <dd>{{$contact_location->$Name_Field}}</dd>
                                    <dt><span class="fas fa-phone-square"><span class="sr-only">phone</span></span></dt>
                                    <dd><a href="tel:{{$contact_mobile->$Name_Field}}"
                                           dir="ltr">{{$contact_mobile->$Name_Field}}</a></dd>
                                    <dt><span class="fas fa-envelope-square"><span class="sr-only">email</span></span>
                                    </dt>
                                    <dd>
                                        <a href="mailto:{{$contact_email->$Name_Field}}">{{$contact_email->$Name_Field}}</a>
                                    </dd>
                                </dl>
                            </address>
                        </div>
                    @elseif($header->type=="header_ql")
                        <div class="col-xs-6 col-sm-6 col-md-4 col">

                            <h3>{{$header_ql->$Name_Field}}</h3>

                            <!-- fooer navigation -->
                            <ul class="fooer-navigation list-unstyled">

                                    <?php
                                    $quick_links = DB::table('footer')->where('status', '=', 'active')->where('type', '=', 'quick_links')->orderBy('element_order', 'asc')->get();
                                    $Name_Field = "name_" . app()->getLocale();
                                    ?>
                                @foreach($quick_links as $quick_link)

                                    <li><a style="font-family:URWGeometric !important" href="{{url($quick_link->url)}}">{{$quick_link->$Name_Field}}</a></li>
                                @endforeach

                            </ul>
                        </div>
                    @else
                        <div class="col-xs-6 col-sm-6 col-md-4 col">

                            <h3>{{$header_lp->$Name_Field}}</h3>
                            <!-- fooer navigation -->
                            <ul class="fooer-navigation list-unstyled">

                                @foreach($legals as $legal)
                                    <li><a style="font-family:URWGeometric !important" href="{{url($legal->url)}}">{{$legal->$Name_Field}}</a></li>
                                @endforeach
                            </ul>
                        </div>

                    @endif
                @endforeach


            </div>
        </aside>
        <!-- page footer -->
        <footer id="page-footer" class="font-lato {{$dir}}">
            <div class="container">
                <div class="row holder">
                    <div class="col-xs-12  col-sm-4"
                         style="display: flex; flex-direction: row; justify-content: center;">
                        <small>{{$copy_right_left->$Name_Field}}</small>
                    </div>
                    <div class="col-xs-12  col-sm-4"
                         style="display: flex; flex-direction: row; justify-content: center;">

                        <p><a href="{{$copy_right_center->url}}" style="color:#2dbccc;"><img
                                    src="{{"/logo/".$logo->url }}" alt="aljhood" style="height:150px; width:200px;"></a>
                        </p>
                    </div>
                    <div class="col-xs-12 col-sm-4">
                        <ul class="socail-networks list-unstyled">

                            <li><a href="{{$facebook->url}}" target="_blank"><span class="fab fa-facebook"></span></a>
                            </li>
                            <li><a href="{{$twitter->url}}" target="_blank"><span class="fab fa-twitter"></span></a>
                            </li>
                            <li><a href="{{$instagram->url}}" target="_blank"><span class="fab fa-instagram"></span></a>
                            </li>
                            <li><a href="{{$linkedin->url}}" target="_blank"><span class="fab fa-linkedin"></span></a>
                            </li>
                            <li><a href="{{$whatsapp->url}}" target="_blank"><span class="fab fa-whatsapp"></span></a>
                            </li>
                            <li><a href="{{$youtube->url}}" target="_blank"><span class="fab fa-youtube"></span></a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <div class="modal fade bd-example-modal-lg" id="newsLetterFormModal" tabindex="-1" role="dialog"
         aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            @if(app()->getlocale()=="en")
                                <img src="{{ url('frontend/images/reports/Newsletter-en.jpeg') }}" alt="aljhood">
                            @else
                                <img src="{{ url('frontend/images/reports/Newsletter-ar.jpeg') }}" alt="aljhood">
                            @endif
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <a class="btn btn-theme btn-warning text-uppercase fw-bold"
                               href="{{ url('/aljhood/privacy-policy') }}" target="_blank">
                                {{ __('messages.Check_our_privacy_policy') }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- back top of the page -->
    <span id="back-top" class="text-center fa fa-caret-up"></span>
    <a href="{{$whatsapp->url}}" target="_blank"><span id="whats-app" class="text-center fab fa-whatsapp"></span></a>

    <!-- loader of the page -->
    <!--    <div id="loader" class="loader-holder">-->
    <!--        <div class="block"><img src="{{ asset("frontend/images/svg/hearts.svg") }}" width="100" alt="loader"></div>-->
    <!--    </div>-->
    <!--</div>-->


    <!-- include min jQuery -->
    <script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
    <!-- include Plugins -->
    <script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
    <!-- include jQuery -->
    <script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
    <!-- include init js -->
    <script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>
    <!-- include pannellum 360 image viewer -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js"></script>
    <!-- include custom js -->
    <script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>
    <!-- include jquery ui js -->
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- air date picker -->
    <script type="text/javascript" src="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.js"></script>
    <script src="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.en.js"></script>
    <script src="{{ asset("frontend/amsifyselect/js/jquery.amsifyselect.js") }}"></script>
    <script src="/path/to/js/jquery.amsifyselect.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <script>

        var locale = '{{request()->getRequestUri()}}';


        @if(app()->getLocale() == "en")
        $(document).ready(function () {

            if (localStorage.getItem('firstVisit') == null) {

                localStorage.setItem('firstVisit', 1);
                window.location.href = locale + '?lang=ar';
            }
        })
        @endif

    </script>


    <script>


        @if(app()->getLocale() == "en")
        $('.my-news-ticker').AcmeTicker({
            type: 'marquee',/*horizontal/horizontal/Marquee/type*/
            direction: 'left',/*up/down/left/right*/
            speed: 0.05,/*true/false/number*/ /*For vertical/horizontal 600*//*For marquee 0.05*//*For typewriter 50*/
            controls: {
                toggle: $('.acme-news-ticker-pause'),/*Can be used for horizontal/horizontal/typewriter*//*not work for marquee*/
            }
        });
        @else
        $('.my-news-ticker').AcmeTicker({
            type: 'marquee',/*horizontal/horizontal/Marquee/type*/
            direction: 'right',/*up/down/left/right*/
            speed: 0.05,/*true/false/number*/ /*For vertical/horizontal 600*//*For marquee 0.05*//*For typewriter 50*/
            controls: {
                toggle: $('.acme-news-ticker-pause'),/*Can be used for horizontal/horizontal/typewriter*//*not work for marquee*/
            }
        });
        @endif


        // pannellum.viewer('panorama', {
        //     "type": "equirectangular",
        //     "panorama": "https://pannellum.org/images/alma.jpg",
        //     "autoLoad": true
        // });

    </script>

    <script>
        $(window).load(function () {
            var newsHeight1 = $('#news1').innerHeight();
            $('#news2').css('height', newsHeight1 / 2);
            $('#news3').css('height', newsHeight1 / 2);
        });
    </script>

    <script>

        $(window).load(function () {
            var courseImageWidth = $('#courseImage').innerWidth();
            var courseDetailsWidth = $('#courseDetails').innerWidth();
            var courseDetailsHeight = $('#courseDetails').innerHeight();
            $('#courseDetails').css({
                width: courseImageWidth,
            });
            if (window.innerWidth < 991) {
                $('.inner-page-courses').css('margin-top', courseDetailsHeight)
            }
        });

        $(window).load(function () {
            var courseImageWidthAr = $('#courseImageAr').innerWidth();
            var courseDetailsWidthAr = $('#courseDetailsAr').innerWidth();
            var courseDetailsHeightAr = $('#courseDetailsAr').innerHeight();
            $('#courseDetailsAr').css({
                width: courseImageWidthAr,
            });
            if (window.innerWidth < 991) {
                $('.inner-page-courses').css('margin-top', courseDetailsHeightAr)
            }
        });

    </script>


    <script>
        $(window).load(function () {
            $('#achieve_img_icn').click(function () {
                $('#achieve_vid').css('display', 'none');
                $('#achieve_img').css('display', 'block');
            });
            $('#achieve_vid_icn').click(function () {
                $('#achieve_img').css('display', 'none');
                $('#achieve_vid').css('display', 'block');
            });
        });

    </script>

    <script>
        $(window).load(function () {
            $('#course_img_icn').click(function () {
                $('#course_vid').css('display', 'none');
                $('#courseImage').css('display', 'block');
            });
            $('#course_vid_icn').click(function () {
                $('#courseImage').css('display', 'none');
                $('#course_vid').css('display', 'block');
            });
        });

    </script>

    <script>
        $(document).ready(function () {
            $('.languages').select2();
        });
    </script>


    <script>

        $('#newsLetterForm').submit(function () {
            var formData = new FormData();
            var url = $('meta[name=base_url]').attr("content");
            var csrf_token = $('meta[name=csrf_token]').attr("content");
            formData.append("report_type", "contact");
            formData.append("email", $('#email').val());
            formData.append("_token", csrf_token);
            console.log(formData);

            $.ajax({
                url: url + '/newsletter',
                type: 'post',
                data: formData,
                cache: false,
                processData: false,
                contentType: false,
                success: function () {
                    console.log('Yes');
                    $('.popup').hide();
                    $('#newsLetterFormModal').modal('show');
                    $("#newsLetterForm")[0].reset();
                },
                error: function () {
                    console.log('error');
                }
            });
        })

        $('#popNewsLetterForm').submit(function () {
            var formData = new FormData();
            var url = $('meta[name=base_url]').attr("content");
            var csrf_token = $('meta[name=csrf_token]').attr("content");
            formData.append("report_type", "contact");
            formData.append("email", $('#email').val());
            formData.append("_token", csrf_token);
            console.log(formData);

            $.ajax({
                url: url + '/newsletter',
                type: 'post',
                data: formData,
                cache: false,
                processData: false,
                contentType: false,
                success: function () {
                    console.log('Yes');
                    $('.popup').hide();
                    $('#newsLetterFormModal').modal('show');
                    $("#popNewsLetterForm")[0].reset();
                },
                error: function () {
                    console.log('error');
                }
            });
        })

    </script>
    <script>
        $('.gallery-calendar').datepicker({
            language: 'en',
            dateFormat: 'mm-dd-yyyy',
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#social-links a').attr('target', '_blank');
        })
    </script>


    <script>
        AOS.init();
    </script>

    <script>


        var url_1 = $('meta[name=base_url]').attr("content");

        @if(app()->getLocale() == "en")
        $('#changeLang').click(function () {
            $.ajax({
                url: url + '/aljhood/courses?lang=ar',
                success: function () {
                    console.log('Yes');
                },
                error: function () {
                    console.log('error');
                }
            });
            window.location.href = url_1 + '/aljhood/courses';

        })
        @else
        $('#changeLang').click(function () {
            $.ajax({
                url: url + '/aljhood/courses?lang=en',
                success: function () {
                    console.log('Yes');
                },
                error: function () {
                    console.log('error');
                }
            });
            window.location.href = url_1 + '/aljhood/courses';
        })
        @endif

    </script>
    <script>
        $('.none-searchable-select').amsifySelect({
            type: 'materialize',
            hideButtons: true,
        });
        $('.searchable-select').amsifySelect({
            type: 'bootstrap',
            hideButtons: true,
            searchable: true,
        });

    </script>

    <script>
        var viewportContent = '';
        if (window.devicePixelRatio = 1) {
            viewportContent = 'width=device-width, initial-scale=0.6, maximum-scale=0.6, user-scalable=0, target-densityDpi=device-dpi';
        } else if (window.devicePixelRatio == 2) {
            viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0';
        } else if (window.devicePixelRatio == .78) {
            viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, target-densityDpi=device-dpi';
        } else if (window.devicePixelRatio == 1.5) {
            viewportContent = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, target-densityDpi=device-dpi';
        }
        // $('head').append('<meta name="viewport" content="' + viewportContent + '">');
    </script>
@yield('scripts')

</body>
</html>
