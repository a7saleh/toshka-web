<!doctype html>
<html lang="en">
<head>
    <title>Aljhood</title>

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
    <!-- include google roboto font cdn link -->
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i"
        rel="stylesheet">
    <!-- include the site bootstrap stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
    <!-- include the plugins stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
    <!-- include the site responsive stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
    <style>
        .body{
            border: 2px solid #BE9F56;
            border-radius: 20px;
            text-align: center;
        }
       .left-div{
           display: flex;
           flex-direction: column;
           justify-content: center;
           align-items: center;
            padding: 30px 50px;
       }
       .title-head h3{
           font-size: 30px;
           color: #BE9F56;
       }
        .right-div{
            background-color: #BE9F56;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-radius: 0 0 20px 20px;
        }
    </style>
</head>
<body>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="head">
                    <h2>Head</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium amet aspernatur cumque, id itaque laudantium libero maiores modi necessitatibus omnis quas quo reiciendis repellat tempore voluptas? Dolor earum soluta velit.</p>
                </div>
                <div class="body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="left-div">
                                <div class="img-head">
                                    <img src="{{  url('frontend/images/logos/logo-dark.png') }}" alt="" width="200">
                                </div>
                                <br>
                                <div class="title-head">
                                    <h3>We Appreciate Your interest</h3>
                                </div>
                                <br>
                                <div class="text-head">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad eveniet fugit maxime placeat porro quaerat voluptatem! Error et illum itaque maiores maxime minus odio repellat soluta. Consequuntur dicta, itaque?</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="right-div">
                                <img src="{{ url('frontend/images/reports/contact-us.png') }}" alt="">
                            </div>
                        </div>
                        <a href="{{ url('aljhood/privacy-policy') }}" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold">Privacy policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- include min jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
<!-- include Plugins -->
<script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
<!-- include jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
<!-- include init js -->
<script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>

<!-- include custom js -->
<script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>
</body>
</html>
