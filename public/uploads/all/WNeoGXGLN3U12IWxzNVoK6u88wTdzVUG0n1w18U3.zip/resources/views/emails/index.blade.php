<!doctype html>
<html lang="en">
<head>
    <title>Aljhood</title>
    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
    <!-- include google roboto font cdn link -->
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i"
        rel="stylesheet">
    <!-- include the site bootstrap stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
    <!-- include the plugins stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
    <!-- include the site responsive stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
</head>
<body>
<h1>{{ $details['title'] }}</h1>
<p>{{ $details['body'] }}</p>
<img src="{{ $details['path'] }}" alt="Image">
<br>
<div class="row" style="display: flex; flex-direction: row; justify-content: center; align-items: center">
    <div class="col-lg-12">
        <a href="{{ url('aljhood/privacy-policy') }}" class="btn btn-theme btn-warning text-uppercase font-lato fw-bold text-center">{{ $details['link_text'] }}</a>
    </div>
</div>


<!-- include min jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
<!-- include Plugins -->
<script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
<!-- include jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
<!-- include init js -->
<script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>

<!-- include custom js -->
<script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>
</body>
</html>
