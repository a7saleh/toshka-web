<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />

    <title> AL JHOOD | Admin Panel </title>

    <!-- Bootstrap -->
    <link href="{{url('/')}}/admintheme/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{url('/')}}{{url('/')}}/admintheme/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{url('/')}}{{url('/')}}/admintheme/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="{{url('/')}}/admintheme/build/css/custom.css" rel="stylesheet">

</head>
  <body class="login">

    <div>

      <div class="login_wrapper">
        <div class="form login_form" style="margin-top:45%;">
          <section class="login_content">
            <img src="{{ url('/') }}/admintheme/images/logo-dark.png" class="img-fluid" width="240">
              @if(Session::has('error'))
                <div class="alert alert-danger mt-3">
                  {{Session::get('error')}}
                </div>
              @endif
            <form action="{{url('admin/auth/login')}}" method="post">
              {!! csrf_field() !!}
              <h1 class="text-white">Login</h1>
              <div>
                <input type="email" class="form-control" name="email" placeholder="Email" required="" />
              </div>
              <div>
                <input type="password" class="form-control" name="password" placeholder="Password" required="" />
              </div>

              <div class="form-group">
                <input type="submit" class="btn btn-info btn-block ml-0" value="Login" style="background:#222; border: none;" />
              </div>

            </form>
              <div class="separator">
                <div>
                  <p class="text-white">©2021 All Rights Reserved. ALJHOOD</p>
                </div>
              </div>
          </section>
        </div>

      </div>
    </div>
  </body>
</html>
