
@extends('admin.layout.master')

@section('title', trans('messages.contact_us'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">


            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.contact_us') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <div class="date-range-filter">
                                    @csrf
                                    <div class="col-lg-12">
                                        <form action="{{ url('admin/reports/filter-teach') }}" method="get">
                                            <h2>Filter between Dates</h2>
                                            <div class="form-group">
                                                <label for="contactDateRange">First Date:</label>
                                                <input type="text" class="date-form-control report-calendar" name="first_date" value="@if(!empty($first_date)) {{ $first_date }} @endif" autocomplete="off" required>
                                                <label for="contactDateRange">Second Date:</label>
                                                <input type="text" class="date-form-control report-calendar" name="second_date" value="@if(!empty($second_date)) {{ $second_date }} @endif" autocomplete="off" required>
                                                <button type="submit" class="btn btn-success">Filter</button>
                                                <a href="{{ url('admin/reports/teach') }}" type="submit" class="btn btn-secondary">Reset</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <table id="galleryTable" class="table table-striped table-bordered dataTableReport" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>{{ trans('messages.name') }}</th>
                                        <th>{{ trans('messages.number') }}</th>
                                        <th>{{ trans('messages.email') }}</th>
                                        <th>{{ trans('messages.country') }}</th>
                                        <th>{{ trans('messages.nationality') }}</th>
                                        <th>{{ trans('messages.category') }}</th>
                                        <th>{{ trans('messages.languages') }}</th>
                                        <th>{{ trans('messages.resume') }}</th>
                                        <th>{{ trans('messages.message') }}</th>
                                        <th>{{ trans('messages.date') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($reports as $report)
                                        <tr>
                                            <td>
                                                <p> {{ $report->id }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->first_name }} {{ $report->last_name }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->area_code }} {{ $report->number }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->email }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->country }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->nationality }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->category }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $report->languages }} </p>
                                            </td>
                                            <td>
                                                @if(!empty($report->resume))
                                                <a href="{{ url('/storage/uploads/resumes/') }}/{{ $report->resume }}" class="btn btn-small btn-info">
                                                   {{ trans('messages.resume') }}
                                                </a>
                                                @endif
                                            </td>
                                            <td>
                                                <p> {{ $report->message }} </p>
                                            </td>
                                            <td>
                                                <p> {{ Carbon\Carbon::parse($report->created_at)->toDateString() }} </p>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
@section('script')
    <script>
        $(document).ready(function () {
            $('.dataTableReport').DataTable({
                "pageLength": 5,
                "order": [],
                "dom": 'Bfrtip',
                "stateSave": true,
                "buttons": [
                    {
                        extend: 'csv',
                    },
                ],
                "language": {
                    "emptyTable": "{{trans('messages.empty_table')}}",
                    "info": "{{trans('messages.showing')}} _START_ {{trans('messages.to')}} _END_ {{trans('messages.of')}} _TOTAL_ {{trans('messages.entries')}}",
                    "infoEmpty": "{{trans('messages.showing')}} 0 {{trans('messages.to')}} 0 {{trans('messages.of')}} 0 {{trans('messages.entries')}}",
                    "infoFiltered": "({{trans('messages.filtered_from')}} _MAX_ {{trans('messages.total_entries')}})",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "{{trans('messages.show')}} _MENU_ {{trans('messages.entries')}}",
                    "loadingRecords": "{{trans('messages.loading')}}...",
                    "processing": "{{trans('messages.processing')}}...",
                    "search": "{{trans('messages.search')}}:",
                    "zeroRecords": "{{trans('messages.no_matching_records_found')}}",
                    "paginate": {
                        "first": "{{trans('messages.first')}}",
                        "last": "{{trans('messages.last')}}",
                        "next": "{{trans('messages.next')}}",
                        "previous": "{{trans('messages.previous')}}"
                    },
                    "aria": {
                        "sortAscending": ": activate to sort column ascending",
                        "sortDescending": ": activate to sort column descending"
                    },
                },
                // 'aaSorting': [[3, 'desc']]
            });

            $('.buttons-csv').text('Export Excel').css({
                'background' : '#f2f2f2',
                'color' : 'green',
                'border' : '1px solid #f3f3f3'
            });

        });
    </script>
@endsection
