@extends('admin.layout.master')

@section('title', trans('messages.somethingweong'))

@section('body')

    <!-- Main content -->
    <div class="right_col" role="main">
        <div class="error-page">

            <div class="error-content">
                <h3><i class="fa fa-exclamation-triangle text-danger"></i> {{ trans('messages.somethingweong') }}. ( Server Error )</h3>

                <p>
                    {{ trans('messages.somethingweongmessage') }}
                     <a href="{{redirect()->back()->getTargetUrl()}}"> {{ trans('messages.click_back') }} </a>
                </p>
            </div>
        </div>
        <!-- /.error-page -->

    </div>
    <!-- /.content -->

@stop
