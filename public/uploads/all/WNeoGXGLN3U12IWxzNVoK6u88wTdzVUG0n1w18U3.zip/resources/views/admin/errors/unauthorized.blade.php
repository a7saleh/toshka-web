@extends('admin.layout.master')

@section('title', trans('messages.unauthorized'))

@section('body')

    <!-- Main content -->
    <div class="right_col" role="main">
        <div class="error-page">

            <div class="error-content">
                <h3><i class="fa fa-lock text-danger"></i> {{ trans('messages.unauthorized') }}.</h3>

                <p>
                     {{ trans('messages.you_do_not_have_permission_to_access_this_page') }}
                </p>
            </div>
        </div>
        <!-- /.error-page -->

    </div>
    <!-- /.content -->

@stop
