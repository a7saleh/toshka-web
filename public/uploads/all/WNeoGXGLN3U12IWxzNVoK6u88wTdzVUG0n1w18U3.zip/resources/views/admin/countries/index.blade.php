@extends('admin.layout.master')

@section('title', trans('messages.countries'))

@section('body')

<!-- page content -->


	<div class="right_col" role="main">
		<div class="col-md-12 col-sm-12">
		    @if(Session::has('success'))
              <div class="alert alert-success mt-3">
              {{Session::get('success')}}
              </div> 
            @endif
			<div class="x_panel">
				<div class="x-header mb-3">
					<h2 class="float-left"><small>{{ trans('messages.countries') }}</small></h2>
                    <a href="{{ route('countries.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}  </a>
				</div>
				<div class="x_content">
					<div class="row">
						<div class="col-sm-12">
							<div class="card-box table-responsive">
								<table id="countryTable" class="table table-striped table-bordered dataTable" style="width:100%">
			                      <thead>
			                        <tr>
					                  <th>ID</th>
					                  <th> {{ trans('messages.country') }} </th>
                                      <th> {{ trans('messages.name_ar') }} </th>
                                      <th> ISO code 2 </th>
                                      <th> ISO code 3</th>
                                      <th> {{ trans('messages.created_at') }} </th>
                                      <th> {{ trans('messages.control') }} </th>
			                        </tr>
			                      </thead>

			                      <tbody>
				                    @foreach($countries as $key => $country)                  
				                      	<tr>
											<td>{{ $country->id }}</td>
                                            <td>{{ $country->country_name }}</td>
                                            <td>{{ $country->country_name_ar }}</td>
                                            <td>{{ $country->country_iso_two_code }}</td>
                                            <td>{{ $country->country_iso_three_code }}</td>
                                            <td>{{ $country->created_at }}</td>
                                            <td>
                                                <form method="POST" action="{{ route('countries.destroy', $country->id) }}">
                                                        {{ csrf_field() }}
                                                        {{ method_field('DELETE') }}

                                                        <div class="form-group">
                                                            <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i>{{ trans('messages.delete') }} </a>
                                                        </div>
                                                    </form>

                                                    <a href="{{ route('countries.edit', $country->id) }}" class="btn btn-small btn-info">
                                                        <i class="fa fa-edit"></i> {{ trans('messages.update') }} 
                                                    </a>
                                            </td>
					                    </tr>
				                    @endforeach
			                      </tbody>

			                    </table>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
		</div>
	</div>

<!--// page content -->

@stop
