
@extends('admin.layout.master')

@section('title', trans('messages.news_slider'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.news_slider') }}</small></h2>
                    <a href="{{ route('newsSlider.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
                    </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th> ID </th>
                                        <th>Image 1</th>
                                        <th>Image 2</th>
                                        <th>Image 3</th>
                                        <th>{{ trans('messages.priority') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($news_slider as $news)
                                        <tr>
                                            <td>{{ $news->id }}</td>
                                            <td><img src="{{ asset("storage/uploads/newsSlider")}}/{{$news->image1 }}" alt="" width="150"></td>
                                            <td><img src="{{ asset("storage/uploads/newsSlider")}}/{{$news->image2 }}" alt="" width="150"></td>
                                            <td><img src="{{ asset("storage/uploads/newsSlider")}}/{{$news->image3 }}" alt="" width="150"></td>
                                            <td> @php echo $news->priority; @endphp </td>
                                            <td>
                                                <form method="POST" action="{{ route('newsSlider.destroy', $news->id) }}">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <div class="form-group">
                                                        <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                    </div>
                                                </form>

                                                <a href="{{ route('newsSlider.edit', $news->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
