@extends('admin.layout.master')

@section('title', trans('messages.users'))

@section('body')

<!-- page content -->


<div class="right_col" role="main">
  <div class="col-md-12 col-sm-12">

     @if(Session::has('success'))
      <div class="alert alert-success mt-3">
        {{Session::get('success')}}
      </div> 
     @endif

     <div class="x_panel">
        <div class="x-header mb-3">
          <h2 class="float-left"><small>{{ trans('messages.users') }}</small></h2>
          @if(Auth::user()->role_id == 1)
            <a href="{{ route('users.create') }}" class="btn btn-success float-right">
              <i class="fa fa-plus"></i> {{ trans('messages.add_new_user') }}  
            </a>
          @endif
        </div>

        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="userTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th> {{ trans('messages.email') }} </th>
                      <th> {{ trans('messages.first_name') }} </th>
                      <th> {{ trans('messages.mobile') }}</th>
                      <th> {{ trans('messages.role') }} </th>
                      <th> {{ trans('messages.register') }} </th>
                      <th> {{ trans('messages.view') }}  </th>
                      @if(Auth::user()->role_id == 1)
                      <th> {{ trans('messages.control') }}  </th>
                      @else {{ ' ' }}
                      @endif
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($users as $key => $user) 
                      <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{$user->email}}</td>
                        <td> {{ $user->first_name }} </td>
                        <td>{{$user->mobile_number}}</td>
                        @if(!empty($users[$key]->userRole->name))
                        <td>{{$users[$key]->userRole->name}}</td>
                        @else <td> </td>
                        @endif
                        <td>{{$user->created_at}}</td>
                        <td>
                          <button type="button" class="btn btn-success btn-view" data-toggle="modal" data-target="#userDetailsModal" id="{{ $user->id }}">
                          {{ trans('messages.view') }}
                          </button>
                        </td>
                        @if(Auth::user()->role_id == 1)
                        <td>
                            <form method="POST" action="{{ route('users.destroy', $user->id) }}">
                                {{ csrf_field() }}
                                {{ method_field('DELETE') }}

                                <div class="form-group">
                                    <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                </div>
                            </form>

                            <a href="{{ route('users.edit', $user->id) }}" class="btn btn-small btn-info">
                                <i class="fa fa-edit"></i> {{ trans('messages.update') }} 
                            </a>
                        </td>
                        @else {{ ' ' }}
                        @endif
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

     </div>

  </div>

    <div class="modal fade" id="userDetailsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"></h5>
              <h3>{{ trans('messages.details') }}</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            </div>
          </div>
        </div>
    </div>

</div>

<!--// page content -->

@stop

 @section('script')
  <script>

    $('.btn-view').click(function(){

      $("#userDetailsModal .modal-body").empty();

      var url        = $('meta[name=base_url]').attr('content');
      var csrf_token = $('meta[name=csrf_token]').attr('content');
      var id         = $(this).attr('id');

      $.ajax({
        url : url+'/admin/userDetails',
        method: 'POST',
        data:{
          id:id,
          _token : csrf_token
        },
        success:function(response){

          $("#userDetailsModal .modal-body").append(
            '<table class="table">'+
            '<tr>'+
            '<th class="border-0"> ID </th>'+
            '<td class="border-0 text-right"> '+ response.user.id +' </td>'+
            '</tr>'+
            '<tr style="border-top: 1px solid #dee2e6;">'+
            '<th class="border-0"> {{ trans('messages.first_name') }} </th>'+
            '<td class="border-0 text-right"> '+ response.user.first_name +' </td>'+
            '</tr>'+
            '<tr style="border-top: 1px solid #dee2e6;">'+
            '<th class="border-0"> {{ trans('messages.middle_name') }} </th>'+
            '<td class="border-0 text-right"> '+ response.user.middle_name +' </td>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.last_name') }} </th>'+
            '<td class="text-right"> '+ response.user.last_name +' </td>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.email') }} </th>'+
            '<td class="text-right"> '+ response.user.email +' </td>'+
            '</tr>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.country') }} </th>'+
            '<td class="text-right"> '+ response.user.country.country_name  +' </td>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.mobile') }} </th>'+
            '<td class="text-right"> '+ response.user.mobile_number +' </td>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.country_code') }} </th>'+
            '<td class="text-right"> '+ response.user.mobile_country_code +' </td>'+
            '</tr>'+
            '<tr>'+
            '<th> {{ trans('messages.role') }} </th>'+
            '<td class="text-right"> '+ response.user.user_role.name +' </td>'+
            '</tr>'+
            '</table>'
          );//append
        },
        errors:function(xhr){
          console.log(xhr.responseText);
        }
      });//ajax

    })


    //block user
    $('.btn-block-user').click(function(){

      if(confirm('Are you sure you want to block this user?')){

        var url = $('meta[name=base_url]').attr('content');
        var csrf_token = $('meta[name=csrf_token]').attr('content');
        var id = $(this).attr('id');
        $.ajax({

          url:url+'/blockUser',
          method: "POST",
          data:{
            _token : csrf_token,
            id : id,
          },

          success:function(response){
            if(response.status == true){
                alert('User has been blocked!');
                window.location.reload();
             }
          },

          error:function(request, status, error){
            console.log(request.responseText);
          }

        });//ajax
      }

    });

  </script>
 @stop