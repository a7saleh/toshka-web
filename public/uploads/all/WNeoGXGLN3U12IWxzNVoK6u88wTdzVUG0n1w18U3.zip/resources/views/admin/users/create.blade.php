@extends('admin.layout.master')

@section('title' ,  trans('messages.add_new_user') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.users') . ' / ' . trans('messages.add') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('users.store') }}" enctype="multipart/form-data" data-parsley-validate class="form-horizontal form-label-left">
                    {!! csrf_field() !!}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">{{ trans('messages.first_name') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="first_name" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="middle-name">{{ trans('messages.middle_name') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="middle-name" name="middle_name" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">{{ trans('messages.last_name') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="last-name" name="last_name" required="required" class="form-control">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="email">{{ trans('messages.email') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="email" id="email" name="email" required="required" class="form-control">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="password">{{ trans('messages.password') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="password" id="password" name="password" required="required" class="form-control">
                      </div>
                    </div>

                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align">{{ trans('messages.countries') }} <span class="required">*</span> </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select id="country_list" class="select2_single form-control" required tabindex="-1" name="country_id">
                          <option disabled="disabled" selected="selected"> Select Country </option>
                          @foreach ($countries as $country)
                             <option value="{{ $country->id }}">{{ $country->country_name }}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="country-code">{{ trans('messages.country_code') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6">
                        <input type="text" id="country-code" name="mobile_country_code" required="required" class="form-control disabled" maxlength="5" minlength="2" readonly="readonly">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="mobile-number">{{ trans('messages.mobile') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="mobile" name="mobile_number" required="required" maxlength="10" minlength="10" onkeypress="return isIntegerKey(event)" class="form-control">
                      </div>
                    </div>


                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align">{{ trans('messages.role') }} <span class="required">*</span> </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select class="select2_single form-control" required tabindex="-1" name="role_id">
                          <option disabled="disabled" selected="selected"> Select user role </option>
                          @foreach ($user_roles as $role)
                             <option value="{{ $role->id }}">{{ $role->name }}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop


@section('script')

<script>
  
  var url = $('meta[name=base_url]').attr('content');
  var csrf_token = $('meta[name=csrf_token]').attr('content');

  $('#country_list').on('change',function(){

    var country_id = $(this).val();

    $.ajax({
      url:url+'/admin/getMobileCountryCode',
      method: "POST",
      data:{
        country_id: country_id,
        _token:csrf_token
      },

      success:function(response){
        if(response.status == 200){
          if(response.code.length > 0){
            $('#country-code').attr('value','');
            $('#country-code').attr('value',response.code[0].mob_country_code);
          }else{
            alert('There is no mobile country code for this country');
          }
        }
      },

      error:function(xhr){
        console.log(xhr.responseText);
      }

    })

  })

</script>

@stop