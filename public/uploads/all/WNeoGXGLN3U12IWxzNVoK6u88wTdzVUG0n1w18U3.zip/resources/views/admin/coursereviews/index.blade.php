
@extends('admin.layout.master')

@section('title', 'Course Reviews')

@section('body')

<!-- course review content -->


  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">

        @if(Session::has('success'))
          <div class="alert alert-success mt-3">
          {{Session::get('success')}}
          </div> 
        @endif

        <div class="x_panel">
          <div class="x-header mb-3">
            <h2 class="float-left"><small> Course Reviews </small></h2>
              <a href="{{ route('coursereviews.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}  
              </a>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="courseReviewTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th> ID </th>
                      <th>Review</th>
                      <th>Stars</th>
                      <th>Related Course</th>
                      <th>Control </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($coursereviews as $review)
                        <tr>
                          <td>{{ $review->id }}</td>
                          <td style="word-break: break-word;">{{ $review->review }}</td>
                          <td>{{ $review->stars }}</td>
                          <td> <a href="{{ url('admin/courses') }}/{{ $review->course->id }}/edit" target="_blank"> {{ $review->course->title_en }} </a> </td>
                          <td>
                            <form method="POST" action="{{ route('coursereviews.destroy', $review->id) }}">
                              {{ csrf_field() }}
                              {{ method_field('DELETE') }}

                              <div class="form-group">
                                  <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                              </div>
                            </form>

                            <a href="{{ route('coursereviews.edit', $review->id) }}" class="btn btn-small btn-info">
                                <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }} 
                            </a>
                          </td>
                        </tr>
                        @endforeach
                        </tbody>
                      </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
<!--// course review content -->

@stop
