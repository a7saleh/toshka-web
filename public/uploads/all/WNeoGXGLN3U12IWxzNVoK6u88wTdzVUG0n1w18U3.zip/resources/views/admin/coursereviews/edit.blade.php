@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ 'Course Review' . ' / ' . trans('messages.update') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('coursereviews.update', $CourseReview->id) }}" data-parsley-validate class="form-horizontal form-label-left">
                    {!! csrf_field() !!}
                    {{ method_field('PUT') }}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="review"> Review <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="review"> {{ $CourseReview->review }} </textarea>
                      </div>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="stars"> Stars <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="stars" name="stars" value="{{ $CourseReview->stars }}" onkeypress="return isIntegerKey(event)" required="required" class="form-control ">
                      </div>
                    </div>


                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="difficulty"> Courses <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select name="course_id" class="form-control" id="difficulty">
                          <option value="" disabled="disabled">...</option>
                          @foreach($courses as $course)
                          <option value="{{ $course->id }}" {{ ($course->id == $CourseReview->course_id) ? 'selected' : '' }}> {{ $course->title_en }} </option>
                          @endforeach
                        </select>
                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
