
@extends('admin.layout.master')

@section('title', trans('messages.leadership'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.blocks') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.description_en') }}</th>
                                        <th>{{ trans('messages.description_ar') }}</th>
                                        <th>{{ trans('messages.image') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($contents as $content)
                                        <tr>
                                            <td>
                                                <p> {{ $content->title_en }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $content->title_ar }} </p>
                                            </td>
                                            <td>
                                                <p> @php echo  $content->description_en; @endphp </p>
                                            </td>
                                            <td>
                                                <p> @php echo  $content->description_ar; @endphp </p>
                                            </td>
                                            <td>
                                                <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" alt="" width="200">
                                            </td>
                                            <td>
                                                <a href="{{ route('blocks.edit', $content->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
