<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- base url -->
    <meta name="base_url" content="{{url('/')}}">
    <!-- csrf token -->
    <meta name="csrf_token" content="{{ csrf_token() }}">


    <title> AL JHOOD | @yield('title') </title>

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>

    <!-- Bootstrap -->
    <link href="{{ url('/') }}/admintheme/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- datatable cdn -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <!-- Font Awesome -->
    <link href="{{ url('/') }}/admintheme/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{ url('/') }}/admintheme/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="{{ url('/') }}/admintheme/vendors/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- bootstrap-wysiwyg -->
    <link href="{{ url('/') }}/admintheme/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">

    <!-- Datatables -->
    <link href="{{ url('/') }}/admintheme/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="{{ url('/') }}/admintheme/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css"
          rel="stylesheet">
    <link href="{{ url('/') }}/admintheme/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css"
          rel="stylesheet">
    <link href="{{ url('/') }}/admintheme/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css"
          rel="stylesheet">
    <link href="{{ url('/') }}/admintheme/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css"
          rel="stylesheet">

    <!-- bootstrap-progressbar -->
    <link href="{{ url('/') }}/admintheme/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css"
          rel="stylesheet">
    <!-- JQVMap -->
    <link href="{{ url('/') }}/admintheme/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="{{ url('/') }}/admintheme/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Select2 -->
    <link rel="stylesheet" href="{{url('/')}}/admintheme/vendors/select2/dist/css/select2.min.css">

    <!-- air date picker -->
    <link href="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.css" rel="stylesheet" type="text/css">

    <!-- amimate -->
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">

    <!-- Custom Theme Style -->
    <link href="{{ url('/') }}/admintheme/build/css/custom.css" rel="stylesheet">
    <!-- Select 2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    @if(app()->getLocale() == "ar")
        <style>
            @font-face {
                font-family: 'URWGeometric';
                src: url('{{ url('/') }}/frontend/css/fonts/URWG.ttf') format('truetype');
            }
            a, p, span, li, h1, h2, h3, h4, h5, h6, input, label, textarea, datalist , dd , div , font , blockquote , strong{
                font-family: URWGeometric;
            }
            blockquote{
                font-family: URWGeometric !important;
            }
            li a{
                font-family: URWGeometric !important;
            }
            strong{
                font-family: URWGeometric !important;
            }

            h3  a{
                font-family: URWGeometric !important;

            }
        </style>
        
    @else
    
    @endif

</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title mt-3 mb-3" style="border: 0;">
                    <div class="img-holder" style="margin-left:auto; margin-right: auto; margin-bottom: 15px; ">
                        <img src="{{ url('/') }}/admintheme/images/logo.png" class="img-fluid" width="150">
                    </div>
                </div>
                <div class="clearfix"></div>

                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">

                        <ul class="nav side-menu">

                            <li class="{{ request()->is('admin/home') ? 'active' : '' }}">
                                <a href="{{ url('admin/home') }}">
                                    <i class="fa fa-circle"></i>
                                    {{ trans('messages.home') }}
                                </a>
                            </li>

                            <li class="{{ request()->is('admin/users*') ? 'active' : '' }}">
                                <a href="{{ url('admin/users') }}">
                                    <i class="fa fa-users"></i>
                                    {{ trans('messages.users') }}
                                </a>
                            </li>

                            <li class="">
                                <a><i class="fa fa-globe"></i> {{ trans('messages.countries') }}
                                    <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu" style="display: none;">
                                    <li class="{{ request()->is('admin/countries*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/countries') }}">
                                            <i class="fa fa-globe"></i>
                                            {{ trans('messages.countries') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/mobilecountrycodes*') ? 'current-page' : '' }} ">
                                        <a href="{{ url('admin/mobilecountrycodes') }}"> <i
                                                class="fa fa-phone"></i> {{ trans('messages.mobile_country_codes') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="">
                                <a><i class="fa fa-book"></i>{{ trans('messages.courses') }}
                                    <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu" style="display: none;">
                                    <li class="{{ request()->is('admin/courses*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/courses') }}">
                                            <i class="fa fa-book"></i>
                                            {{ trans('messages.courses') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/subject*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/subject') }}">
                                            <i class="fa fa-graduation-cap"></i>
                                            {{ trans('messages.subject_area') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/venue*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/venue') }}">
                                            <i class="fa fa-map-marker"></i>
                                            {{ trans('messages.venue') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/activity*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/activity') }}">
                                            <i class="fa fa-bar-chart"></i>
                                            {{ trans('messages.activity_type') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/courseApplication*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/courseApplication') }}">
                                            <i class="fa fa-book"></i>
                                            {{ trans('messages.courseApplication') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="">
                                <a><i class="fa fa-file-o"></i>{{ trans('messages.home_page') }}
                                    <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu" style="display: none;">
                                    <li class="{{ request()->is('admin/home-page/menu*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/menu') }}">
                                            <i class="fa fa-bars"></i>
                                            {{ trans('messages.menu') }}
                                        </a>
                                    </li>                                   
                                    <li class="{{ request()->is('admin/home-page/blocks*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/blocks') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.blocks') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/home-page/slider*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/slider') }}">
                                            <i class="fa fa-image"></i>
                                            {{ trans('messages.slider') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/home-page/media_center*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/media_center') }}">
                                            <i class="fa fa-file-video-o"></i>
                                            {{ trans('messages.media_center') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/home-page/testimonial*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/testimonial') }}">
                                            <i class="fa fa-comment"></i>
                                            {{ trans('messages.testimonials') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/home-page/counter*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/counter') }}">
                                            <i class="fa fa-circle-o"></i>
                                            {{ trans('messages.counters') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/home-page/home-content*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/home-content') }}">
                                            <i class="fa fa-file-text-o"></i>
                                            {{ trans('messages.content') }}
                                        </a>
                                    </li>
                                        <li class="{{ request()->is('admin/home-page/footer*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/home-page/footer') }}">
                                            <i class="fa fa-bars"></i>
                                            {{ trans('messages.footer') }}
                                        </a>
                                    </li>  
                                </ul>
                            </li>
                            <li class="{{ request()->is('admin/news') ? 'active' : '' }}">
                                <a href="{{ url('admin/news') }}">
                                    <i class="fa fa-list"></i>
                                    {{ trans('messages.news') }}
                                </a>
                            </li>
                            <li class="{{ request()->is('admin/newsSlider*') ? 'active' : '' }}">
                                <a href="{{ url('admin/newsSlider') }}">
                                    <i class="fa fa-image"></i>
                                    {{ trans('messages.news_slider') }}
                                </a>
                            </li>
                            <li class="{{ request()->is('admin/blog_sliders*') ? 'active' : '' }}">
                                <a href="{{ url('admin/blog_sliders') }}">
                                    <i class="fa fa-image"></i>
                                    {{ trans('messages.blog_sliders') }}
                                </a>
                            </li>

                            <li class="{{ request()->is('admin/gallery*') ? 'active' : '' }}">
                                <a href="{{ url('admin/gallery') }}">
                                    <i class="fa fa-image"></i>
                                    {{ trans('messages.gallery') }}
                                </a>
                            </li>
                            <li class="{{ request()->is('admin/titles*') ? 'active' : '' }}">
                                <a href="{{ url('admin/titles') }}">
                                    <i class="fa fa-image"></i>
                                    {{ trans('messages.titles') }}
                                </a>
                            </li>                            
                            <li class="">
                                <a><i class="fa fa-file-o"></i>{{ trans('messages.pages') }}
                                    <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu" style="display: none;">
                                    <li class="{{ request()->is('admin/training*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/training') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.training') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/extra*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/extra') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.extra') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/consultancy*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/consultancy') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.consultancy') }}
                                        </a>
                                    </li>

                                    <li class="{{ request()->is('admin/faq*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/faq') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.faq') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/contact-us*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/contact-us') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.contact_us') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/about-us-head*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/about-us-head') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.about-us-head') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/about-us*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/about-us') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.about_us') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/join-us*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/join-us') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.join_us') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/leadership*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/leadership') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.leadership') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/brands*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/brands') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.brands') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/our-impact*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/our-impact') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.our-impact') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/strategy*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/strategy') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.strategy') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/achievements*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/achievements') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.achievements') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/terms-of-use*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/terms-of-use') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.terms-of-use') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/privacy-policy*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/privacy-policy') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.privacy-policy') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/copyright') ? 'active' : '' }}">
                                        <a href="{{ url('admin/copyright') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.year') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/copyright-page*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/copyright-page') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.copyright') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="{{ request()->is('admin/coursereviews*') ? 'active' : '' }}">
                                <a href="{{ url('admin/coursereviews') }}">
                                    <i class="fa fa-star"></i>
                                    {{ trans('messages.courses_reviews') }}
                                </a>
                            </li>
                            <li class="{{ request()->is('admin/video-reviews*') ? 'active' : '' }}">
                                <a href="{{ url('admin/video-reviews') }}">
                                    <i class="fa fa-star"></i>
                                    {{ trans('messages.video-reviews') }}
                                </a>
                            </li>
                            <li class="{{ request()->is('admin/trusted_accreditation*') ? 'active' : '' }}">
                                <a href="{{ url('admin/trusted_accreditation') }}">
                                    <i class="fa fa-certificate"></i>
                                    {{ trans('messages.trusted_by_and_accreditation') }}
                                </a>
                            </li>

                            <li class="{{ request()->is('admin/newsletter*') ? 'active' : '' }}">
                                <a href="{{ url('admin/newsletter') }}">
                                    <i class="fa fa-envelope"></i>
                                    {{ trans('messages.newsletter') }}
                                </a>
                            </li>
                            <li class="">
                                <a><i class="fa fa-file-o"></i>{{ trans('messages.reports') }}
                                    <span class="fa fa-chevron-down"></span></a>
                                <ul class="nav child_menu" style="display: none;">
                                    <li class="{{ request()->is('admin/reports/contact*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/reports/contact') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.contact_us') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/reports/join*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/reports/join') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.join_us') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/reports/suggest*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/reports/suggest') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.suggest_course') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/reports/teach*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/reports/teach') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.apply_teach') }}
                                        </a>
                                    </li>
                                    <li class="{{ request()->is('admin/reports/reseller*') ? 'active' : '' }}">
                                        <a href="{{ url('admin/reports/reseller') }}">
                                            <i class="fa fa-file-o"></i>
                                            {{ trans('messages.reseller') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>

                        @if(Auth::user()->role_id == 1)
                                <li class="{{ request()->is('admin/permissions*') ? 'active' : '' }}">
                                    <a href="{{ url('admin/permissions') }}">
                                        <i class="fa fa-lock"></i>
                                        {{ trans('messages.permissions') }}
                                    </a>
                                </li>
                            @endif

                        </ul>


                    </div>
                </div>
                <!-- /sidebar menu -->
            </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <div class="nav toggle">
                    <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div>
                <nav class="nav navbar-nav">
                    <ul class=" navbar-right">

                        <li class="nav-item dropdown open" style="padding-left: 15px;">
                            <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true"
                               id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                                {{ Auth::user()->first_name }}
                            </a>
                            <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item"
                                   href="{{ route('users.edit', Auth::id()) }}"> {{ trans('messages.profile') }} <i
                                        class="fa fa-user pull-right"></i> </a>
                                <a class="dropdown-item" href="{{ url('admin/auth/logout') }}"><i
                                        class="fa fa-sign-out pull-right"></i> {{ trans('messages.logout') }} </a>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}">
                                <i class="fa fa-globe"></i>
                                @if(app()->getLocale() == "en")
                                    العربية
                                @else
                                    English
                                @endif
                            </a>

                        </li>

                        <li class="nav-item pr-3">
                            <a href="{{ url('/') }}" target="_blank" style="font-weight: 600;">
                                <i class="fa fa-step-forward"></i>
                                @if(app()->getLocale() == "en")
                                    Visit Site
                                @else
                                    زيارة الموقع
                                @endif
                            </a>
                        </li>

                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->

    @yield('body')

    <!--// page content -->

        <!-- footer content -->
        <footer>
            <div class="pull-right">
                AL JHOOD - Powered By <a href="https://rumman.tech" target="_blank">Rumman.tech</a>
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->
<script src="{{ url('/') }}/admintheme/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="{{ url('/') }}/admintheme/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="{{ url('/') }}/admintheme/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="{{ url('/') }}/admintheme/vendors/nprogress/nprogress.js"></script>
<!-- Chart.js -->
<script src="{{ url('/') }}/admintheme/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="{{ url('/') }}/admintheme/vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="{{ url('/') }}/admintheme/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="{{ url('/') }}/admintheme/vendors/iCheck/icheck.min.js"></script>
<!-- Datatables -->
<script src="{{ url('/') }}/admintheme/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<!-- Skycons -->
<script src="{{ url('/') }}/admintheme/vendors/skycons/skycons.js"></script>
<!-- Flot -->
<script src="{{ url('/') }}/admintheme/vendors/Flot/jquery.flot.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/Flot/jquery.flot.pie.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/Flot/jquery.flot.time.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/Flot/jquery.flot.stack.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/Flot/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="{{ url('/') }}/admintheme/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/flot.curvedlines/curvedLines.js"></script>
<!-- DateJS -->
<script src="{{ url('/') }}/admintheme/vendors/DateJS/build/date.js"></script>
<!-- JQVMap -->
<script src="{{ url('/') }}/admintheme/vendors/jqvmap/dist/jquery.vmap.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{ url('/') }}/admintheme/vendors/moment/min/moment.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="https://cdn.datatables.net/datetime/1.1.1/js/dataTables.dateTime.min.js"></script>

<!-- bootstrap-datetimepicker -->
<script
    src="{{ url('/') }}/admintheme/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

<!-- air date picker -->
<script type="text/javascript" src="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/air-datepicker/datepicker.en.js"></script>

<!-- bootstrap-wysiwyg -->
<script src="{{ url('/') }}/admintheme/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
<script src="{{ url('/') }}/admintheme/vendors/google-code-prettify/src/prettify.js"></script>

<!-- -->
<script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>

<!-- Select2 -->
<script src="{{url('/')}}/admintheme/vendors/select2/dist/js/select2.full.min.js"></script>
<!-- SummerNote Editor -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
    $(document).ready(function () {
        $('.dataTable').DataTable({
            "pageLength": 5,
            "order": [],
            "language": {
                "emptyTable": "{{trans('messages.empty_table')}}",
                "info": "{{trans('messages.showing')}} _START_ {{trans('messages.to')}} _END_ {{trans('messages.of')}} _TOTAL_ {{trans('messages.entries')}}",
                "infoEmpty": "{{trans('messages.showing')}} 0 {{trans('messages.to')}} 0 {{trans('messages.of')}} 0 {{trans('messages.entries')}}",
                "infoFiltered": "({{trans('messages.filtered_from')}} _MAX_ {{trans('messages.total_entries')}})",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "{{trans('messages.show')}} _MENU_ {{trans('messages.entries')}}",
                "loadingRecords": "{{trans('messages.loading')}}...",
                "processing": "{{trans('messages.processing')}}...",
                "search": "{{trans('messages.search')}}:",
                "zeroRecords": "{{trans('messages.no_matching_records_found')}}",
                "paginate": {
                    "first": "{{trans('messages.first')}}",
                    "last": "{{trans('messages.last')}}",
                    "next": "{{trans('messages.next')}}",
                    "previous": "{{trans('messages.previous')}}"
                },
                "aria": {
                    "sortAscending": ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                },
            },
            // 'aaSorting': [[3, 'desc']]
        });

    });

    $('.delete-btn').click(function (e) {
        if (confirm('Are you sure you want to delete this item?'))
            $(e.target).closest('form').submit();
    });

    $('.hide-btn').click(function (e) {
        if (confirm('Are you sure you want to hide this item?'))
            $(e.target).closest('form').submit();
    });
    $('.unhide-btn').click(function (e) {
        if (confirm('Are you sure you want to Unhide this item?'))
            $(e.target).closest('form').submit();
    });

    //generate select2
    $('.select2_single').select2();
    $('.select2_multiple').select2();
    $('.select2_group').select2();

    // Initialization
    $('.calendar').datepicker({
        language: 'en',
        dateFormat: 'mm-dd-yyyy',
        minDate: new Date()
    });

    $('.report-calendar').datepicker({
        language: 'en',
        dateFormat: 'yyyy-mm-dd',
    });


    ClassicEditor
        .create(document.querySelector('#rich_text1'))
        .then(editor => {
            editor.model.document.on('change:data', () => {
                editorData = editor.getData();
            });
        })
        .catch(error => {
            console.error(error);
        });


    ClassicEditor
        .create(document.querySelector('#rich_text2'))
        .then(editor => {
            editor.model.document.on('change:data', () => {
                editorData = editor.getData();
            });
        })
        .catch(error => {
            console.error(error);
        });

    ClassicEditor
        .create(document.querySelector('#rich_text3'))
        .then(editor => {
            editor.model.document.on('change:data', () => {
                editorData = editor.getData();
            });
        })
        .catch(error => {
            console.error(error);
        });

    ClassicEditor
        .create(document.querySelector('#rich_text4'))
        .then(editor => {
            editor.model.document.on('change:data', () => {
                editorData = editor.getData();
            });
        })
        .catch(error => {
            console.error(error);
        });

    ClassicEditor
        .create(document.querySelector('#rich_text5'))
        .then(editor => {
            editor.model.document.on('change:data', () => {
                editorData = editor.getData();
            });
        })
        .catch(error => {
            console.error(error);
        });


</script>
<script>
    $(document).ready(function() {
        $('.subject-area').select2();
    });
    $(document).ready(function() {
        $('.venue').select2();
    });
    $(document).ready(function() {
        $('.subject-area_ar').select2();
    });
    $(document).ready(function() {
        $('.venue_ar').select2();
    });
    $(document).ready(function() {
        $('.related-courses').select2();
    });
</script>


<script>
    $(document).ready(function() {
        $("#is_blog").click(function() {
            $('#related_courses_div').toggleClass('display-none');
            $('#explore_blog').toggleClass('display-none');
            $('#breakingNews').toggleClass('display-none');
        });

    });
    $(document).ready(function() {
        if($("#is_blog").prop('checked') == true){
            $('#related_courses_div').removeClass('display-none');
            $('#explore_blog').removeClass('display-none');
            $('#breakingNews').addClass('display-none');
        }else {
            $('#related_courses_div').addClass('display-none');
            $('#explore_blog').addClass('display-none');
            $('#breakingNews').removeClass('display-none');
        }
    });
</script>
<script type="text/javascript">

    $('#description').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#description_en').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#description_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#what_you_will_learn	').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#what_you_will_learn_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#course_details').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#course_details_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#prerequisites').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#prerequisites_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#content_en').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#content_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#details_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#details_en').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });

    $('#your_class').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });
    $('#your_class_ar').summernote({
        height: 400,
        callbacks: {
            onPaste: function (e) {
                var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                e.preventDefault();
                document.execCommand('insertText', false, bufferText);
            }
        }
    });

</script>
<script>
    // $(document).ready(function (){
    //     if($('#achiev_img').is(':checked')) {
    //         alert("img checked");
    //     }else if($('#achiev_vid').is(':checked')){
    //         alert('vid check')
    //     }
    // })
    $('input:radio[name="mediaType"]').change(function(){

        if ($(this).val() == 'image') {
            $('#image_achiev').css('display' , 'block')
            $('#video_achiev').css('display' , 'none')
        }
        else {
            $('#image_achiev').css('display' , 'none')
            $('#video_achiev').css('display' , 'block')
        }
    });
</script>

@yield('script')

<!-- Custom Theme Scripts -->
<script src="{{ url('/') }}/admintheme/build/js/custom.js"></script>

</body>
</html>
