
@extends('admin.layout.master')

@section('title', trans('messages.privacy-policy'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.privacy-policy') }}</small></h2>
                    <a hidden href="{{ route('privacy-policy.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
                    </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.description_en') }}</th>
                                        <th>{{ trans('messages.description_en') }}</th>
                                        <th>Control</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($contents as $content)
                                        <tr>
                                            <td>
                                                <p> {{ $content->title_en }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $content->title_ar }} </p>
                                            </td>
                                            <td>
                                                <p>  @php echo $content->description_en; @endphp </p>
                                            </td>
                                            <td>
                                                <p>  @php echo $content->description_ar; @endphp </p>
                                            </td>
                                            <td>
                                                @if($content->id != 32)
                                                    <form method="POST" action="{{ route('privacy-policy.destroy', $content->id) }}">
                                                        {{ csrf_field() }}
                                                        {{ method_field('DELETE') }}

                                                        <div class="form-group">
                                                            <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                        </div>
                                                    </form>
                                                @endif

                                                <a href="{{ route('privacy-policy.edit', $content->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
