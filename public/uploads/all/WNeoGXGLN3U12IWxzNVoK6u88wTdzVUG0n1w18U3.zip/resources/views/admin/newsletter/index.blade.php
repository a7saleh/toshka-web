
@extends('admin.layout.master')

@section('title', trans('messages.newsletter'))

@section('body')

    <!-- gallery content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.send_email') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">
                                <div class="information">
                                    <h2>Send Message To All Newsletter Subscribers</h2>
                                </div>
                                <hr>
                                <div class="newsletter-send-email-form">
                                    <form action="{{ url('admin/newsletter/sendnewsletteremail') }}" method="post">
                                        @csrf
                                        <label for="subject">Subject</label>
                                        <input type="text" name="subject" id="subject" style="width: 100% ; margin:0 0 20px 0" required>
                                        <label for="message">Write Your Message</label>
                                        <textarea name="message" id="message" cols="300" rows="10" style="width: 100%" required></textarea>
                                        <div class="ln_solid"></div>
                                        <div class="item form-group">
                                            <div class="col-md-12 col-sm-12 text-center">
                                                <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.newsletter') }}</small></h2>
                    <a href="{{ route('newsletter.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
                    </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTableNews" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>{{ trans('messages.email') }}</th>
                                        <th>Control</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($emails as $email)
                                        <tr>
                                            <td>
                                                <p> {{ $email->id }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $email->email }} </p>
                                            </td>
                                            <td>
                                                <form method="POST" action="{{ route('newsletter.destroy', $email->id) }}">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <div class="form-group">
                                                        <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                    </div>
                                                </form>

                                                <a href="{{ route('newsletter.edit', $email->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
@section('script')
    <script>
        $(document).ready(function () {
            $('.dataTableNews').DataTable({
                "pageLength": 5,
                "order": [],
                "dom": 'Bfrtip',
                "stateSave": true,
                "buttons": [
                    {
                        extend: 'csv',
                    },
                ],
                "language": {
                    "emptyTable": "{{trans('messages.empty_table')}}",
                    "info": "{{trans('messages.showing')}} _START_ {{trans('messages.to')}} _END_ {{trans('messages.of')}} _TOTAL_ {{trans('messages.entries')}}",
                    "infoEmpty": "{{trans('messages.showing')}} 0 {{trans('messages.to')}} 0 {{trans('messages.of')}} 0 {{trans('messages.entries')}}",
                    "infoFiltered": "({{trans('messages.filtered_from')}} _MAX_ {{trans('messages.total_entries')}})",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "{{trans('messages.show')}} _MENU_ {{trans('messages.entries')}}",
                    "loadingRecords": "{{trans('messages.loading')}}...",
                    "processing": "{{trans('messages.processing')}}...",
                    "search": "{{trans('messages.search')}}:",
                    "zeroRecords": "{{trans('messages.no_matching_records_found')}}",
                    "paginate": {
                        "first": "{{trans('messages.first')}}",
                        "last": "{{trans('messages.last')}}",
                        "next": "{{trans('messages.next')}}",
                        "previous": "{{trans('messages.previous')}}"
                    },
                    "aria": {
                        "sortAscending": ": activate to sort column ascending",
                        "sortDescending": ": activate to sort column descending"
                    },
                },
                // 'aaSorting': [[3, 'desc']]
            });

            $('.buttons-csv').text('Export Excel').css({
                'background' : '#f2f2f2',
                'color' : 'green',
                'border' : '1px solid #f3f3f3'
            });

        });
    </script>
@endsection
