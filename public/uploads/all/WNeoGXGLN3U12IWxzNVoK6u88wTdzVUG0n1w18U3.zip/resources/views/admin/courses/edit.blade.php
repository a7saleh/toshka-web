@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.courses') . ' / ' . trans('messages.update') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                <form method="POST" action="{{ route('courses.update', $course->id) }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="title-en">{{ trans('messages.title_en') }} <span
                                                class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" value="{{ $course->title_en }}" id="title-en"
                                                   name="title_en"
                                                   required="required" class="form-control ">
                                        </div>
                                    </div>

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="title-ar">{{ trans('messages.title_ar') }} <span
                                                class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" value="{{ $course->title_ar }}" id="title-ar"
                                                   name="title_ar" required="required" class="form-control ">
                                        </div>
                                    </div>

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="meta_description_en">{{ trans('messages.meta_description_en') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea class="form-control" name="description_en" id="meta_description_en">{{ $course->description_en }}</textarea>
                                        </div>
                                    </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align"
                                       for="meta_description_ar">{{ trans('messages.meta_description_ar') }} <span
                                        class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="description_ar"
                                              id="meta_description_ar">{{ $course->description_ar }}</textarea>
                                </div>
                            </div>
 
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_details"> {{ trans('messages.description_en') }} <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="course_details"
                                              id="course_details">{{ $course->course_details }}</textarea>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_details_ar"> {{ trans('messages.description_ar') }}<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="course_details_ar"
                                              id="course_details_ar">{{ $course->course_details_ar }}</textarea>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="start_date"> Start Date
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="date" value="{{ $course->start_date }}" id="start_date"
                                           name="start_date" class="form-control" required autocomplete="off">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="subject_area"> Select
                                    Subject Area
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select name="subject_area[]" class="form-control subject-area" id="subject_area" multiple="multiple">
                                        @foreach($selected_subjects as $selected_subject)
                                         <option value="{{ $selected_subject }}" selected aria-selected="true">{{ $selected_subject }}</option>
                                        @endforeach
                                        @foreach($subject_area as $sub)
                                            <option value="{{ $sub->subject_area }}">{{ $sub->subject_area }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="subject_area_ar"> Select
                                    Subject Area Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select name="subject_area_ar[]" class="form-control subject-area_ar" id="subject_area_ar" multiple="multiple">
                                        @foreach($selected_subjects_ar as $selected_subject)
                                            <option value="{{ $selected_subject }}" selected aria-selected="true">{{ $selected_subject }}</option>
                                        @endforeach
                                        @foreach($subject_area as $sub)
                                            <option value="{{ $sub->subject_area_ar }}">{{ $sub->subject_area_ar }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="duration"> Duration
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->duration }}" id="duration" name="duration"
                                           required="required" class="form-control" placeholder="ex: 0 - 2 weeks">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="duration_ar"> Duration Arabic
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->duration_ar }}" id="duration_ar" name="duration_ar"
                                           required="required" class="form-control" placeholder="ex: 0 - 2 weeks">
                                </div>
                            </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_en">{{ trans('messages.skills') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="skills" id="content_en" required="required">{{ $course->skills}}</textarea>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_ar">{{ trans('messages.skills_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="skills_ar" id="content_ar" required="required">{{ $course->skills_ar }}</textarea>
                      </div>
                    </div>


                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_ar">{{ trans('messages.details_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" rows="12"  name="details_ar" id="details_ar" required="required">{{ $course->details_ar }}</textarea>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_ar">{{ trans('messages.details_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" rows="12"  name="details_en" id="details_en" required="required">{{ $course->details_en }}</textarea>
                      </div>
                    </div>


                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="prerequisites">
                                    Prerequisites <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="prerequisites"
                                              id="prerequisites">{{ $course->prerequisites }}</textarea>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="prerequisites_ar">
                                    Prerequisites Arabic<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="prerequisites_ar"
                                              id="prerequisites_ar">{{ $course->prerequisites_ar }}</textarea>
                                </div>
                            </div>


                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="time_commitment"> Time
                                    Commitment <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->time_commitment }}" id="time_commitment"
                                           name="time_commitment" class="form-control">
                                </div>
                            </div>


                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="time_commitment_ar"> Time
                                    Commitment Arabic<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->time_commitment_ar }}" id="time_commitment_ar"
                                           name="time_commitment_ar" class="form-control">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_language">
                                    Course Language <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->course_language }}" id="course_language"
                                           name="course_language" class="form-control">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_language_ar">
                                    Course Language <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->course_language_ar }}" id="course_language_ar"
                                           name="course_language_ar" class="form-control">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="level"> Level
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="level" value="{{ $course->level }}" name="level" class="form-control">
                                </div>

                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="level_ar"> Level Ar
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="level" value="{{ $course->level_ar }}" name="level_ar" class="form-control">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="venue"> Venue <span
                                        class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select name="venue[]" class="form-control venue" id="venue" multiple="multiple">
                                        @foreach($selected_venues as $selected_venue)
                                        <option value="{{ $selected_venue }}" selected aria-selected="true">{{ $selected_venue }}</option>
                                        @endforeach
                                        @foreach($venue as $ven)
                                            <option value="{{ $ven->venue }}">{{ $ven->venue }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="venue_ar"> Venue Arabic<span
                                        class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select name="venue_ar[]" class="form-control venue" id="venue_ar" multiple="multiple">
                                        @foreach($selected_venues_ar as $selected_venue)
                                            <option value="{{ $selected_venue }}" selected aria-selected="true">{{ $selected_venue }}</option>
                                        @endforeach
                                        @foreach($venue as $ven)
                                            <option value="{{ $ven->venue_ar }}">{{ $ven->venue_ar }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="activity_type">
                                    Activity Type<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select id="activity_type" name="activity_type" class="form-control">
                                        <option value="{{ $course->activity_type }}" disabled="disabled"
                                                selected="selected">{{ $course->activity_type }}</option>
                                        @foreach($activity_type as $act)
                                            <option value="{{ $act->activity_type }}">{{ $act->activity_type }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="activity_type_ar">
                                    Activity Type Arabic<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <select id="activity_type_ar" name="activity_type_ar" class="form-control">
                                        <option value="{{ $course->activity_type_ar }}" disabled="disabled"
                                                selected="selected">{{ $course->activity_type_ar }}</option>
                                        @foreach($activity_type as $act)
                                            <option value="{{ $act->activity_type_ar }}">{{ $act->activity_type_ar }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="activity"> Activity
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="activity" name="activity" class="form-control"
                                           value="{{ $course->activity }}">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="activity_ar"> Activity Arabic
                                    <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="activity_ar" name="activity_ar" class="form-control"
                                           value="{{ $course->activity_ar }}">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="accreditation">
                                    Accreditation<span class="required">*</span>
                                </label>

                                <div class="col-md-6 col-sm-6 ">
                                    <select id="accreditation" name="accreditation" class="form-control">
                                        <option value="{{ $course->accreditation }}" disabled="disabled"
                                                selected="selected">{{ $course->accreditation }}</option>
                                        @foreach($accreditation as $acc)
                                            <option value="{{ $acc->name }}">{{ $acc->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="accreditation_ar">
                                    Accreditation Arabic <span class="required">*</span>
                                </label>

                                <div class="col-md-6 col-sm-6 ">
                                    <select id="accreditation_ar" name="accreditation_ar" class="form-control">
                                        <option value="{{ $course->accreditation_ar }}" disabled="disabled"
                                                selected="selected">{{ $course->accreditation_ar }}</option>
                                        @foreach($accreditation as $acc)
                                            <option value="{{ $acc->name_ar }}">{{ $acc->name_ar }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="days"> Days <span
                                        class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="days"  name="days"
                                           class="form-control" value="{{ $course->days }}">
                                </div>
                            </div>


                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="number_modules"> Number
                                    of modules <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->number_modules }}" id="number_modules"
                                           name="number_modules"
                                           class="form-control">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="contact_number">
                                    Contact Number <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" value="{{ $course->contact_number }}" id="contact_number"
                                           onkeypress="return isNumberKey(event)" name="contact_number"
                                           class="form-control">
                                </div>
                            </div>


                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="what_you_will_learn">
                                    What You Will Learn <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="what_you_will_learn"
                                              id="what_you_will_learn">{{ $course->what_you_will_learn }}</textarea>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="what_you_will_learn_ar">
                                    What You Will Learn Arabic<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="what_you_will_learn_ar"
                                              id="what_you_will_learn_ar">{{ $course->what_you_will_learn_ar }}</textarea>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align"
                                       for="your_class_title">Bottom Section Title
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="your_class_title" name="your_class_title"
                                           class="form-control" value="{{ $course->your_class_title }}">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align"
                                       for="your_class_title_ar">Bottom Section Title Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" id="your_class_title_ar" name="your_class_title_ar"
                                           class="form-control" value="{{ $course->your_class_title_ar }}">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="your_class">
                                    Bottom Section Description
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                            <textarea class="form-control" name="your_class"
                                      id="your_class">{{ $course->your_class }}</textarea>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="your_class_ar">
                                    Bottom Section Description Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                            <textarea class="form-control" name="your_class_ar"
                                      id="your_class_ar">{{ $course->your_class_ar }}</textarea>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="your_class_image"> Bottom Section Image
                                </label>
                                <div class="col-md-6 col-sm-6">
                                    <input type="file" class="form-control" name="your_class_image" id="your_class_image">
                                </div>
                            </div>
                                                

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="register_by">Registered
                                    By <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="date" id="register_by" name="register_by" required="required"
                                           class="form-control" value="{{ $course->register_by }}" autocomplete="off">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="is_certified"> Is
                                    certified
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="checkbox" style="width:10%" class="form-control"
                                           {{ ($course->is_certified == 1) ? 'checked=checked' : '' }} value="1"
                                           name="is_certified"
                                           id="is_certified">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="image"> Course Image
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <div class="col-md-12 col-sm-12 text-center"><img src="/storage/uploads/courses/{{ $course->image }}" width="100"></div>
                                    <input type="file" class="form-control" name="image" id="image">
                                </div>
                            </div>
                            <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="file"> {{ trans('messages.cover') }}
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <div class="col-md-12 col-sm-12 text-center"><img src="/storage/uploads/courses/{{ $course->inner_image }}" width="100"></div>
                            <input type="file" class="form-control" name="inner_image" id="inner_image">
                        </div>
                    </div><br>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="brochure"> Brochure
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="file" class="form-control" name="brochure" id="brochure">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="video">{{ trans('messages.video') }} src
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="video" id="video"  placeholder="Please Enter the Source of the Embedded Video" value="{{ $course->video }}">
                                </div>
                            </div>
                            <p style="text-align: center; font-weight: bold; padding: 20px; color: red ; font-size: 14px">* Note : Please enter the source of the youtube embedded video <span style=" font-weight: bolder">without the double quotation</span> as shown on the picture below</p>

                            <div class="ln_solid"></div>
                            
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="number" class="form-control" name="priority" id="priority" value="{{ $course->priority }}">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 1 Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b1_ar" id="b1_ar" value="{{ $course->b1_ar }}">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 1 English
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b1_en" id="b1_en" value="{{ $course->b1_en }}">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 2 Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b2_ar" id="b2_ar" value="{{ $course->b2_ar }}">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 2 English
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b2_en" id="b2_en" value="{{ $course->b2_en }}">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 3 Arabic
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b3_ar" id="b3_ar" value="{{ $course->b3_ar }}">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Box 3 English
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <input type="text" class="form-control" name="b3_en" id="b3_en" value="{{ $course->b3_en }}">
                                </div>
                            </div>
                            
                            
                            <div class="item form-group">
                                <div class="col-md-6 col-sm-6 offset-md-3">
                                    <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                                    <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                </div>
                            </div>
                            </form>
                            <div class="video-src-pic" style="display: flex; flex-direction: row; justify-content: center; margin: 20px">
                                <img src="{{ url('admintheme/images/video-src.png') }}" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!--// page content -->

@stop
