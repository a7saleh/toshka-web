
@extends('admin.layout.master')

@section('title', trans('messages.courses'))

@section('body')

<!-- courses content -->


<div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">

        @if(Session::has('success'))
          <div class="alert alert-success mt-3">
          {{Session::get('success')}}
          </div>
        @endif

        <div class="x_panel">
          <div class="x-header mb-3">
            <h2 class="float-left"><small>{{ trans('messages.courses') }}</small></h2>
              <a href="{{ route('courses.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
              </a>
        </div>
        <div class="x_content">
          <div class="row">



            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="CourseTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th> ID </th>
                      <th>{{ trans('messages.title_en') }}</th>
                      <th>Subject Area</th>
                      <th>Duration</th>
                      <th>Time Commitment</th>
                      <th>Course Language</th>
                      <th>Start Date</th>
                      <th>{{ trans('messages.priority') }}</th>
                      <th>Image</th>
                      <th>Control </th>
                      <th>Hide </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($courses as $course)
                            <tr class="{{ ($course->is_hidden == 1) ? 'is-hidden-course' : ''}}">
                              <td>{{ $course->id }}</td>
                              <td>{{ $course->title_en }}</td>
                              <td>{{ $course->subject_area }}</td>
                              <td>{{ $course->duration }}</td>
                              <td>{{ $course->time_commitment }}</td>
                              <td>{{ $course->course_language }}</td>
                              <td>{{ $course->start_date }}</td>
                              <td>{{ $course->priority }}</td>
                              <td> <img src="{{ asset('storage/uploads/courses') }}/{{ $course->image }}" width="150"> </td>
                              <td>
                                <form method="POST" action="{{ route('courses.destroy', $course->id) }}">
                                  {{ csrf_field() }}
                                  {{ method_field('DELETE') }}

                                  <div class="form-group">
                                      <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                  </div>
                                </form>

                                <a href="{{ route('courses.edit', $course->id) }}" class="btn btn-small btn-info">
                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                </a>
                              </td>
                                <td>
                                    @if($course->is_hidden == 0)
                                        <form action="{{ url('admin/hide') }}/{{ $course->id }}" method="post">
                                            @csrf
                                            <input type="number" name="is_hidden" value="1" style="display: none">
                                            <div class="form-group">
                                                <a href="javascript:void(0);" class="btn btn-small btn-warning hide-btn"><i class="fa fa-trash"></i> {{ trans('messages.hide') }} </a>
                                            </div>
                                        </form>
                                    @else
                                        <form action="{{ url('admin/hide') }}/{{ $course->id }}" method="post">
                                            @csrf
                                            <input type="number" name="is_hidden" value="0" style="display: none">
                                            <p class="text-danger">This Course is hidden</p>
                                            <div class="form-group">
                                                <a href="javascript:void(0);" class="btn btn-small btn-success unhide-btn" style="opacity: 1"><i class="fa fa-trash"></i> {{ trans('messages.unhide') }} </a>
                                            </div>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                      </table>
                      </div>
                  </div>

                                    <div class="x-header" style="height:1px;"></div><br><br><div class="x-header" style="height:1px;"></div>
                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','activity_type_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','course_language_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','accreditation_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','subject_area_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','number_modules_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','activity_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','days_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','time_commitment_img')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-12 col-md-12 col-sm-12 text-center"><img src="{{$activity_type_img->image}}"></div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                            <input type="text" class="form-control" name="image" id="image" value="{{$activity_type_img->image}}">
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-sm-12 text-center" style="width:100%;">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                   <div class="x-header"></div>

                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab1')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab3')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab4')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab5')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab6')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>


                                    <?php $activity_type_img=DB::table('page_contents')->where('ref_page','=','tab7')->first();?>
                                    <form method="POST" action="{{ route('courses.update' , $activity_type_img->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" value="{{$activity_type_img->title_ar}}">
                                            </div>
                                        <div class="col-form-label col-lg-8 col-md-8 col-sm-8 text-center">
                                            <input type="text" class="form-control" name="title_en" id="title_en" value="{{$activity_type_img->title_en}}">
                                        </div>
                                       <div class="col-form-label col-lg-10 col-md-10 col-sm-10 text-center">
                                        <input type="hidden" class="form-control" name="icons" value="1">
                                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                    </div></div></form><div class="x-header" style="height:1px;"></div>




              </div>
          </div>
      </div>
    </div>
</div>
<!--// course content -->

@stop
