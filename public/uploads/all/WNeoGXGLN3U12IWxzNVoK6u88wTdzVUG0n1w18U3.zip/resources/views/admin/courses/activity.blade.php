
@extends('admin.layout.master')

@section('title', trans('messages.activity_type'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.activity_type') }}</small></h2>
                    <a href="{{ route('activity.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
                    </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th> ID </th>
                                        <th>{{ trans('messages.activity_type') }}</th>
                                        <th>{{ trans('messages.activity_type_ar') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($activity_type as $act)
                                        Accreditation
                                        accreditation
                                        <tr>
                                            <td>{{ $act->id }}</td>
                                            <td>{{ $act->activity_type }}</td>
                                            <td style="direction: rtl;">{{ $act->activity_type_ar }}</td>
                                            <td>
                                                <form method="POST" action="{{ route('activity.destroy', $act->id) }}">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <div class="form-group">
                                                        <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                    </div>
                                                </form>

                                                <a href="{{ route('activity.edit', $act->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->

@stop
