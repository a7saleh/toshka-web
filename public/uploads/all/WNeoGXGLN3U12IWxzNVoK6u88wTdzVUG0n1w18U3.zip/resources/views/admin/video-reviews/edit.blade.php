@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.video-reviews') . ' / ' . trans('messages.update') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <p style="text-align: center; font-weight: bold; padding: 20px; color: red ; font-size: 16px">
                                    * Note : Please enter the source of the youtube embedded video <span
                                        style=" font-weight: bolder">without the double quotation</span> as shown on the
                                    picture below</p>


                                <form method="POST" action="{{ route('video-reviews.update' , $video->id) }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="video">{{ trans('messages.video') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="video" id="video"
                                                   required="required" value="{{ $video->video }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="difficulty"> Courses <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="course_id" class="form-control" id="difficulty">
                                                <option value="" disabled="disabled">...</option>
                                                @foreach($courses as $course)
                                                    <option value="{{ $course->id }}" {{ ($course->id == $video->course_id) ? 'selected' : '' }}> {{ $course->title_en }} </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="number" class="form-control" name="priority" id="priority" value="{{ $video->priority }}">
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button class="btn btn-primary"
                                                    type="reset">{{ trans('messages.reset_btn') }}</button>
                                            <button type="submit"
                                                    class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>

                                </form>
                                <div class="video-src-pic"
                                     style="display: flex; flex-direction: row; justify-content: center; margin: 20px">
                                    <img src="{{ url('admintheme/images/video-src.png') }}" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
