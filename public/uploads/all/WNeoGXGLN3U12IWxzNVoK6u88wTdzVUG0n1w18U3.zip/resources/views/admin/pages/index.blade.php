
@extends('admin.layout.master')

@section('title', trans('messages.pages'))

@section('body')

<!-- page content -->


  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">

        @if(Session::has('success'))
          <div class="alert alert-success mt-3">
          {{Session::get('success')}}
          </div>
        @endif

        <div class="x_panel">
          <div class="x-header mb-3">
            <h2 class="float-left"><small>{{ trans('messages.pages') }}</small></h2>
              <a href="{{ route('pages.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
              </a>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="pageTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th> ID </th>
                      <th>{{ trans('messages.page_en') }}</th>
                      <th>{{ trans('messages.slug') }}</th>
                      <th>{{ trans('messages.content') }}</th>
                      <th>{{ trans('messages.created_by') }}</th>
                      <th>{{ trans('messages.updated_by') }}</th>
                      <th>{{ trans('messages.control') }} </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($pages as $page)
                        <tr>
                          <td>{{ $page->id }}</td>
                          <td><a href="{{ route('pages.edit', $page->id) }}">{{$page->page_name_en}}</a></td></td>
                          <td>{{$page->slug}}</td>
                          <td><?php echo strlen($page->content_en) > 30 ? substr($page->content_en,0,30).'...' : $page->content_en; ?>
                          </td>
                          @if(!empty($page->createdBy->first_name))
                          <td>{{$page->createdBy->first_name}}</td>
                          @else <td> </td>
                          @endif

                          @if(!empty($page->updatedBy->first_name))
                          <td>{{$page->updatedBy->first_name}}</td>
                          @else <td> </td>
                          @endif
                          <td>
                            <form method="POST" action="{{ route('pages.destroy', $page->id) }}">
                              {{ csrf_field() }}
                              {{ method_field('DELETE') }}

                              <div class="form-group">
                                  <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                              </div>
                            </form>

                            <a href="{{ route('pages.edit', $page->id) }}" class="btn btn-small btn-info">
                                <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                            </a>
                          </td>
                        </tr>
                        @endforeach
                        </tbody>
                      </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
<!--// page content -->

@stop
