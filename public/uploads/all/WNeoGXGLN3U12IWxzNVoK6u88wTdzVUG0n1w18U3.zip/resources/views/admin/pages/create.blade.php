@extends('admin.layout.master')

@section('title' ,  trans('messages.add') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.pages') . ' / ' . trans('messages.add') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('pages.store') }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    {!! csrf_field() !!}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="page-name-en">{{ trans('messages.page_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="page-name-en" name="page_name_en" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="page-name-ar">{{ trans('messages.page_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="page-name-ar" name="page_name_ar" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content-en">{{ trans('messages.content_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="content_en" id="content-en" required="required"></textarea>
                      </div>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content-ar">{{ trans('messages.content_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="content_ar" id="content-ar" required="required"></textarea>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="slug"> Slug <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" placeholder="Ex: about-us" class="form-control" required="required" name="slug" id="slug">
                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
