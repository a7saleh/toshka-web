@extends('admin.layout.master')

@section('title', trans('messages.home'))

@section('body')

<?php

$users = App\Models\User::count();
$courses = App\Models\Course::count();
$news = App\Models\News::count();
$Blog = App\Models\News::where('is_blog',1)->count();
$NewsletterEmails = App\Models\NewsletterEmails::count();
$teach = DB::table('reports')->where('report_type','=','teach')->count();
$contact = DB::table('reports')->where('report_type','=','contact')->count();
$join = DB::table('reports')->where('report_type','=','join')->count();

$suggest = DB::table('reports')->where('report_type','=','suggest')->count();
$reseller = DB::table('reports')->where('report_type','=','reseller')->count();
$course_reviews = DB::table('course_reviews')->count();
$testimonials = DB::table('testimonials')->count();

?>

@if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2)
<div class="right_col" role="main">

   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-info">
	      <div class="inner">
	        <h3><i class="fa fa-users"></i> {{ $users }} </h3>
	        <a href="{{ url('admin/users') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.users') }}</a>
	      </div>
	    </div>
   	</div>

   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-success">
	      <div class="inner">
	        <h3><i class="fa fa-book"></i> {{ $courses }} </h3>
	        <a href="{{ url('admin/courses') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.courses') }}</a>
	      </div>
	    </div>
   	</div>

   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-warning">
	      <div class="inner">
	        <h3><i class="fa fa-newspaper-o"></i> {{ $news }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.news') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-dark">
	      <div class="inner">
	        <h3><i class="fa fa-clipboard"></i> {{ $Blog }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.blog') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-danger">
	      <div class="inner">
	        <h3><i class="fa fa-envelope"></i> {{ $NewsletterEmails }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.subscriber') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-primary">
	      <div class="inner">
	        <h3><i class="fa fa-pencil-square-o"></i> {{ $teach }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.apply_to_teach') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-secondary">
	      <div class="inner">
	        <h3><i class="fa fa-comments-o"></i> {{ $contact }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.contact') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-blue">
	      <div class="inner">
	        <h3><i class="fa  fa-sign-in"></i> {{ $join }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.join') }}</a>
	      </div>
	    </div>
   	</div>


   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-dark">
	      <div class="inner">
	        <h3><i class="fa fa-list"></i> {{ $suggest }} </h3>
	        <a href="{{ url('admin/users') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.suggest') }}</a>
	      </div>
	    </div>
   	</div>

   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-warning">
	      <div class="inner">
	        <h3><i class="fa  fa-suitcase"></i> {{ $reseller }} </h3>
	        <a href="{{ url('admin/courses') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.reseller') }}</a>
	      </div>
	    </div>
   	</div>

   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-success">
	      <div class="inner">
	        <h3><i class="fa fa-star-o"></i> {{ $course_reviews }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.course_reviews') }}</a>
	      </div>
	    </div>
   	</div>
   	<div class="col-md-3 stat mb-2 mt-5">
	    <div class="small-box bg-info">
	      <div class="inner">
	        <h3><i class="fa fa-comment"></i> {{ $testimonials }} </h3>
	        <a href="{{ url('admin/news') }}" target="_blank" class="small-box-footer">
	        {{ trans('messages.testimonials') }}</a>
	      </div>
	    </div>
   	</div>


</div>
@else
<div class="right_col" role="main">
	home
</div>
@endif

@stop

@section('script')


@stop
