
@extends('admin.layout.master')

@section('title', trans('messages.achievements'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.achievements') }}</small></h2>
                    <a href="{{ route('extra.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}</a>
                </div>
                <div class="x_content">
                    <div class="row">


                        <?php $banner=DB::table('page_contents')->where('ref_page','=','extra_banner')->first();?>
                            <form method="POST" action="{{ route('extra.update' , $banner->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-md-8 col-sm-8 text-center"><img src="/frontend/images/banners/{{$banner->image}}" alt="aljhood" style="max-width:680px;height:120px;"></div>
                                        <div class="col-md-4 col-sm-4 text-center"><br>
                                            <input type="file" class="form-control" name="banner" id="banner" value="{{$banner->image}}">
                                            <input type="text" class="form-control" name="title_ar" value="{{$banner->title_ar}}">
                                            <input type="text" class="form-control" name="title_en" value="{{$banner->title_en}}"><br>
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="x-header"></div>

                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.description_en') }}</th>
                                        <th>{{ trans('messages.description_ar') }}</th>
                                        <th>{{ trans('messages.priority') }}</th>
                                        <th>{{ trans('messages.image') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($contents as $content)
                                        <tr>
                                            <td>
                                                <p> {{ $content->title_en }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $content->title_ar }} </p>
                                            </td>
                                            <td>
                                                <p>  @php echo $content->description_en; @endphp </p>
                                            </td>
                                            <td>
                                                <p> @php echo $content->description_ar; @endphp  </p>
                                            </td>
                                            <td>{{ $content->priority }}</td>
                                            <td>
                                                @if(!empty($content->image))
                                                    <img src="{{ asset('storage/uploads/page-contents') }}/{{ $content->image }}" alt="" width="200">
                                                @else
                                                    <iframe width="200" height="200" src="{{ $content->video }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                @endif
                                            </td>
                                            <td>
                                                <form method="POST" action="{{ route('extra.destroy', $content->id) }}">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <div class="form-group">
                                                        <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                    </div>
                                                </form>
                                                <a href="{{ route('extra.edit', $content->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
