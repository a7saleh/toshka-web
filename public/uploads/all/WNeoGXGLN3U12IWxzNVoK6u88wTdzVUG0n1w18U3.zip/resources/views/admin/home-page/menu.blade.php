
@extends('admin.layout.master')

@section('title', trans('messages.menu'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.menu') }}</small></h2>
                    <a href="clone-menu" class="btn btn-small btn-dark float-right">
                    <i class="fa fa-copy"></i> {{ trans('messages.clone') }}
                     </a>                    <a href="{{ route('menu.create') }}" class="btn btn-small btn-success float-right">
                    <i class="fa fa-plus"></i> {{ trans('messages.add') }}
                     </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-bordered" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th> ID </th>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.url') }}</th>
                                        <th>{{ trans('messages.order') }}</th>
                                        <th>{{ trans('messages.Status') }}</th>
                                        <th>{{ trans('messages.parent') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($menus as $menu)
                                        <tr class="table-success">
                                            <td>{{ $menu->id }}</td>
                                            <td>
                                                <p>{{ $menu->name_en }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $menu->name_ar }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $menu->url }}</p>
                                            </td>
                                            <td>
                                                <p>{{$menu->element_order}}</p>
                                            </td>
                                            <td>
                                                <p>{{trans($menu->status)}}</p>
                                            </td>
                                            <td>
                                            <p>Main</p>
                                            </td>
                                            <td>
                                                <a href="{{ route('menu.edit',$menu->id) }}" class="btn btn-small btn-success">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }}
                                                </a>
                                            </td>
                                        </tr>
                                        @foreach($menu->submenu as $submenu_item)
                                            <tr>
                                             <td>{{ $submenu_item->id }}</td>
                                            <td>
                                                <p>{{ $submenu_item->name_en }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $submenu_item->name_ar }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $submenu_item->url }}</p>
                                            </td>
                                            <td>
                                                <p>{{$submenu_item->element_order}}</p>

                                            </td>
                                            <td>
                                                <p>{{trans($submenu_item->status)}}</p>
                                            </td>
                                            <td>
                                                <?php $parent_item=DB::table('menu')->where('id','=',$menu->id)->first();?>
                                                <p>{{$parent_item->name_en}}</p>
                                            </td>
                                            <td>
                                                <a href="{{ route('menu.edit',$submenu_item->id) }}" class="btn btn-small btn-dark">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
