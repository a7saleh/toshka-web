@extends('admin.layout.master')

@section('title' ,  trans('messages.add') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.slider') . ' / ' . trans('messages.add') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                <form method="POST" action="{{ route('slider.store') }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_en"> {{ trans('messages.title_en') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="title_en" id="title_en">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_ar">{{ trans('messages.title_ar') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_en"> {{ trans('messages.description_en') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_en" id="description_en"></textarea>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_ar">{{ trans('messages.description_ar') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_ar" id="description_ar"></textarea>
                                        </div>
                                    </div>

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="venue">{{ trans('messages.image') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="file" class="form-control" name="image" id="image" required="required">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="link"> Link
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="link" id="link">
                                        </div>
                                    </div>
                                    
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="venue">{{ trans('messages.file') }}  <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="file" class="form-control" name="file" id="file">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="button_file_ar"> File Label AR
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="button_file_ar" id="button_file_ar">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="button_file_en">File Label En
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="button_file_en" id="button_file_en">
                                        </div>
                                    </div>                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="button_label_ar"> Button Label AR
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="button_label_ar" id="button_label_ar">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="button_label_en">Button Label En
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="button_label_en" id="button_label_en">
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="number" class="form-control" name="priority" id="priority">
                                        </div>
                                    </div>
                                    <div class="item form-group" id="video_achiev">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="video">{{ trans('messages.video') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="video" id="video">
                                        </div>
                                    </div> 
                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
