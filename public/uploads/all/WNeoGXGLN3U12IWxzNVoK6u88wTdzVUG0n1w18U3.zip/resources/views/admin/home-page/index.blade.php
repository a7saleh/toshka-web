
@extends('admin.layout.master')

@section('title', trans('messages.slider'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.slider') }}</small></h2>
                    <a href="{{ route('slider.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
                    </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th> ID </th>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.description_en') }}</th>
                                        <th>{{ trans('messages.description_ar') }}</th>
                                        <th>{{ trans('messages.image') }}</th>
                                        <th>{{ trans('messages.priority') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($banners as  $banner)
                                        <tr>
                                            <td>{{ $banner->id }}</td>
                                            <td>
                                                <p> {{ $banner->title_en }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $banner->title_ar }} </p>
                                            </td>
                                            <td>
                                                <p>  @php echo $banner->description_en; @endphp </p>
                                            </td>
                                            <td>
                                                <p>  @php echo $banner->description_ar; @endphp </p>
                                            </td>
                                            <td><img src="{{ asset("storage/uploads/sliders")}}/{{$banner->image }}" alt="" width="150"></td>
                                            <td><p>{{ $banner->priority }}</p></td>
                                            <td>
                                                <form method="POST" action="{{ route('slider.destroy', $banner->id) }}">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}

                                                    <div class="form-group">
                                                        <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                                                    </div>
                                                </form>

                                                <a href="{{ route('slider.edit', $banner->id) }}" class="btn btn-small btn-info">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
