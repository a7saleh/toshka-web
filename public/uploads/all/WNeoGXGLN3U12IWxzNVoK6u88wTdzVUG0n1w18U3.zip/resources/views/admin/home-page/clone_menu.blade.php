@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.menu') . ' / ' . trans('messages.clone') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <form method="POST" action="{{ route('menu.store') }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('POST') }}

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_en">{{ trans('messages.name_en') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="name_en" id="name_en" required="required">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_ar">{{ trans('messages.name_ar') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="name_ar" id="name_ar" required="required">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{trans('messages.clone_from')}}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="url" class="form-control">
                                            @if(!empty($menus))
                                            @foreach ($menus as $menu)
                                            <option value="{{$menu->url}}">{{$menu->name_en}}</option>
                                            @endforeach
                                            @endif
                                            </select>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.order') }} 
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="number" class="form-control" required="required" name="element_order" id="element_order">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.parent') }} 
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="parent_id" class="form-control">
                                            <option value="0" >none</option>
                                            @if(!empty($parents))
                                            @foreach ($parents as $parent)
                                            <option value="{{$parent->id}}">{{$parent->name_en}}</option>
                                            @endforeach
                                            @endif
                                            </select>
                                        </div>
                                    </div>                                    
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.Status') }} 
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="status" class="form-control">
                                            <option value="active">{{ trans('messages.active')}}</option>
                                            <option value="disabled">{{ trans('messages.disabled')}}</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button class="btn btn-primary"
                                                    type="reset">{{ trans('messages.reset_btn') }}</button>
                                            <button type="submit"
                                                    class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
