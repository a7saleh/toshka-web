@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.menu') . ' / ' . trans('messages.update') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <form method="POST" action="{{ route('footer.update' , $counter->id) }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_en">{{ trans('messages.name_en') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="name_en" id="name_en" required="required" value="{{ $counter->name_en }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_ar">{{ trans('messages.name_ar') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="name_ar" id="name_ar" required="required" value="{{ $counter->name_ar }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="counter">{{ trans('messages.url') }}  <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" class="form-control" name="url" id="url" required="required" value="{{ $counter->url }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.order') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="number" class="form-control" required="required" name="element_order" id="element_order" value="{{ $counter->element_order }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.type') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            @if($counter->type=="header_cu"||$counter->type=="header_lp"||$counter->type=="header_ql")
                                            <select name="type" class="form-control" style="pointer-events: none;">
                                            @else
                                            <select name="type" class="form-control">
                                            @endif
                                            @if($counter->type=="logo")
                                            <option value="logo" selected>Logo</option>
                                            @else
                                            <option value="logo">Logo</option>
                                            @endif

                                            @if($counter->type=="quick_links")
                                            <option value="quick_links" selected>Quick Links</option>
                                            @else
                                            <option value="quick_links">Quick Links</option>
                                            @endif

                                            @if($counter->type=="legal")
                                            <option value="legal" selected>Legal</option>
                                            @else
                                            <option value="legal">Legal</option>
                                            @endif

                                            @if($counter->type=="contact_text")
                                            <option value="contact_text" selected>contact_text</option>
                                            @else
                                            <option value="contact_text">contact_text</option>
                                            @endif

                                            @if($counter->type=="contact_location")
                                            <option value="contact_location" selected>contact_location</option>
                                            @else
                                            <option value="contact_location">contact_location</option>
                                            @endif

                                            @if($counter->type=="contact_mobile")
                                            <option value="contact_mobile" selected>contact_mobile</option>
                                            @else
                                            <option value="contact_mobile">contact_mobile</option>
                                            @endif

                                            @if($counter->type=="contact_email")
                                            <option value="contact_email" selected>contact_email</option>
                                            @else
                                            <option value="contact_email">contact_email</option>
                                            @endif

                                            @if($counter->type=="copy_right_left")
                                            <option value="copy_right_left" selected>copy_right_left</option>
                                            @else
                                            <option value="copy_right_left">copy_right_left</option>
                                            @endif

                                            @if($counter->type=="copy_right_center")
                                            <option value="copy_right_center" selected>copy_right_center</option>
                                            @else
                                            <option value="copy_right_center">copy_right_center</option>
                                            @endif

                                            @if($counter->type=="copy_right_right")
                                            <option value="copy_right_right" selected>copy_right_right</option>
                                            @else
                                            <option value="copy_right_right">copy_right_right</option>
                                            @endif

                                            @if($counter->type=="facebook")
                                            <option value="facebook" selected>facebook</option>
                                            @else
                                            <option value="facebook">facebook</option>
                                            @endif

                                            @if($counter->type=="twitter")
                                            <option value="twitter" selected>twitter</option>
                                            @else
                                            <option value="twitter">twitter</option>
                                            @endif

                                            @if($counter->type=="instagram")
                                            <option value="instagram" selected>instagram</option>
                                            @else
                                            <option value="instagram">instagram</option>
                                            @endif

                                            @if($counter->type=="linkedin")
                                            <option value="linkedin" selected>linkedin</option>
                                            @else
                                            <option value="linkedin">linkedin</option>
                                            @endif

                                            @if($counter->type=="whatsapp")
                                            <option value="whatsapp" selected>whatsapp</option>
                                            @else
                                            <option value="whatsapp">whatsapp</option>
                                            @endif

                                            @if($counter->type=="youtube")
                                            <option value="youtube" selected>youtube</option>
                                            @else
                                            <option value="youtube">youtube</option>
                                            @endif

                                            @if($counter->type=="header_cu")
                                            <option value="header_cu" selected>Header Contact Us</option>
                                            @endif

                                            @if($counter->type=="header_lp")
                                            <option value="header_lp" selected>Header Legal Page</option>
                                            @endif

                                            @if($counter->type=="header_ql")
                                            <option value="header_ql" selected>Header Quick Links</option>
                                            @endif


                                            </select>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority">{{ trans('messages.Status') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="status" class="form-control">
                                            <?php if($counter->status=="active"){
                                            $Activeselected="selected";
                                            $NActiveselected="";
                                            }else{
                                             $Activeselected="";
                                             $NActiveselected="selected";
                                            }?>
                                            <option value="active" {{$Activeselected}}>{{ trans('messages.active')}}</option>
                                            <option value="disabled" {{$NActiveselected}}>{{ trans('messages.disabled')}}</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button class="btn btn-primary"
                                                    type="reset">{{ trans('messages.reset_btn') }}</button>
                                            <button type="submit"
                                                    class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
