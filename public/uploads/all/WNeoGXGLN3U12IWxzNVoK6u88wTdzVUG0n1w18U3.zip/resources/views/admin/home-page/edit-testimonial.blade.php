@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.testimonial') . ' / ' . trans('messages.update') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <form method="POST" action="{{ route('testimonial.update' , $testimonial->id) }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                      <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="prerequisites_ar">
                                    {{ trans('messages.testimonial') }} Title En  <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="title_en" id="prerequisites_ar">{{ $testimonial->title_en }}</textarea>
                                </div>
                            </div>  
                            
                            <div class="item form-group">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="prerequisites">
                                    {{ trans('messages.testimonial') }} Title Ar  <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                    <textarea class="form-control" name="title_ar" id="prerequisites">{{ $testimonial->title_ar }}</textarea>
                                </div>
                            </div>                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_en">{{ trans('messages.testimonial') }} Description En <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_en" id="description_en" required="required">{{ $testimonial->description_en }}</textarea>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_ar">{{ trans('messages.testimonial') }} Description Ar <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_ar" id="description_ar" required="required">{{ $testimonial->description_ar }}</textarea>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="number" class="form-control" name="priority" id="priority" value="{{ $testimonial->priority }}">
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button class="btn btn-primary"
                                                    type="reset">{{ trans('messages.reset_btn') }}</button>
                                            <button type="submit"
                                                    class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
