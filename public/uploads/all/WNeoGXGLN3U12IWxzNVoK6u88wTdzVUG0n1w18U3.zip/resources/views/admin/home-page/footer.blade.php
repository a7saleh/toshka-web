
@extends('admin.layout.master')

@section('title', trans('messages.menu'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">

            @if(Session::has('success'))
                <div class="alert alert-success mt-3">
                    {{Session::get('success')}}
                </div>
            @endif

            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.footer') }}</small></h2>
                    <a hidden href="{{ route('footer.create') }}" class="btn btn-small btn-success float-right">
                    <i class="fa fa-plus"></i> {{ trans('messages.add') }}
                     </a>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">

                                    <?php $logo=DB::table('footer')->where('status','=','active')->where('type','=','logo')->first();?>
                                    <form method="POST" action="{{ route('footer.update' , 23) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <div class="item form-group">
                                        <div class="col-form-label col-md-4 col-sm-4 bg-dark text-center"><img src="{{"/logo/".$logo->url }}" alt="aljhood" style="width:100px;"></div>
                                        <div class="col-md-8 col-sm-8 text-center">
                                            <input type="file" class="form-control" name="image" id="image" required><br><br>
                                            <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="x-header"></div>

                                <table id="galleryTable" class="table table-striped table-bordered " style="width:100%">
                                    <thead>
                                    <tr>
                                        <th> ID </th>
                                        <th>{{ trans('messages.title_en') }}</th>
                                        <th>{{ trans('messages.title_ar') }}</th>
                                        <th>{{ trans('messages.url') }}</th>
                                        <th>{{ trans('messages.order') }}</th>
                                        <th>{{ trans('messages.Status') }}</th>
                                        <th>{{ trans('messages.type') }}</th>
                                        <th>Control </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($menus as $menu)
                                        <tr>
                                            <td>{{ $menu->id }}</td>
                                            <td>
                                                <p>{{ $menu->name_en }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $menu->name_ar }}</p>
                                            </td>
                                            <td>
                                                <p>{{ $menu->url }}</p>
                                            </td>
                                            <td>
                                                <p>{{$menu->element_order}}</p>
                                            </td>
                                            <td>
                                                <p>{{trans($menu->status)}}</p>
                                            </td>
                                            <td>
                                                <p>{{$menu->type}}</p>
                                            </td>
                                            <td class="text-center" style="width:100%;">
                                                <a href="{{ route('footer.edit',$menu->id) }}" class="btn btn-small btn-primary">
                                                    <i class="fa fa-edit"></i> {{ trans('messages.update') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
