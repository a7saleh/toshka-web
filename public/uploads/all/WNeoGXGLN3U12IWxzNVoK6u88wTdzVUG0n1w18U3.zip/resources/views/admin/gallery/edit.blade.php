@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.gallery') . ' / ' . trans('messages.update') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('gallery.update' , $gallery->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    {!! csrf_field() !!}
                    {{ method_field('PUT') }}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-en">{{ trans('messages.title_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-en" name="title_en" value="{{ $gallery->title_en }}" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-ar">{{ trans('messages.title_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-ar" name="title_ar" value="{{ $gallery->title_ar }}" required="required" class="form-control ">
                      </div>
                    </div>

                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_en">{{ trans('messages.description_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="description_en" id="description_en">{{ $gallery->description_en }}</textarea>
                      </div>
                  </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_ar">{{ trans('messages.description_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="description_ar" id="description_ar">{{ $gallery->description_ar }}</textarea>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_id"> Courses <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select name="course_id" class="form-control" id="course_id">
                          <option value="" disabled="disabled">...</option>

                            @if(!empty($gallery->course_id))
                              @foreach($courses as $course)
                              <option value="{{ $course->id }}" {{ ($course->id == $gallery->course_id) ? 'selected' : '' }}> {{ $course->title_en }} </option>
                              @endforeach
                            @else
                                <option value="other" selected>Other</option>
                            @endif
                        </select>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="location_id"> Locations <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select name="location_id" class="form-control" id="location_id">
                          <option value="" disabled="disabled">...</option>
                          @foreach($locations as $location)
                          <option value="{{ $location->id }}" {{ ($location->id == $gallery->location_id) ? 'selected' : '' }}> {{ $location->country_name }} </option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="cover_photo"> Gallery Cover Photo
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="file" class="form-control" name="cover_photo" id="cover_photo">
                      </div>
                    </div>

                    <div class="image-holder text-center mb-5 mt-5">
                      <img class="ml-auto mr-auto" width="300" src="{{ asset('storage/uploads/gallery').'/'.$gallery->cover_photo }}" alt="no-photo">
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="files"> Course Files
                      </label>
                      <div class="col-md-6 col-sm-6 mb-3">
                        <input type="file" multiple="multipart" class="form-control" name="files[]" id="files">
                      </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="date">Date <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="date" id="date" name="date" required="required" class="form-control" value="{{ $gallery->date }}">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="number" class="form-control" name="priority" id="priority" value="{{ $gallery->priority }}">
                        </div>
                    </div>
                    @if(count($gallery_files) > 0)
                        <div id="imageCarSlider" class="carousel slide mt-5" data-ride="carousel" style="width: 100% !important;">
                          <div class="carousel-inner">
                            <div class="carousel-item active">
                              <img class="d-block ml-auto mr-auto" width="300" src="{{ asset('storage/uploads/gallery').'/'.$gallery_files[0] }}"
                              alt="no-photo">
                            </div>
                            @if(count($gallery_files) > 1 )
                            @foreach(array_slice($gallery_files, 1) as $file)
                            <div class="carousel-item">
                              <img class="d-block ml-auto mr-auto" width="300" src="{{ asset('storage/uploads/gallery').'/'.$file }}" alt="no-photo">
                            </div>
                            @endforeach
                            @else {{ ' ' }}
                            @endif
                          </div>
                          @if(count($gallery_files) > 1 )
                          <a class="carousel-control-prev" href="#imageCarSlider" role="button" data-slide="prev" style="background: #b5985a; width: 60px; height: 60px; left:30%;">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                          </a>
                          <a class="carousel-control-next" href="#imageCarSlider" role="button" data-slide="next" style="background: #b5985a; width: 60px; height: 60px; right:30%;">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                          </a>
                          @endif
                        </div>
                    @endif
                                        <div class="item form-group" id="video_achiev">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="video">{{ trans('messages.video') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="video" id="video"
                                                    value="{{ $gallery->video }}">
                                        </div>

                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
