@extends('admin.layout.master')

@section('title' ,  trans('messages.add') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.gallery') . ' / ' . trans('messages.add') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('gallery.store') }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    {!! csrf_field() !!}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-en">{{ trans('messages.title_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-en" name="title_en" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-ar">{{ trans('messages.title_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-ar" name="title_ar" required="required" class="form-control ">
                      </div>
                    </div>



                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_en">{{ trans('messages.description_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="description_en" id="description_en"></textarea>
                      </div>
                      </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_ar">{{ trans('messages.description_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="description_ar" id="description_ar"></textarea>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="course_id"> Courses <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select name="course_id" class="form-control" id="course_id">
                          <option value="" disabled="disabled" selected>...</option>
                          <option value="other">Other</option>
                          @foreach($courses as $course)
                          <option value="{{ $course->id }}"> {{ $course->title_en }} </option>
                          @endforeach
                        </select>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="location_id"> Locations <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select name="location_id" class="form-control" id="location_id">
                          <option value="" disabled="disabled">...</option>
                          @foreach($locations as $location)
                          <option value="{{ $location->id }}"> {{ $location->country_name }} </option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="date">Date <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="date" id="date" name="date" required="required" class="form-control ">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="number" class="form-control" name="priority" id="priority">
                        </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="cover_photo"> Gallery Cover Photo
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="file" class="form-control" name="cover_photo" id="cover_photo" required="required">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="files"> Choose Files
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="file" multiple="multiple" class="form-control" name="files[]" id="files"
                        required="required">
                      </div>
                    </div>
                    
                                    <div class="item form-group" id="video_achiev">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="video">{{ trans('messages.video') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="video" id="video"
                                                    >
                                        </div>
                                    </div>                    

                                    
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
