
@extends('admin.layout.master')

@section('title', trans('messages.gallery'))

@section('body')

<!-- gallery content -->


  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">

        @if(Session::has('success'))
          <div class="alert alert-success mt-3">
          {{Session::get('success')}}
          </div>
        @endif

        <div class="x_panel">
          <div class="x-header mb-3">
            <h2 class="float-left"><small>{{ trans('messages.gallery') }}</small></h2>
              <a href="{{ route('gallery.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
              </a>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="galleryTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th> ID </th>
                      <th>{{ trans('messages.title_en') }}</th>
                      <th>{{ trans('messages.title_ar') }}</th>
                      <th>{{ trans('messages.description_en') }}</th>
                      <th>{{ trans('messages.description_ar') }}</th>
                      <th>Related Course</th>
                      <th>{{ trans('messages.priority') }}</th>
                      <th>Control </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($gallery as $gal)
                        <tr>
                          <td>{{ $gal->id }}</td>
                          <td>{{ $gal->title_en }}</td>
                          <td>{{ $gal->title_ar }}</td>
                          <td> @php echo $gal->description_en; @endphp</td>
                          <td> @php echo $gal->description_ar; @endphp</td>
                            @if(!empty($gal->course->id))
                          <td> <a href="{{ url('admin/courses') }}/{{ $gal->course->id }}/edit" target="_blank"> {{ $gal->course->title_en }} </a> </td>
                            @else
                        <td>  </td>
                            @endif
                            <td>{{ $gal->priority }}</td>
                          <td>
                            <form method="POST" action="{{ route('gallery.destroy', $gal->id) }}">
                              {{ csrf_field() }}
                              {{ method_field('DELETE') }}

                              <div class="form-group">
                                  <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                              </div>
                            </form>

                            <a href="{{ route('gallery.edit', $gal->id) }}" class="btn btn-small btn-info">
                                <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                            </a>
                          </td>
                        </tr>
                        @endforeach
                        </tbody>
                      </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
<!--// gallery content -->

@stop
