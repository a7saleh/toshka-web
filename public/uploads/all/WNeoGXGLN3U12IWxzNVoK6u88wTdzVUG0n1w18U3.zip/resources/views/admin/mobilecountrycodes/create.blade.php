@extends('admin.layout.master')

@section('title' ,  trans('messages.add') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.mobile_country_codes') . ' / ' . trans('messages.add') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('mobilecountrycodes.store') }}" data-parsley-validate class="form-horizontal form-label-left">
                    {!! csrf_field() !!}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="mob_country_code">{{ trans('messages.country_code') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="mob_country_code" maxlength="5" name="mob_country_code" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align">{{ trans('messages.countries') }} <span class="required">*</span> </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select class="select2_single form-control" required 
                        tabindex="-1" name="country_id">
                          <option disabled="disabled" selected="selected"> Select Country </option>
                          @foreach ($countries as $country)
                             <option value="{{ $country->id }}">{{ $country->country_name }}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>

                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                        <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                      </div>
                    </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
