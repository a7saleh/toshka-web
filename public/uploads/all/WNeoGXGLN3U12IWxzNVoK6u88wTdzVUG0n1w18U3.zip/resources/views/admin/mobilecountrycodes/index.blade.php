@extends('admin.layout.master')

@section('title', trans('messages.mobile_country_codes'))

@section('body')

<!-- page content -->


	<div class="right_col" role="main">
		<div class="col-md-12 col-sm-12">
		    @if(Session::has('success'))
              <div class="alert alert-success mt-3">
              {{Session::get('success')}}
              </div> 
            @endif
			<div class="x_panel">
				<div class="x-header mb-3">
					<h2 class="float-left"><small>{{ trans('messages.mobile_country_codes') }}</small></h2>
                    <a href="{{ route('mobilecountrycodes.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}  </a>
				</div>
				<div class="x_content">
					<div class="row">
						<div class="col-sm-12">
							<div class="card-box table-responsive">
								<table id="mobileCountryTable" class="table table-striped table-bordered dataTable" style="width:100%">
			                      <thead>
			                        <tr>
					                  <th>ID</th>
                                      <th> {{ trans('messages.country_code') }} </th>
					                  <th> {{ trans('messages.country') }} </th>
					                  <th> {{ trans('messages.control') }} </th>
			                        </tr>
			                      </thead>

			                      <tbody>
				                    @foreach($mobilecountrycodes as $key => $mobilecountrycode)                  
				                      	<tr>
											<td>{{ $mobilecountrycode->id }}</td>
                                            <td>{{ $mobilecountrycode->mob_country_code }}</td>
                                            <td>{{ $mobilecountrycode->country->country_name }}</td>
                                            <td>
                                                <form method="POST" action="{{ route('mobilecountrycodes.destroy', $mobilecountrycode->id) }}">
                                                        {{ csrf_field() }}
                                                        {{ method_field('DELETE') }}

                                                        <div class="form-group">
                                                            <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i>{{ trans('messages.delete') }} </a>
                                                        </div>
                                                    </form>

                                                    <a href="{{ route('mobilecountrycodes.edit', $mobilecountrycode->id) }}" class="btn btn-small btn-info">
                                                        <i class="fa fa-edit"></i> {{ trans('messages.update') }} 
                                                    </a>
                                            </td>
					                    </tr>
				                    @endforeach
			                      </tbody>

			                    </table>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
		</div>
	</div>

<!--// page content -->

@stop
