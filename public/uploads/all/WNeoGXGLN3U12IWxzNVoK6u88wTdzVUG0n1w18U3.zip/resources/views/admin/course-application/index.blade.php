
@extends('admin.layout.master')

@section('title', trans('messages.courseApplication'))

@section('body')

    <!-- gallery content -->


    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">


            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2 class="float-left"><small>{{ trans('messages.courseApplication') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                                <div class="date-range-filter">
                                    @csrf
                                    <div class="col-lg-12">
                                        <form action="{{ url('admin/reports/filter-course-application') }}" method="get">
                                            <h2>Filter between Dates</h2>
                                            <div class="form-group">
                                                <label for="contactDateRange">First Date:</label>
                                                <input type="text" class="date-form-control report-calendar" name="first_date" value="@if(!empty($first_date)) {{ $first_date }} @endif" autocomplete="off" required>
                                                <label for="contactDateRange">Second Date:</label>
                                                <input type="text" class="date-form-control report-calendar" name="second_date" value="@if(!empty($second_date)) {{ $second_date }} @endif" autocomplete="off" required>
                                                <button type="submit" class="btn btn-success">Filter</button>
                                                <a href="{{ url('admin/courseApplication') }}" type="submit" class="btn btn-secondary">Reset</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <table id="galleryTable" class="table table-striped table-bordered dataTableReport" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>{{ trans('messages.course_name') }}</th>
                                        <th>{{ trans('messages.name') }}</th>
                                        <th>{{ trans('messages.english_name') }}</th>
                                        <th>{{ trans('messages.email') }}</th>
                                        <th>{{ trans('messages.number') }}</th>
                                        <th>{{ trans('messages.country') }}</th>
                                        <th>{{ trans('messages.company') }}</th>
                                        <th>{{ trans('messages.birthdate') }}</th>
                                        <th>{{ trans('messages.gender') }}</th>
                                        <th>{{ trans('messages.job_title') }}</th>
                                        <th>{{ trans('messages.cv') }}</th>
                                        <th>{{ trans('messages.date') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($applications as $key => $application)
                                        <tr>
                                            <td>
                                                <p> {{ $application->id }} </p>
                                            </td>
                                            <td>
                                                @if(!empty($applications[$key]->course->title_en))
                                                    <p> {{ $application->course->title_en }} </p>
                                                @else
                                                    <p> - </p>
                                                @endif
                                            </td>
                                            <td>
                                                <p> {{ $application->name }}  </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->name_en }}  </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->email }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->number }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->country }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->company }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->birthdate }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->gender }} </p>
                                            </td>
                                            <td>
                                                <p> {{ $application->job_title }} </p>
                                            </td>
                                            <td>
                                                @if(!empty($application->cv))
                                                    <a href="{{ url('/storage/uploads/courseApplication/') }}/{{ $application->cv }}" target="_blank" class="btn btn-small btn-info">
                                                       {{ trans('messages.cv') }}
                                                    </a>
                                                @endif
                                            </td>
                                            <td>
                                                <p> {{ Carbon\Carbon::parse($application->created_at)->toDateString() }} </p>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// gallery content -->


@stop
@section('script')
    <script>
        $(document).ready(function () {
            $('.dataTableReport').DataTable({
                "pageLength": 5,
                "order": [],
                "dom": 'Bfrtip',
                "stateSave": true,
                "buttons": [
                    {
                        extend: 'csv',
                    },
                ],
                "language": {
                    "emptyTable": "{{trans('messages.empty_table')}}",
                    "info": "{{trans('messages.showing')}} _START_ {{trans('messages.to')}} _END_ {{trans('messages.of')}} _TOTAL_ {{trans('messages.entries')}}",
                    "infoEmpty": "{{trans('messages.showing')}} 0 {{trans('messages.to')}} 0 {{trans('messages.of')}} 0 {{trans('messages.entries')}}",
                    "infoFiltered": "({{trans('messages.filtered_from')}} _MAX_ {{trans('messages.total_entries')}})",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "{{trans('messages.show')}} _MENU_ {{trans('messages.entries')}}",
                    "loadingRecords": "{{trans('messages.loading')}}...",
                    "processing": "{{trans('messages.processing')}}...",
                    "search": "{{trans('messages.search')}}:",
                    "zeroRecords": "{{trans('messages.no_matching_records_found')}}",
                    "paginate": {
                        "first": "{{trans('messages.first')}}",
                        "last": "{{trans('messages.last')}}",
                        "next": "{{trans('messages.next')}}",
                        "previous": "{{trans('messages.previous')}}"
                    },
                    "aria": {
                        "sortAscending": ": activate to sort column ascending",
                        "sortDescending": ": activate to sort column descending"
                    },
                },
                // 'aaSorting': [[3, 'desc']]
            });

            $('.buttons-csv').text('Export Excel').css({
                'background' : '#f2f2f2',
                'color' : 'green',
                'border' : '1px solid #f3f3f3'
            });

        });
    </script>
@endsection
