
@extends('admin.layout.master')

@section('title', trans('messages.news'))

@section('body')

<!-- news content -->


  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">

        @if(Session::has('success'))
          <div class="alert alert-success mt-3">
          {{Session::get('success')}}
          </div>
        @endif

        <div class="x_panel">
          <div class="x-header mb-3">
            <h2 class="float-left"><small>{{ trans('messages.news') }}</small></h2>
              <a href="{{ route('news.create') }}" class="btn btn-success float-right"><i class="fa fa-plus"></i> {{ trans('messages.add') }}
              </a>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box table-responsive">
                <table id="newsTable" class="table table-striped table-bordered dataTable" style="width:100%">
                  <thead>
                    <tr>
                      <th> ID </th>
                      <th>{{ trans('messages.title_en') }}</th>
                      <th style="word-break: break-word;">{{ trans('messages.content') }}</th>
                      <th>{{ trans('messages.type') }}</th>
                      {{-- <th>{{ trans('messages.link') }}</th> --}}
                      <th>{{ trans('messages.created_by') }}</th>
                      <th>{{ trans('messages.updated_by') }}</th>
                      <th>{{ trans('messages.priority') }}</th>
                      <th>{{ trans('messages.control') }} </th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($news as $new)
                        <tr>
                          <td>{{ $new->id }}</td>
                          <td><a href="{{ route('news.edit', $new->id) }}">{{$new->title_en}}</a></td></td>
                          <td> {{ strlen($new->content_en) > 30 ? substr($new->content_en,0,30).'...' : $new->content_en }}
                          </td>
                          <td>
                            @if($new->is_blog == 1)
                            <h2> Blog </h2>
                            @else
                            <h2> News </h2>
                            @endif
                          </td>
{{--                           <td>
                            <a href="{{ $new->link }}">{{ $new->link }}</a>
                          </td> --}}
                          @if(!empty($new->createdBy->first_name))
                          <td>{{$new->createdBy->first_name}}</td>
                          @else <td> </td>
                          @endif

                          @if(!empty($new->updatedBy->first_name))
                          <td>{{$new->updatedBy->first_name}}</td>
                          @else <td> </td>
                          @endif
                            <td>{{ $new->priority }}</td>
                          <td>
                            <form method="POST" action="{{ route('news.destroy', $new->id) }}">
                              {{ csrf_field() }}
                              {{ method_field('DELETE') }}

                              <div class="form-group">
                                  <a href="javascript:void(0);" class="btn btn-small btn-danger delete-btn"><i class="fa fa-trash"></i> {{ trans('messages.delete') }} </a>
                              </div>
                            </form>

                            <a href="{{ route('news.edit', $new->id) }}" class="btn btn-small btn-info">
                                <i class="fa fa-edit"></i> {{ trans('messages.update') }} / {{ trans('messages.view') }}
                            </a>
                          </td>
                        </tr>
                        @endforeach
                        </tbody>
                      </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
<!--// new content -->

@stop
