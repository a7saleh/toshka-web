@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

<!-- page content -->

  <div class="right_col" role="main">
    <div class="col-md-12 col-sm-12">
      <div class="x_panel">
        <div class="x-header mb-3">
          <h2><small>{{ trans('messages.news') . ' / ' . trans('messages.update') }}</small></h2>
        </div>
        <div class="x_content">
          <div class="row">
            <div class="col-sm-12">
              <div class="card-box">

                @if($errors->any())
                  <div class="alert alert-danger mt-3">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
                @endif

                <form method="POST" action="{{ route('news.update', $new->id) }}" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                    {!! csrf_field() !!}
                    {{ method_field('PUT') }}

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-en">{{ trans('messages.title_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-en" value="{{ $new->title_en }}" name="title_en" required="required" class="form-control">
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="title-ar">{{ trans('messages.title_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="title-ar" value="{{ $new->title_ar }}" name="title_ar" required="required" class="form-control ">
                      </div>
                    </div>

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="meta_description_en">{{ trans('messages.meta_description_en') }} <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="text" id="meta_description_en" value="{{ $new->meta_description_en }}" name="meta_description_en" required="required" class="form-control ">
                        </div>
                    </div>


                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="meta_description_ar">{{ trans('messages.meta_description_ar') }} <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="text" id="meta_description_ar" value="{{ $new->meta_description_ar }}" name="meta_description_ar" required="required" class="form-control ">
                        </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_en">{{ trans('messages.content_en') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="content_en" id="content_en" required="required">{{ $new->content_en }}</textarea>
                      </div>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="content_ar">{{ trans('messages.content_ar') }} <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <textarea class="form-control" name="content_ar" id="content_ar" required="required">{{ $new->content_ar }}</textarea>
                      </div>
                    </div>
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="date">{{ trans('messages.date') }} <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="date" id="date" name="date" class="form-control" required autocomplete="off" value="{{ $new->date }}">
                        </div>
                    </div>
                    <div class="item form-group" id="breakingNews">
                        <label id="test" class="col-form-label col-md-3 col-sm-3 label-align" for="breaking_news"> Breaking News
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <input type="checkbox" style="width:10%" {{ ($new->breaking_news == 1) ? 'checked=checked' : '' }} class="form-control" value="1" name="breaking_news" id="breaking_news">
                        </div>
                    </div>

{{--                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="link"> {{ trans('messages.link') }}
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" class="form-control" name="link" value="{{ $new->link }}" id="link">
                      </div>
                    </div> --}}

                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="file"> {{ trans('messages.image') }}
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <div class="col-md-12 col-sm-12 text-center"><img src="/storage/uploads/news/{{ $new->file }}" width="100"></div>
                            <input type="file" class="form-control" name="file" id="file">
                        </div>
                    </div>
                    
                    <div class="item form-group">
                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="file"> {{ trans('messages.cover') }}
                        </label>
                        <div class="col-md-6 col-sm-6 ">
                            <div class="col-md-12 col-sm-12 text-center"><img src="/storage/uploads/news/{{ $new->inner_image }}" width="100"></div>
                            <input type="file" class="form-control" name="inner_image" id="inner_image">
                        </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="is_blog"> Is Blog
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="checkbox" style="width:10%" {{ ($new->is_blog == 1) ? 'checked=checked' : '' }} class="form-control" value="1" name="is_blog" id="is_blog">
                      </div>
                    </div>
                    <div class="item form-group display-none" id="explore_blog">
                        <label id="test" class="col-form-label col-md-3 col-sm-3 label-align" for=""> Type
                        </label>
                        <div class="col-md-6 col-sm-6" style="display: flex ; flex-direction: row ; justify-content: flex-start ; align-items: center">
                            <input type="checkbox" style="width:10%" {{ ($new->explore_more == 1) ? 'checked=checked' : '' }} class="form-control" value="1" name="explore_more" id="explore_more">
                            <label for="explore_more" style="padding: 10px ; margin-bottom: 0"> Explore More</label>
                            <input type="checkbox" style="width:10%" {{ ($new->most_popular == 1) ? 'checked=checked' : '' }} class="form-control" value="1" name="most_popular" id="most_popular">
                            <label for="most_popular" style="padding: 10px ; margin-bottom: 0"> Most Popular</label>
                            <input type="checkbox" style="width:10%" {{ ($new->latest == 1) ? 'checked=checked' : '' }} class="form-control" value="1" name="latest" id="latest">
                            <label for="latest" style="padding: 10px ; margin-bottom: 0"> Latest Articles</label>
                        </div>
                    </div>

                <div class="item form-group display-none" id="related_courses_div">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="related_courses"> Select
                        Related Course
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <select name="related_courses[]" class="form-control related-courses" id="related_courses" multiple="multiple">
                            @foreach($selected_courses as $course)
                                <option selected value="{{ $course->id }}">{{ $course->title_en }}</option>
                            @endforeach
                            @foreach($related_courses as $course)
                                <option value="{{ $course->id }}">{{ $course->title_en }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="item form-group">
                    <label class="col-form-label col-md-3 col-sm-3 label-align" for="priority"> Priority
                    </label>
                    <div class="col-md-6 col-sm-6 ">
                        <input type="number" class="form-control" name="priority" id="priority" value="{{ $new->priority }}">
                    </div>
                </div>
                
                                        <div class="item form-group" id="video_achiev">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align"
                                               for="video">{{ trans('messages.video') }}
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="video" id="video"
                                                    value="{{ $new->video }}">
                                        </div></div>                
                
                <div class="ln_solid"></div>
                <div class="item form-group">
                  <div class="col-md-6 col-sm-6 offset-md-3">
                    <button class="btn btn-primary" type="reset">{{ trans('messages.reset_btn') }}</button>
                    <button type="submit" class="btn btn-success">{{ trans('messages.submit') }}</button>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--// page content -->

@stop
