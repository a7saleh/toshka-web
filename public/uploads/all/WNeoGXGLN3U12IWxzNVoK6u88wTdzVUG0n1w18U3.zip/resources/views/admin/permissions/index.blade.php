@extends('admin.layout.master')

 @section('title', trans('messages.permissions'))

 @section('body')

         <!-- page content -->
    <div class="right_col" role="main">

        <div class="col-md-6 msg-success">
        </div>

        <?php  $count = 0 ; ?>
        @foreach($user_roles as $role)
          <div class="col-md-12 mt-3">
            <h6>{{ trans('messages.notes') }}:</h6>
            <h6>index  -> to view items</h6>
            <h6>add & store   -> to add item</h6>
            <h6>edit & update -> to edit item</h6>
            <h6>destroy -> to delete item</h6>
          <div class="card">
            <div class="card-header">
              <h5 class="card-title"> <b> {{$role->name}} </b> {{ trans('messages.permissions') }} </h5>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form class="frm-permission" role="form" role-id="{{$role->id}}">
                <div class="card-body">
                <div class="row">
                @foreach($permissions as $permission)
                <?php  $count++ ?>
                  <div class="form-group col-md-3">
                    @if(in_array($permission->id,$role->permissions))
                      <div class="icheck-primary d-inline">
                        <input type="checkbox" id="checkboxPrimary3-{{$count}}" value="{{$permission->id}}" p-id="{{$permission->id}}" checked>
                        <label for="checkboxPrimary3-{{$count}}" style="word-break: break-all; font-size: 15px;">
                          {{$permission->name}}
                        </label>
                      </div>
                    @else
                      <div class="icheck-primary d-inline">
                        <input type="checkbox" id="checkboxPrimary3-{{$count}}" value="{{$permission->id}}" p-id="{{$permission->id}}">
                        <label for="checkboxPrimary3-{{$count}}" style="word-break: break-all; font-size: 15px;">
                          {{$permission->name}}
                        </label>
                      </div>
                    @endif
                  </div>
                @endforeach
                </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      @endforeach

    </div>
 @stop
