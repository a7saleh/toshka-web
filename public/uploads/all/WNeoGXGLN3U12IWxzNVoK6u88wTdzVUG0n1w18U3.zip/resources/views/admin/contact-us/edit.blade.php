@extends('admin.layout.master')

@section('title' ,  trans('messages.update') )

@section('body')

    <!-- page content -->

    <div class="right_col" role="main">
        <div class="col-md-12 col-sm-12">
            <div class="x_panel">
                <div class="x-header mb-3">
                    <h2><small>{{ trans('messages.contact_us') . ' / ' . trans('messages.update') }}</small></h2>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box">

                                @if($errors->any())
                                    <div class="alert alert-danger mt-3">
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                <form method="POST" action="{{ route('contact-us.update' , $content->id) }}"
                                      data-parsley-validate class="form-horizontal form-label-left"
                                      enctype="multipart/form-data">
                                    {!! csrf_field() !!}
                                    {{ method_field('PUT') }}

                                    <input type="text" class="form-control" name="ref_page" id="ref_page" required="required" value="contact-us" style="display: none">

                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_en"> {{ trans('messages.title_en') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="title_en" id="title_en" required="required" value="{{ $content->title_en }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="title_ar">{{ trans('messages.title_ar') }}<span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <input type="text" class="form-control" name="title_ar" id="title_ar" required="required" value="{{ $content->title_ar }}">
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_en"> {{ trans('messages.description_en') }} <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_en" id="description_en" required="required">{{ $content->description_en }}</textarea>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="col-form-label col-md-3 col-sm-3 label-align" for="description_ar">{{ trans('messages.description_ar') }}<span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 ">
                                            <textarea type="text" class="form-control" name="description_ar" id="description_ar" required="required">{{ $content->description_ar }}</textarea>
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="item form-group">
                                        <div class="col-md-6 col-sm-6 offset-md-3">
                                            <button class="btn btn-primary"
                                                    type="reset">{{ trans('messages.reset_btn') }}</button>
                                            <button type="submit"
                                                    class="btn btn-success">{{ trans('messages.submit') }}</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--// page content -->

@stop
