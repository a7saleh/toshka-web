@extends('website.layout.master')

@section('title', '404')

@section('content')

<div class="error-holder" style="margin: 0px; padding:0px; width:100%;">
  <img src="{{ asset('../../frontend/images/404.png') }}" style="margin: 0px; padding:0px; width:100%;" alt="404">
</div>

@stop
