<!DOCTYPE html>
<html lang="">
<head>
    <!-- set the encoding of your site -->
    <meta charset="utf-8">
    <!-- set the viewport width and initial-scale on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- set the HandheldFriendly -->
    <meta name="HandheldFriendly" content="True">
    <!-- set the description -->
    <meta name="description"
          content="In 2000, Aljhood founded as development and consultation services provider. which aims at providing the companies operating in the local and Arab market with expertise and knowledge. ">
    <!-- set the Keyword -->
    <meta name="keywords" content="aljhood">
    <meta name="author" content="aljhood">
    <!-- base url -->
    <meta name="base_url" content="{{url('/')}}">
    <!-- csrf token -->
    <meta name="csrf_token" content="{{ csrf_token() }}">

    <!-- set the page title -->
    <title> 404 </title>

    <!-- Add site Favicon -->
    <link rel="icon" href="{{ asset("frontend/images/favicon/50x50.png") }}" sizes="50x50"/>
    <link rel="icon" href="{{ asset("frontend/images/favicon/180x180.png") }}" sizes="180x180"/>
    <link rel="apple-touch-icon" href="{{ asset("frontend/images/favicon/180x180.png") }}"/>
    <!-- include google roboto font cdn link -->
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i"
        rel="stylesheet">
    <!-- include the site bootstrap stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/bootstrap.css") }}">
    <!-- include the plugins stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/plugins.css") }}">
    <!-- include the colors stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/colors.css") }}">
    <!-- include the custom stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/custom.css") }}">
    <!-- include the site responsive stylesheet -->
    <link rel="stylesheet" href="{{ asset("frontend/css/responsive.css") }}">
    <!-- jquery ui -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
    <!-- include pannellum 360 image viewer -->
{{-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"/> --}}
<!-- include animate css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
</head>
<body style="margin: 0px; padding:0px; background:#323232;">

<!-- main container of all the page elements -->
@if(app()->getLocale() == "en")
    <div id="wrapper">
    <!-- header of the page -->
    <header id="page-header" class="page-header-stick">
        <!-- top bar -->
        <div class="top-bar bg-dark text-gray">
            <div class="container">
                <div class="row top-bar-holder">

                </div>
            </div>
        </div>
        <!-- header holder -->
        <div class="header-holder">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 col-sm-3">
                        <!-- logo -->
                        <div class="logo">
                            <a href="{{ url('/') }}">
                                <img class="hidden-xs" src="{{ asset("frontend/images/logos/logo.png") }}"
                                     alt="aljhood">
                                <img class="hidden-sm hidden-md hidden-lg"
                                     src="{{ asset("frontend/images/logos/logo-dark.png") }}"
                                     alt="aljhood">
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-6 col-sm-9 static-block">
                        <!-- nav -->
                        <nav id="nav" class="navbar navbar-default">
                            <!-- navbar collapse -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <!-- main navigation -->
                                <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato">
                                    <li class="dropdown">
                                        <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false">AL JHOOD</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="{{ url('aljhood/about-us') }}">About Us</a></li>
                                            <li><a href="{{ url('aljhood/leadership') }}">Leadership</a></li>
                                            <li><a href="{{ url('aljhood/brands') }}">Brands</a></li>
                                            <li><a href="{{ url('aljhood/ourimpact') }}">Our Impact</a></li>
                                            <li><a href="{{ url('aljhood/strategies') }}">Strategy</a></li>
                                            <li>
                                                <a href="{{ url('aljhood/achievements2') }}">Achievements</a>
                                            </li>
                                            <li><a href="{{ url('aljhood/achievements/#partners_trusted') }}">Trusted By
                                                    and Accreditation</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="{{ url('aljhood/trainings') }}">TRAINING</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('aljhood/consultancy') }}">CONSULTANCY</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('aljhood/courses') }}">COURSES</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false">RESOURCES</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="{{ url('aljhood/blog') }}">Blog</a></li>
                                            <li><a href="{{ url('aljhood/news') }}">News</a></li>
                                            <li><a href="{{ url('aljhood/faqs') }}">FAQ</a></li>
                                            <li><a href="{{ url('aljhood/gallery') }}">Gallery</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                           role="button" aria-haspopup="true" aria-expanded="false">CONNECT</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="{{ url('aljhood/contact-us') }}">Contact Us</a></li>
                                            <li><a href="{{ url('aljhood/join-us') }}">Join Us</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <!-- navbar form -->
                            <form action="{{ url('search') }}" method="GET" class="navbar-form navbar-search-form navbar-right">
                                <a class="fas fa-search search-opener" role="button" data-toggle="collapse" href="#searchCollapse" aria-expanded="false" aria-controls="searchCollapse">
                                    <span class="sr-only">search opener</span>
                                </a>
                                <!-- search collapse -->
                                <div class="collapse search-collapse" id="searchCollapse">
                                    <div class="form-group">
                                        <input type="text" name="search_word" pattern=".*\S+.*"
                                               title="This field is required" class="form-control"
                                               placeholder="Search for courses, news &hellip;" required="required">
                                        <button type="submit" class="fas fa-search btn"><span
                                                class="sr-only">search</span></button>
                                    </div>
                                </div>
                            </form>
                            <span class="lang_switcher">
                                <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}" class="lang-text">
                                    <i class="fa fa-globe"></i>
                                     @if(app()->getLocale() == "en")
                                        عربي
                                    @else
                                        EN
                                    @endif
                                </a>
                            </span>
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- contain main informative part of the site -->
    <main id="main">
        <div class="error-holder">
            <img src="{{ asset('../../frontend/images/404.png') }}" style="margin: 0px; padding:0px; width:100%;">
        </div>
    </main>

    <!-- footer area container -->
    <div class="footer-area bg-dark text-gray">
        <!-- aside -->
        <aside class="aside container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 col">
                    <div class="logo"><a href="{{ url('/') }}"><img src="{{ asset("frontend/images/logos/logo.png") }}"
                                                                    alt="aljhood"></a></div>
                    <p>In 2000, a host of youths who believe in entrepreneurship gathered their efforts to make a
                        success. They worked hard a round the clock to materialize the hopes and ambitions and make an
                        Arab edifice for knowledge, an edifice having a presence between the consultation and training
                        firms in the advanced countries.</p>
                </div>
                <nav class="col-xs-12 col-sm-12 col-md-3 col">
                    <h3>Quick Links</h3>
                    <!-- fooer navigation -->
                    <ul class="fooer-navigation list-unstyled">
                        <li><a href="{{ url('aljhood/about-us') }}">About us</a></li>
                        <li><a href="{{ url('aljhood/contact-us') }}">Contact us</a></li>
                        <li><a href="{{ url('aljhood/join-us') }}">Join us</a></li>
                        <li><a href="{{ url('aljhood/suggest-new-course-form') }}">Suggest a course</a></li>
                        <li><a href="{{ url('aljhood/instructor-form') }}">Apply to teach</a></li>
                        <li><a href="{{ url('aljhood/reseller-form') }}">Become a reseller</a></li>
                    </ul>
                </nav>

                <nav class="col-xs-12 col-sm-12 col-md-3 col">
                    <h3>Legal</h3>
                    <!-- fooer navigation -->
                    <ul class="fooer-navigation list-unstyled">
                        <li><a href="{{ url('aljhood/terms-of-use') }}">Terms of use</a></li>
                        <li><a href="{{ url('aljhood/privacy-policy') }}">Privacy policy</a></li>
                        <li><a href="{{ url('aljhood/copyright') }}">Copyright</a></li>
                        <li><a href="{{ url('aljhood/sitemap') }}">Sitemap</a></li>
                    </ul>
                </nav>

                <div class="col-xs-12 col-sm-12 col-md-3 col">
                    <h3>contact us</h3>
                    <p>If you want to contact us about any issue our support available to help you 8:30am - 5:00pm
                        Sunday to Thursday - Saturday 8:30am - 3:00pm.</p>
                    <!-- ft address -->
                    <address class="ft-address">
                        <dl>
                            <dt><span class="fas fa-map-marker"><span class="sr-only">marker</span></span></dt>
                            <dd>Amman - Jordan, Queen Rania St. Building No. 155</dd>
                            <dt><span class="fas fa-phone-square"><span class="sr-only">phone</span></span></dt>
                            <dd>Call: <a href="tel:+962065522807">+962 (06) 552 2807</a></dd>
                            <dt><span class="fas fa-envelope-square"><span class="sr-only">email</span></span></dt>
                            <dd>Email: <a href="mailto:info@aljhood.com">info@aljhood.com</a></dd>
                        </dl>
                    </address>
                </div>
            </div>
        </aside>
        <!-- page footer -->
        <footer id="page-footer" class="font-lato">
            <div class="container">
                <div class="row holder">
                    <div class="col-xs-12 col-sm-push-6 col-sm-6">
                        <ul class="socail-networks list-unstyled">
                            <li><a href="https://www.facebook.com/AljhoodGroup" target="_blank"><span
                                        class="fab fa-facebook"></span></a>
                            </li>
                            <li><a href="https://twitter.com/AljhoodGroup" target="_blank"><span
                                        class="fab fa-twitter"></span></a></li>
                            <li><a href="https://www.instagram.com/aljhoodgroup/" target="_blank"><span
                                        class="fab fa-instagram"></span></a></li>
                            <li><a href="https://www.linkedin.com/company/aljhoodgroup/" target="_blank"><span
                                        class="fab fa-linkedin">
                                    </span></a></li>
                            <li><a href="javascript:void(0)"><span class="fab fa-whatsapp">
                                    </span></a></li>
                            <li><a href="javascript:void(0)"><span class="fab fa-youtube">
                                    </span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- back top of the page -->
    <span id="back-top" class="text-center fa fa-caret-up"></span>
    <span id="whats-app" class="text-center fab fa-whatsapp"></span>
    <!-- loader of the page -->
    <div id="loader" class="loader-holder">
        <div class="block"><img src="{{ asset("frontend/images/svg/hearts.svg") }}" width="100" alt="loader"></div>
    </div>
</div>
@else
    <div id="wrapper">
        <!-- header of the page -->
        <header id="page-header" class="page-header-stick">
            <!-- top bar -->
            <div class="top-bar bg-dark text-gray">
                <div class="container">
                    <div class="row top-bar-holder">

                    </div>
                </div>
            </div>
            <!-- header holder -->
            <div class="header-holder">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-6 col-sm-3">
                            <!-- logo -->
                            <div class="logo">
                                <a href="{{ url('/') }}">
                                    <img class="hidden-xs" src="{{ asset("frontend/images/logos/logo.png") }}"
                                         alt="aljhood">
                                    <img class="hidden-sm hidden-md hidden-lg"
                                         src="{{ asset("frontend/images/logos/logo-dark.png") }}"
                                         alt="aljhood">
                                </a>
                            </div>
                        </div>
                        <div class="col-xs-6 col-sm-9 static-block">
                            <!-- nav -->
                            <nav id="nav" class="navbar navbar-default">
                                <!-- navbar collapse -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <!-- main navigation -->
                                    <ul class="nav navbar-nav navbar-right main-navigation text-uppercase font-lato text-right">
                                        <li class="dropdown">
                                            <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                               role="button" aria-haspopup="true" aria-expanded="false">الاتصال</a>
                                            <ul class="dropdown-menu" style="left: auto">
                                                <li><a href="{{ url('aljhood/contact-us') }}" style="text-align: right">اتصل بنا</a></li>
                                                <li><a href="{{ url('aljhood/join-us') }}" style="text-align: right">انضم لنا</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                               role="button" aria-haspopup="true" aria-expanded="false">مصادر اخرى</a>
                                            <ul class="dropdown-menu" style="left: auto">
                                                <li><a href="{{ url('aljhood/blog') }}" style="text-align: right">مدونات</a></li>
                                                <li><a href="{{ url('aljhood/news') }}" style="text-align: right">اخبار</a></li>
                                                <li><a href="{{ url('aljhood/faqs') }}" style="text-align: right">الأسئلة الأكثر شيوعاً</a></li>
                                                <li><a href="{{ url('aljhood/gallery') }}" style="text-align: right">الصور</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="{{ url('aljhood/courses') }}">الدورات</a>
                                        </li>
                                        <li>
                                            <a href="{{ url('aljhood/consultancy') }}">استشارات</a>
                                        </li>
                                        <li>
                                            <a href="{{ url('aljhood/trainings') }}">التدريب</a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"
                                               role="button" aria-haspopup="true" aria-expanded="false">الجهود</a>
                                            <ul class="dropdown-menu" style="left: auto">
                                                <li><a href="{{ url('aljhood/about-us') }}" style="text-align: right">من نحن</a></li>
                                                <li><a href="{{ url('aljhood/leadership') }}" style="text-align: right">القيادة</a></li>
                                                <li><a href="{{ url('aljhood/brands') }}" style="text-align: right">العلامات التجارية</a></li>
                                                <li><a href="{{ url('aljhood/ourimpact') }}" style="text-align: right">تأثيرنا</a></li>
                                                <li><a href="{{ url('aljhood/strategies') }}" style="text-align: right">إستراتيجياتنا</a></li>
                                                <li>
                                                    <a href="{{ url('aljhood/achievements2') }}" style="text-align: right">إنجازاتنا</a>
                                                </li>
                                                <li><a href="{{ url('aljhood/achievements/#partners_trusted') }}" style="text-align: right">الاعتماد الاكاديمي</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                                <!-- navbar form -->
                                <form action="{{ url('search') }}" method="GET" class="navbar-form navbar-search-form navbar-right">
                                    <a class="fas fa-search search-opener" role="button" data-toggle="collapse" href="#searchCollapse" aria-expanded="false" aria-controls="searchCollapse">
                                        <span class="sr-only">محرك البحث</span>
                                    </a>
                                    <!-- search collapse -->
                                    <div class="collapse search-collapse" id="searchCollapse">
                                        <div class="form-group">
                                            <input type="text" name="search_word" pattern=".*\S+.*"
                                                   title="This field is required" class="form-control"
                                                   placeholder="ابحث عن دورات , أخبار و مدونات ...">
                                            <button type="submit" class="fas fa-search btn" style="left: 0 !important; right: unset"><span
                                                    class="sr-only">بحث</span></button>

                                        </div>
                                    </div>
                                </form>
                                <span class="lang_switcher">
                                    <a href="{{(app()->getLocale() == "en")?request()->getRequestUri() . '?lang=ar':request()->getRequestUri() . '?lang=en'}}" class="lang-text">
                                        <i class="fa fa-globe"></i>
                                         @if(app()->getLocale() == "en")
                                            AR
                                        @else
                                            EN
                                        @endif
                                    </a>
                                </span>
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                            data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- contain main informative part of the site -->
        <main id="main">
            <div class="error-holder">
                <img src="{{ asset('../../frontend/images/404.png') }}" style="margin: 0px; padding:0px; width:100%;">
            </div>
        </main>

        <!-- footer area container -->
        <div class="footer-area bg-dark text-gray">
            <!-- aside -->
            <aside class="aside container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-3 col">
                        <div class="logo"><a href="{{ url('/') }}"><img src="{{ asset("frontend/images/logos/logo.png") }}"
                                                                        alt="aljhood"></a></div>
                        <p>In 2000, a host of youths who believe in entrepreneurship gathered their efforts to make a
                            success. They worked hard a round the clock to materialize the hopes and ambitions and make an
                            Arab edifice for knowledge, an edifice having a presence between the consultation and training
                            firms in the advanced countries.</p>
                    </div>
                    <nav class="col-xs-12 col-sm-12 col-md-3 col">
                        <h3>Quick Links</h3>
                        <!-- fooer navigation -->
                        <ul class="fooer-navigation list-unstyled">
                            <li><a href="{{ url('aljhood/about-us') }}">About us</a></li>
                            <li><a href="{{ url('aljhood/contact-us') }}">Contact us</a></li>
                            <li><a href="{{ url('aljhood/join-us') }}">Join us</a></li>
                            <li><a href="{{ url('aljhood/suggest-new-course-form') }}">Suggest a course</a></li>
                            <li><a href="{{ url('aljhood/instructor-form') }}">Apply to teach</a></li>
                            <li><a href="{{ url('aljhood/reseller-form') }}">Become a reseller</a></li>
                        </ul>
                    </nav>

                    <nav class="col-xs-12 col-sm-12 col-md-3 col">
                        <h3>Legal</h3>
                        <!-- fooer navigation -->
                        <ul class="fooer-navigation list-unstyled">
                            <li><a href="{{ url('aljhood/terms-of-use') }}">Terms of use</a></li>
                            <li><a href="{{ url('aljhood/privacy-policy') }}">Privacy policy</a></li>
                            <li><a href="{{ url('aljhood/copyright') }}">Copyright</a></li>
                            <li><a href="{{ url('aljhood/sitemap') }}">Sitemap</a></li>
                        </ul>
                    </nav>

                    <div class="col-xs-12 col-sm-12 col-md-3 col">
                        <h3>contact us</h3>
                        <p>If you want to contact us about any issue our support available to help you 8:30am - 5:00pm
                            Sunday to Thursday - Saturday 8:30am - 3:00pm.</p>
                        <!-- ft address -->
                        <address class="ft-address">
                            <dl>
                                <dt><span class="fas fa-map-marker"><span class="sr-only">marker</span></span></dt>
                                <dd>Amman - Jordan, Queen Rania St. Building No. 155</dd>
                                <dt><span class="fas fa-phone-square"><span class="sr-only">phone</span></span></dt>
                                <dd>Call: <a href="tel:+962065522807">+962 (06) 552 2807</a></dd>
                                <dt><span class="fas fa-envelope-square"><span class="sr-only">email</span></span></dt>
                                <dd>Email: <a href="mailto:info@aljhood.com">info@aljhood.com</a></dd>
                            </dl>
                        </address>
                    </div>
                </div>
            </aside>
            <!-- page footer -->
            <footer id="page-footer" class="font-lato">
                <div class="container">
                    <div class="row holder">
                        <div class="col-xs-12 col-sm-push-6 col-sm-6">
                            <ul class="socail-networks list-unstyled">
                                <li><a href="https://www.facebook.com/AljhoodGroup" target="_blank"><span
                                            class="fab fa-facebook"></span></a>
                                </li>
                                <li><a href="https://twitter.com/AljhoodGroup" target="_blank"><span
                                            class="fab fa-twitter"></span></a></li>
                                <li><a href="https://www.instagram.com/aljhoodgroup/" target="_blank"><span
                                            class="fab fa-instagram"></span></a></li>
                                <li><a href="https://www.linkedin.com/company/aljhoodgroup/" target="_blank"><span
                                            class="fab fa-linkedin">
                                    </span></a></li>
                                <li><a href="javascript:void(0)"><span class="fab fa-whatsapp">
                                    </span></a></li>
                                <li><a href="javascript:void(0)"><span class="fab fa-youtube">
                                    </span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        <!-- back top of the page -->
        <span id="back-top" class="text-center fa fa-caret-up"></span>
        <span id="whats-app" class="text-center fab fa-whatsapp"></span>
        <!-- loader of the page -->
        <div id="loader" class="loader-holder">
            <div class="block"><img src="{{ asset("frontend/images/svg/hearts.svg") }}" width="100" alt="loader"></div>
        </div>
    </div>
@endif


<!-- include min jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.js") }}"></script>
<!-- include Plugins -->
<script type="text/javascript" src="{{ asset("frontend/js/plugins.js") }}"></script>
<!-- include jQuery -->
<script type="text/javascript" src="{{ asset("frontend/js/jquery.main.js") }}"></script>
<!-- include init js -->
<script type="text/javascript" src="{{ asset("frontend/js/init.js") }}"></script>
<!-- include pannellum 360 image viewer -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js"></script>
<!-- include custom js -->
<script type="text/javascript" src="{{ asset("frontend/js/custom.js") }}"></script>
<!-- include jquery ui js -->
<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
<script>
    var url = $('meta[name=base_url]').attr("content");
    $(document).ready(function () {
        $(".partner-list img").click(function () {
            window.location.href = url + '/aljhood/achievements/#accreditation';
        });
    });
</script>
<script>

    $('.my-news-ticker').AcmeTicker({
        type: 'marquee',/*horizontal/horizontal/Marquee/type*/
        direction: 'right',/*up/down/left/right*/
        speed: 0.05,/*true/false/number*/ /*For vertical/horizontal 600*//*For marquee 0.05*//*For typewriter 50*/
        controls: {
            toggle: $('.acme-news-ticker-pause'),/*Can be used for horizontal/horizontal/typewriter*//*not work for marquee*/
        }
    });
    // pannellum.viewer('panorama', {
    //     "type": "equirectangular",
    //     "panorama": "https://pannellum.org/images/alma.jpg",
    //     "autoLoad": true
    // });

</script>

<script>
    $(window).load(function () {
        var newsHeight1 = $('#news1').innerHeight();
        $('#news2').css('height', newsHeight1 / 2);
        $('#news3').css('height', newsHeight1 / 2);
    });
</script>

<script>

    $(window).load(function () {
        var courseImageWidth = $('#courseImage').innerWidth();
        var courseDetailsWidth = $('#courseDetails').innerWidth();
        var courseDetailsHeight = $('#courseDetails').innerHeight();
        $('#courseDetails').css({
            width: courseImageWidth,
        });
        if (window.innerWidth < 1199) {
            $('.inner-page-courses').css('margin-top', courseDetailsHeight)
        }
    });
    // $(window).resize(function() {
    //     if ($(this).width() < 1199) {
    //         $('.inner-page-courses').css('margin-top' , '300px')
    //     }
    // });
</script>

<script>

    var course_select_1 = $('#course_select_1').find(":selected").val();
    var course_select_2 = $('#course_select_2').find(":selected").val();
    if (course_select_1 != 0 && course_select_1 != 0) {
        $('.compare-btn').on(change)
    } else {
        $('.compare-btn').prop('disabled', true);
    }

    function compare(id) {

        var course_select_1 = $('#course_select_1').find(":selected").val();
        var course_select_2 = $('#course_select_2').find(":selected").val();
        var course_select_3 = $('#course_select_3').find(":selected").val();

        if (course_select_1 == 0) {

            var element = $('#course_select_1');
            element.val(id);
            $('#addCompare_' + id).addClass('display-none');
            $('#removeCompare_' + id).removeClass('display-none');
        } else if (course_select_2 == 0) {

            var element = $('#course_select_2');
            element.val(id);
            $('#addCompare_' + id).addClass('display-none');
            $('#removeCompare_' + id).removeClass('display-none');
            $('.compare-btn').prop('disabled', false);
            $('.compare-courses-section').removeClass('display-none');


        } else if (course_select_3 == 0) {

            var element = $('#course_select_3');
            element.val(id);
            $('#addCompare_' + id).addClass('display-none');
            $('#removeCompare_' + id).removeClass('display-none');
            $('.compare-courses-section').removeClass('display-none');

        } else {
            alert('You already have the maximum number of courses to compare , please remove a course to add this one.');
        }

    }

    function removeCompare(id) {

        var course_select_1 = $('#course_select_1').find(":selected").val();
        var course_select_2 = $('#course_select_2').find(":selected").val();
        var course_select_3 = $('#course_select_3').find(":selected").val();

        if (course_select_1 == id) {

            var element = $('#course_select_1');
            element.val(0);
            $('#addCompare_' + id).removeClass('display-none');
            $('#removeCompare_' + id).addClass('display-none');
            $('.compare-btn').prop('disabled', true);
            $('.compare-courses-section').addClass('display-none');


        } else if (course_select_2 == id) {

            var element = $('#course_select_2');
            element.val(0);
            $('#addCompare_' + id).removeClass('display-none');
            $('#removeCompare_' + id).addClass('display-none');
            $('.compare-btn').prop('disabled', true);
            $('.compare-courses-section').addClass('display-none');

        } else if (course_select_3 == id) {

            var element = $('#course_select_3');
            element.val(0);
            $('#addCompare_' + id).removeClass('display-none');
            $('#removeCompare_' + id).addClass('display-none');

        } else {
            alert('You already have the maximum number of courses to compare , please remove a course to add this one.');
        }

    }

</script>

<!--
<script>
   if(window.innerWidth > 991){
       $(window).load(function () {
           var courseHeight1 = $('#compareCourse1').innerHeight();
           var courseHeight2 = $('#compareCourse2').innerHeight();
           var courseHeight3 = $('#compareCourse3').innerHeight();
           if (courseHeight3 == null){
               if (courseHeight1 > courseHeight2) {
                   $('#compareCourse1').addClass('scrolled').css('height' , courseHeight2);
               }else if(courseHeight2 > courseHeight1  && courseHeight2 > courseHeight3){
                   $('#compareCourse2').addClass('scrolled').css('height' , courseHeight1);
               }else{
                   console.log('Error First If');
               }
           }else{
               if (courseHeight1 > courseHeight2  && courseHeight1 > courseHeight3) {
                   if (courseHeight2 > courseHeight3){
                       $('#compareCourse1').addClass('scrolled').css('height' , courseHeight3);
                       $('#compareCourse2').addClass('scrolled').css('height' , courseHeight3);
                   }else{
                       $('#compareCourse1').addClass('scrolled').css('height' , courseHeight2);
                       $('#compareCourse3').addClass('scrolled').css('height' , courseHeight2);
                   }
               }else if(courseHeight2 > courseHeight1  && courseHeight2 > courseHeight3){
                   if (courseHeight1 > courseHeight3){
                       $('#compareCourse2').addClass('scrolled').css('height' , courseHeight3);
                       $('#compareCourse1').addClass('scrolled').css('height' , courseHeight3);
                   }else{
                       $('#compareCourse2').addClass('scrolled').css('height' , courseHeight1);
                       $('#compareCourse3').addClass('scrolled').css('height' , courseHeight1);
                   }
               }else if(courseHeight3 > courseHeight1  && courseHeight3 > courseHeight2){
                   if (courseHeight1 > courseHeight2){
                       $('#compareCourse3').addClass('scrolled').css('height' , courseHeight2);
                       $('#compareCourse1').addClass('scrolled').css('height' , courseHeight2);
                   }else{
                       $('#compareCourse3').addClass('scrolled').css('height' , courseHeight1);
                       $('#compareCourse2').addClass('scrolled').css('height' , courseHeight1);
                   }
               }else{
                   console.log('All Equals');
               }
           }

       });
   }


</script>
-->


</body>
</html>
