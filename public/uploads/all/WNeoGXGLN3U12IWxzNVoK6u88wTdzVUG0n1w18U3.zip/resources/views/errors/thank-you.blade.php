@extends('website.layout.master')

@section('title', '404')

@section('content')

<div class="error-holder">
  <img src="{{ asset('../../frontend/images/thnakyou.png') }}" style="margin: 0px; padding:0px; width:100%;" alt="Thank You">
</div>

@stop
